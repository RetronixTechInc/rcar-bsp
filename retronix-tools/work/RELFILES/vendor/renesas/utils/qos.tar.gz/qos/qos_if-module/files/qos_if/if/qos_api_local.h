/*
 * Copyright (c) 2016 Renesas Electronics Corporation
 * Released under the MIT license
 * http://opensource.org/licenses/mit-license.php
 */

#ifndef __QOS_H__
#define __QOS_H__

#include "qos_public_common.h"

#endif /* __QOS_H__ */
