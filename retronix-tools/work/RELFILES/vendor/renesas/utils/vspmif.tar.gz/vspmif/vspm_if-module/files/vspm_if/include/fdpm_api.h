/* 
 * Copyright (c) 2015 Renesas Electronics Corporation
 * Released under the MIT license
 * http://opensource.org/licenses/mit-license.php 
 */

#ifndef __FDPM_API_H__
#define __FDPM_API_H__

#include "vspm_public.h"
#endif
