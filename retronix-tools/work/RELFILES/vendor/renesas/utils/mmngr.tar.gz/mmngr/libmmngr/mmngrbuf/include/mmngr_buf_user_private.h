/*
 * Copyright (c) 2015-2016 Renesas Electronics Corporation
 * Released under the MIT license
 * http://opensource.org/licenses/mit-license.php
 */
#ifndef __MMNGR_BUF_USER_PRIVATE_H__
#define __MMNGR_BUF_USER_PRIVATE_H__

#include "mmngr_buf_private_cmn.h"

#endif	/* __MMNGR_BUF_USER_PRIVATE_H__ */
