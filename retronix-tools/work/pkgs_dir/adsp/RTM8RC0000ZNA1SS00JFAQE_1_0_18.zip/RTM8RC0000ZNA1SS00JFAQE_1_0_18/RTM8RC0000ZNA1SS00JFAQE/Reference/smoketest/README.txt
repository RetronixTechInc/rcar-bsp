ADSP Smoketest program Usage guideline & Example setting cases
***********************************************************************************
"ADSP Smoke Test program Help Menu"
			"command: adsp-omx-launch -i <input> -o <output> [-<command> <value>]"
			"-i <name>       : Input file (.pcm or .wav) or Input device (capture)"
			"-o <name>       : Output file (.pcm) or Output device (renderer)"
			"-eq <value>     : Enable/Disable equalizer (on/off) (default: off)"
			"-w <value>      : PCM Bit per sample (16/24)"(Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)
			"-c <value>      : PCM channel number for Capture and Equalizer (1/2)"(Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)
			"-eqzfs <value>  : Equalizer PCM sampling frequency(32000/44100/48000)"
			"-l <value>      : Recording time (second)"
			"-eqz <name>     : Equalizer configuration file"
			"-cap <name>     : Capture configuration file"
			"-rdr <name>     : Renderer configuration file"
			"-card <name>    : Select audio card"
"Equalizer configuration file example"
			"1. Parametric configuration file"
			" - Start 1st line with \"Parametric\" identity"
			" - 2nd line to 10th line will contain information structure like below:"
			"   Type Fc Bandwidth Gain BaseGain"
			" - Type: Filter type (P: Peak, R: Treble, B: Bass, T: Through"
			" - Fc: Frequency center (Peak|Through: 20-20000, Treble: 5000-11000, Bass: 50-500)"
			" - Bandwidth: 0.5 - 15"
			" - Gain (dB): -15.0 - 15.0"
			" - BaseGain (dB): -10.0 - 10.0"
			"Example:"
			"--------------------------------------------------------------------"
			"Parametric"
			"P 20000 0.2 10.0 5.0"
			"R 8000 1.0 0.5 5.0"
			"T 18000 12.0 5.5 1.0"
			"B 400 14.0 1.6 6.4"
			"P 11000 8.4 6.4 7.1"
			"B 50 2.5 6.5 4.1"
			"B 100 8.6 1.5 4.6"
			"R 5000 2.5 6.4 5.5"
			"T 1200 1.6 4.5 4.5"
			"--------------------------------------------------------------------"
			"2. Graphic configuration file"
			" - Start 1st line with \"Graphic\" identity"
			" - 2nd line to 6th line with Gain (-10.0 - 10.0) dB value"
			"Example:"
			"--------------------------------------------------------------------"
			"Graphic"
			"-8.0"
			"10.0"
			"0.0"
			"6.0"
			"-6.0"
			"--------------------------------------------------------------------"
"Capture configuration file example"
			"Parameters will be set in a row follow the order"
			"In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize"
			"Parameters meaning:"
			"In_fs           : Capture input sampling frequency(32000/44100/48000)." (*)
			"Out_fs          : Capture output sampling frequency (32000/44100/48000)." 
			"Dmach1          : Capture DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)"
			"Input1          : Capture input source 1(SSI10/SRC0 to SRC9)" 
			"Dmach2          : Capture DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)"
			"Input2          : Capture input source 2(SSI10/NONCONFIG). If Input1 is SSI10, this value must be NONCONFIG"
			"Volume          : Capture volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1)" (**)
			"Framesize       : Capture frame size(1024)" (***)
			"Example:"
			"--------------------------------------------------------------------"
			"32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI10 1 1024"
			"--------------------------------------------------------------------"
"Renderer configuration file example"
			"Parameters will be set in a row follow the order"
			"In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize"
			"Parameters meaning:"
			"In_fs           : Renderer input sampling frequency(32000/44100/48000)."
			"Out_fs          : Renderer output sampling frequency (32000/44100/48000)." (*)
			"Dmach1          : Renderer DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)"
			"Output1         : Renderer output source 1(SSI00/SRC0 to SRC9)" 
			"Dmach2          : Renderer DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)"
			"Output2         : Renderer output source 2(SSI00/NONCONFIG). If Output1 is SSI00, this value must be NONCONFIG"
			"Volume          : Renderer volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1)" (**)
			"Framesize       : Renderer frame size(1024)" (***)
			"In channel      : Number of Renderer input channels (1/2/4/6/8)"
			"Out channel     : Number of Renderer output channels (1/2)"
			"Mix control     : Renderer Mix enable control(0/1). (0 is disable MIX function, 1 is enable MIX function)" (**)
			"Example:"
			"--------------------------------------------------------------------"
			"32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI00 1 1024 2 2 0"
			"--------------------------------------------------------------------"

***********************************************************************************

Below command of Smoke-test program based on all use case of Renderer

=================================================================================================================
1.	Normal playback |
--------------------

Ex 1: Memory -> ADMAC -> SSI, 16 bit stereo, 32 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH01 SSI00 ADMACPP_CH00 NONCONFIG -1 1024 2 2 0

Ex 2: Memory -> ADMACpp -> SSI, 16 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_48000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 48000 ADMACPP_CH15 SSI00 ADMACPP_CH00 NONCONFIG -1 1024 2 2 0
    
Ex 3: Memory -> ADMAC -> SSI, 24 bit stereo, 44.1 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_44100_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    44100 44100 ADMAC_CH01 SSI00 ADMACPP_CH00 NONCONFIG -1 1024 2 2 0

Ex 4: Memory -> ADMACpp -> SSI, 24 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_48000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 48000 ADMACPP_CH15 SSI00 ADMACPP_CH00 NONCONFIG -1 1024 2 2 0
=================================================================================================================
2.  Sampling Rate Conversion |
-----------------------------

Ex 1: Memory -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC.txt
    
    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 48000 ADMAC_CH10 SRC0 ADMAC_CH11 SSI00 -1 1024 2 2 0

Ex 2: Memory -> ADMAC -> SRC -> ADMACpp -> SSI, 16 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC.txt
    
    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 48000 ADMAC_CH10 SRC0 ADMACPP_CH01 SSI00 -1 1024 2 2 0

Ex 3: Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC.txt
    
    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 48000 ADMACPP_CH00 SRC0 ADMAC_CH11 SSI00 -1 1024 2 2 0

Ex 4: Memory -> ADMACpp -> SRC -> ADMACpp -> SSI, 16 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC.txt
    
    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 48000 ADMACPP_CH10 SRC0 ADMACPP_CH11 SSI00 -1 1024 2 2 0
=================================================================================================================
3.  Channel Transfer |
---------------------
Ex 1: Memory -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit, downmixing 8 channel to 2 channel
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_8ch_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH15 SRC1 ADMAC_CH00 SSI00 -1 1024 8 2 0

Ex 2: Memory -> ADMAC -> SRC -> ADMACpp -> SSI, 24 bit, downmixing 8 channel to 2 channel
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_8ch_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH15 SRC1 ADMACPP_CH00 SSI00 -1 1024 8 2 0

Ex 3: Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 16 bit, downmixing 8 channel to 2 channel
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_8ch_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH15 SRC1 ADMAC_CH00 SSI00 -1 1024 8 2 0

Ex 4: Memory -> ADMACpp -> SRC -> ADMACpp -> SSI, 24 bit, downmixing 8 channel to 2 channel
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_8ch_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH15 SRC1 ADMACPP_CH00 SSI00 -1 1024 8 2 0
=================================================================================================================
4. Volume Control |
------------------

Ex 1: Memory -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH15 SRC0 ADMAC_CH00 SSI00 1.5 1024 2 2 0

Ex 2: Memory -> ADMAC -> SRC -> ADMACpp -> SSI, 16 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH15 SRC0 ADMACPP_CH00 SSI00 1.5 1024 2 2 0

Ex 3: Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH15 SRC0 ADMAC_CH00 SSI00 1.5 1024 2 2 0

Ex 4: Memory -> ADMACpp -> SRC -> ADMACpp -> SSI, 16 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:

    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI00 1.5 1024 2 2 0

=================================================================================================================
5. MIX function |
----------------
Ex 1: Mix 16 bit streams
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMACPP_1.txt
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC_2.txt
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_4ch_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMACPP_3.txt
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_6ch_32000_16.pcm -w 16 -o renderer 
    -rdr rdrconfig_ADMAC_4.txt

    Content of rdrconfig_ADMACPP_1.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH05 SRC0 ADMAC_CH00 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMAC_2.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH13 SRC5 ADMACPP_CH10 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMACPP_3.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH03 SRC1 ADMAC_CH04 SSI00 -1 1024 4 2 1

    Content of rdrconfig_ADMAC_4.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH06 SRC3 ADMAC_CH6 SSI00 -1 1024 6 2 1
    
Ex 2: Mix 24 bit streams
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMACPP_1.txt
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_s_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC_2.txt
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_4ch_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMACPP_3.txt                                            
    #./adsp-omx-launch -card plughw:0,4 -i thetest_FULL_6ch_32000_24.pcm -w 24 -o renderer 
    -rdr rdrconfig_ADMAC_4.txt

    Content of rdrconfig_ADMACPP_1.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH05 SRC0 ADMAC_CH00 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMAC_2.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH13 SRC5 ADMACPP_CH10 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMACPP_3.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH03 SRC1 ADMAC_CH04 SSI00 -1 1024 4 2 1

    Content of rdrconfig_ADMAC_4.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMAC_CH06 SRC3 ADMAC_CH6 SSI00 -1 1024 6 2 1

***********************************************************************************

Below command of Smoke-test program based on all use case of Capture

=================================================================================================================
1. Normal case |
---------------

Ex 1: Memory <- ADMAC <- SSI, 16 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    48000 48000 ADMAC_CH15 SSI10 ADMAC_CH00 NONCONFIG -1 1024

Ex 2: Memory <- ADMACpp <- SSI, 16 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    48000 48000 ADMACPP_CH15 SSI10 ADMAC_CH00 NONCONFIG -1 1024

Ex 3: Memory <- ADMAC <- SSI, 24 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    48000 48000 ADMAC_CH15 SSI10 ADMAC_CH00 NONCONFIG -1 1024

Ex 4: Memory <- ADMACpp <- SSI, 24 bit stereo, 48 kHz sample rate
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    48000 48000 ADMACPP_CH15 SSI10 ADMAC_CH00 NONCONFIG -1 1024

=================================================================================================================
2. Sampling Rate Conversion |
----------------------------
Ex 1: Memory <- ADMAC <- SRC <- ADMAC <- SSI, 24 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC0 ADMAC_CH00 SSI10 -1 1024

Ex 2: Memory <- ADMAC <- SRC <- ADMACpp <- SSI, 16 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC0 ADMACPP_CH00 SSI10 -1 1024

Ex 3: Memory <- ADMACpp <- SRC <- ADMAC <- SSI, 24 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC0 ADMAC_CH00 SSI10 -1 1024

Ex 4: Memory <- ADMACpp <- SRC <- ADMACpp <- SSI, 16 bit stereo, 32 kHz convert to 48 kHz
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI10 -1 1024

=================================================================================================================
3. Volume Control |
------------------
Ex 1: Memory <- ADMAC <- SRC <- ADMAC <- SSI, 24 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC0 ADMAC_CH00 SSI10 2 1024

Ex 2: Memory <- ADMAC <- SRC <- ADMACpp <- SSI, 16 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC0 ADMACPP_CH00 SSI10 2 1024

Ex 3: Memory <- ADMACpp <- SRC <- ADMAC <- SSI, 24 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 24 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC0 ADMAC_CH00 SSI10 2 1024

Ex 4: Memory <- ADMACpp <- SRC <- ADMACpp <- SSI, 16 bit, set volume is 1.5
    #./adsp-omx-launch -card plughw:0,4 -i capture -c 2 -w 16 -l 15 -o out.pcm -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI10 2 1024

***********************************************************************************

Below command of Smoke-test program based on all use case of Equalizer

=================================================================================================================
Ex 1: Setting by parametric
    #./adsp-omx-launch -i thetest_FULL_s_32000_16.pcm -w 16 -c 2 
    -o out.pcm -eq on -eqzfs 32000 -eqz parametric_config.txt
    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 2: Setting by graphic
    #./adsp-omx-launch -i thetest_FULL_s_32000_24.pcm -w 24 -c 2 
    -o out.pcm -eq on -eqzfs 32000 -eqz graphic_config.txt
    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0
***********************************************************************************

Below command of Smoke-test program based on all route case
(Note): When two or more components are routing, framesize of each component must be the same.
Besides Equalizer only supports 1024. So when routing with Equalizer only frame size 1024 is supported.
Other route case (Capture - Renderer) 1024/2048 are supported

=================================================================================================================

1. Capture - Equalizer |
-----------------------

Ex 1: Equalizer uses parametric, 24 bit data, use ADMAC connect memory to audio peripheral device
    #./adsp-omx-launch -o out.pcm -card plughw:0,4 -i capture -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 2: Equalizer uses graphic, 16 bit data, use ADMAC connect memory to audio peripheral device
    #./adsp-omx-launch -o out.pcm -card plughw:0,4 -i capture -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0
    
Ex 3: Equalizer uses parametric, 24 bit data, use ADMACPP connect memory to audio peripheral device
    #./adsp-omx-launch -o out.pcm -card plughw:0,4 -i capture -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 4: Equalizer uses graphic, 16 bit data, use ADMACPP connect memory to audio peripheral device
    #./adsp-omx-launch -o out.pcm -card plughw:0,4 -i capture -w 24 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0


=================================================================================================================
2. Equalizer - Renderer |
------------------------
Ex 1: Equalizer uses parametric, 24 bit data, use ADMAC connect memory to audio peripheral device
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_24.pcm -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 2: Equalizer uses graphic, 16 bit data, use ADMAC connect memory to audio peripheral device
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_16.pcm -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMAC.txt

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0

Ex 3: Equalizer uses parametric, 24 bit data, use ADMACPP connect memory to audio peripheral device
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_24.pcm -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 4: Equalizer uses graphic, 16 bit data, use ADMACPP connect memory to audio peripheral device
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_16.pcm -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP.txt

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0

=================================================================================================================
2. Capture - Equalizer - Renderer |
----------------------------------

Ex 1: SSI -> ADMAC -> SRC -> ADMAC -> Memory(EQZ processing) -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 2: SSI -> ADMACpp -> SRC -> ADMAC -> Memory(EQZ processing) -> ADMACpp -> SRC -> ADMAC -> SSI, 16 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0

Ex 3: SSI -> ADMAC -> SRC -> ADMACpp -> Memory(EQZ processing) -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 4: SSI -> ADMACpp -> SRC -> ADMACpp -> Memory(EQZ processing) -> ADMACpp -> SRC -> ADMACpp -> SSI, 16 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0
    
Ex 5: SSI -> ADMAC -> SRC -> ADMAC -> Memory(EQZ processing) -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 6: SSI -> ADMACpp -> SRC -> ADMAC -> Memory(EQZ processing) -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0

Ex 7: SSI -> ADMAC -> SRC -> ADMACpp -> Memory(EQZ processing) -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

Ex 8: SSI -> ADMACpp -> SRC -> ADMACpp -> Memory(EQZ processing) -> ADMACpp -> SRC -> ADMACpp -> SSI, 24 bit
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0
=================================================================================================================
2. Capture - Renderer |
----------------------
---------
Ex 1: SSI -> ADMAC -> SRC -> ADMAC -> Memory -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

Ex 2: SSI -> ADMAC -> SRC -> ADMACpp -> Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 16 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

Ex 3: SSI -> ADMAC -> SRC -> ADMACpp -> Memory -> ADMAC -> SRC -> ADMAC -> SSI, 16 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

Ex 4: SSI -> ADMAC -> SRC -> ADMAC -> Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 16 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 16 -c 2 -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0
    
Ex 5: SSI -> ADMAC -> SRC -> ADMAC -> Memory -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit, frame size 1024 
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

Ex 6: SSI -> ADMAC -> SRC -> ADMACpp -> Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMACPP_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMACPP_CH00 SSI00 0.5 1024 2 2 0

Ex 7: SSI -> ADMAC -> SRC -> ADMACpp -> Memory -> ADMAC -> SRC -> ADMAC -> SSI, 24 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -rdr rdrconfig_ADMAC.txt -cap capconfig_ADMACPP.txt

    Content of capconfig_ADMACPP.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMACPP_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMAC.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0

Ex 8: SSI -> ADMAC -> SRC -> ADMAC -> Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit, frame size 1024
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 1024

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 1024 2 2 0
    
Ex 9: SSI -> ADMAC -> SRC -> ADMAC -> Memory -> ADMACpp -> SRC -> ADMAC -> SSI, 24 bit, frame size 2048
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i capture -w 24 -c 2 -rdr rdrconfig_ADMACPP.txt -cap capconfig_ADMAC.txt

    Content of capconfig_ADMAC.txt:
    #In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize
    32000 48000 ADMAC_CH15 SRC6 ADMAC_CH04 SSI10 0.5 2048

    Content of rdrconfig_ADMACPP.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMACPP_CH25 SRC3 ADMAC_CH00 SSI00 0.5 2048 2 2 0
=================================================================================================================
2. Equalizer - Renderer use MIX function|
----------------------------------------
Ex 1: Mix 16 bit streams
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_32000_16.pcm -w 16 -c 2 -eqzfs 32000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP1.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_16.pcm -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMAC2.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_44100_16.pcm -w 16 -c 2 -eqzfs 44100 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMACPP3.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_16.pcm -w 16 -c 2 -eqzfs 48000 -eqz graphic_config.txt -eq on -rdr rdrconfig_ADMAC4.txt

    Content of rdrconfig_ADMACPP1.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH00 SRC0 ADMACPP_CH02 SSI00 0.5 1024 2 2 1

    Content of rdrconfig_ADMAC2.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH05 SRC1 ADMACPP_CH04 SSI00 1 1024 2 2 1

    Content of rdrconfig_ADMACPP3.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    44100 32000 ADMACPP_CH10 SRC3 ADMACPP_CH06 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMAC4.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH13 SRC5 ADMACPP_CH08 SSI00 2 1024 2 2 1

    Content of graphic_config.txt:
    Graphic
    -10.0
    -10.0
    -10.0
    -10.0
    -10.0

Ex 2: Mix 24 bit streams
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_32000_24.pcm -w 24 -c 2 -eqzfs 32000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMACPP1.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_24.pcm -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC2.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_44100_24.pcm -w 24 -c 2 -eqzfs 44100 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMACPP3.txt
    #./adsp-omx-launch -card plughw:0,4 -o renderer -i thetest_FULL_s_48000_24.pcm -w 24 -c 2 -eqzfs 48000 -eqz parametric_config.txt -eq on -rdr rdrconfig_ADMAC4.txt

    Content of rdrconfig_ADMACPP1.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    32000 32000 ADMACPP_CH00 SRC0 ADMACPP_CH02 SSI00 0.5 1024 2 2 1

    Content of rdrconfig_ADMAC2.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH05 SRC1 ADMACPP_CH04 SSI00 1 1024 2 2 1

    Content of rdrconfig_ADMACPP3.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    44100 32000 ADMACPP_CH10 SRC3 ADMACPP_CH06 SSI00 -1 1024 2 2 1

    Content of rdrconfig_ADMAC4.txt:
    # In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize In_ch Out_ch Mix_ctrl
    48000 32000 ADMAC_CH13 SRC5 ADMACPP_CH08 SSI00 2 1024 2 2 1

    Content of parametric_config.txt:
    Parametric
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0
    T 15000 0.707 1.0 1.0

