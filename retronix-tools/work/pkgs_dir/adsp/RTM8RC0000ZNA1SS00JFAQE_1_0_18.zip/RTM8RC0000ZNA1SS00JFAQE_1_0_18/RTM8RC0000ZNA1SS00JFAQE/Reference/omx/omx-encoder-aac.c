/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-encoder-aac.c
 *
 * OMX IL component for Xtensa HiFi2 AAC encoder
 ******************************************************************************/

#define MODULE_TAG                      XA_AACENC

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa_aac_enc_api.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);
TRACE_TAG(TS, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

typedef struct XAOMXAacEncoder
{
    /* ...generic codec structure */
    XAOMXCodecBase                  base;

    /* ...PCM-specific parameters (input port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

    /* ...AAC-specific parameters (output port) */
    OMX_AUDIO_PARAM_AACPROFILETYPE  sAAC;

    /* ...encoded frame duration */
    OMX_TICKS                       nFrameDuration;

    /* ...extra-configuration request */
    OMX_U32                         config;

}   XAOMXAacEncoder;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/* ...total amount of input buffers */
#define NUM_INPUT_BUFFERS               4

/* ...total amount of output buffers (during flush we do not have available output buffers, anyway) */
#define NUM_OUTPUT_BUFFERS              4

/* ...total amount of output buffers (during flush we do not have available output buffers, anyway) */
#define INPUT_BUFFER_LENGTH             4096

/* ...required data alignment */
#define BUFFER_ALIGNMENT                32

/* ...sampling rate index for AAC codec-specific info */
static const u32 xaomx_aac_encoder_rate_table[] = {
    96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000,
};

/*******************************************************************************
 * Low-level codec commands
 ******************************************************************************/

/* ...codec setup hook */
static int AACENC_CodecSetup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *)pBase;

    /* ...prepare parameters to set */
    msg->item[0].id = XA_AACENC_CONFIG_PARAM_PCM_WDSZ;
    msg->item[0].value = pData->sPCM.nBitPerSample;

    msg->item[1].id = XA_AACENC_CONFIG_PARAM_SAMP_FREQ;
    msg->item[1].value = pData->sAAC.nSampleRate;

    msg->item[2].id = XA_AACENC_CONFIG_PARAM_NUM_CHANNELS;
    msg->item[2].value = pData->sAAC.nChannels;

    msg->item[3].id = XA_AACENC_CONFIG_PARAM_BITRATE;
    msg->item[3].value = pData->sAAC.nBitRate;

    msg->item[4].id = XA_AACENC_CONFIG_PARAM_USE_ADIF;
    msg->item[4].value = 1;

    /* ...return number of parameters to set */
    return 5;
}

/* ...codec runtime initialization hook */
static int AACENC_CodecRuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *)pBase;
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;

    /* ...initialize the audio parameters for output port */
    pBase->sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pBase->sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pBase->sPortDef[1].nBufferSize = msg->output_length;
    pBase->sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;

    /* ...update parameters requiring port reconfiguration */
    pData->sAAC.nSampleRate = msg->sample_rate;
    pData->sAAC.nChannels = msg->channels;

    /* ...prepare parameters to get (that flag is not needed at all) */
    get->c.id[0] = XA_AACENC_CONFIG_PARAM_DNSAMP_FLAG;

    /* ...return number of parameters we are querying */
    return 1;
}

/* ...process output stream parameters */
static int AACENC_CodecGetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, unsigned length)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *) pBase;

    /* ...check the message length is correct */
    XF_CHK_ERR(length == sizeof(*msg) * 1, -EBADF);

    /* ...just output parameters retrieved (TBD) */
    TRACE(INIT, _b("AAC encoder parameters: downsampling = %u"), msg->r.value[0]);

    /* ...mark we want to strip ADIF header and to pass configuration data in first buffer */
    pData->config = 1;

    return 0;
}

/* ...timestamp advance function */
static void AACENC_CodecTimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *) pBase;

    if (pData->config) {
        u8     *buffer = (u8 *)  pBufHdr->pBuffer;
        u32     n = (pBase->sPortDef[0].nBufferSize * 8) / (pData->sPCM.nBitPerSample * pData->sPCM.nChannels);
        u8      index;

        /* ...first buffer is ADIF header; drop it */
        pBufHdr->nFlags = OMX_BUFFERFLAG_ENDOFFRAME | OMX_BUFFERFLAG_CODECCONFIG;

        /* ...determine rate index */
        for (index = 0; index < sizeof(xaomx_aac_encoder_rate_table) / sizeof(xaomx_aac_encoder_rate_table[0]); index++)
            if (xaomx_aac_encoder_rate_table[index] == pData->sAAC.nSampleRate)
                break;

        if (index != sizeof(xaomx_aac_encoder_rate_table) / sizeof(xaomx_aac_encoder_rate_table[0])) {
            TRACE(ERROR, _b("Invalid AAC rate index: %u"), index);
            return;
        }

        /* ...fill-in configuration-specific data */
        buffer[0] = ((0x02 << 3) | (index >> 1));
        buffer[1] = ((index & 0x01) << 7) | (pData->sAAC.nChannels << 3);

        TRACE(TS, _b("ADIF header passed (2 bytes (header: %d))"), (int) pBufHdr->nFilledLen);

        /* ...set total amount of bytes in buffer */
        pBufHdr->nFilledLen = 2;

        /* ...calculate the length of audio frame in usecs */
        pData->nFrameDuration = (1000000U * n) / pData->sPCM.nSamplingRate;

        /* ...reset first buffer flag */
        pData->config = 0;
    }
    else {
        /* ...set current timestamp to the buffer */
        pBufHdr->nTimeStamp = pBase->nTimeStamp;

        /* ...and advance the timestamp for next frame (not really accurate yet) */
        pBase->nTimeStamp += pData->nFrameDuration;

        TRACE(TS, _b("%d:%lu"), (int) pBufHdr->nFilledLen, (unsigned long) pBase->nTimeStamp);
    }
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/* ...get parameter */
static OMX_ERRORTYPE AACENC_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioAac:
    {
        /* ...return OMX_AUDIO_AACPROFILETYPE structure */
        OMX_AUDIO_PARAM_AACPROFILETYPE *param = (OMX_AUDIO_PARAM_AACPROFILETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sAAC.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sAAC, sizeof(*param));

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPcm:
    {
        /* ...return OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...set parameter */
static OMX_ERRORTYPE AACENC_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioPcm:
    {
        /* ...set OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sPCM, param, sizeof(*param));

        TRACE(INIT, _b("PCM parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sPCM.nChannels);
        TRACE(INIT, _b("Bits per sample:    %lu"), pData->sPCM.nBitPerSample);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sPCM.nSamplingRate);

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioAac:
    {
        /* ...set OMX_AUDIO_PARAM_AACPROFILETYPE structure */
        OMX_AUDIO_PARAM_AACPROFILETYPE *param = (OMX_AUDIO_PARAM_AACPROFILETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sAAC.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sAAC, param, sizeof(*param));

        TRACE(INIT, _b("AAC parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sAAC.nChannels);
        TRACE(INIT, _b("Bitrate:            %lu"), pData->sAAC.nBitRate);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sAAC.nSampleRate);
        TRACE(INIT, _b("Channel mode:       %u"),  pData->sAAC.eChannelMode);
        TRACE(INIT, _b("AAC profile:        %u"),  pData->sAAC.eAACProfile);
        TRACE(INIT, _b("AAC stream format:  %u"),  pData->sAAC.eAACStreamFormat);

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...component destructor */
static OMX_ERRORTYPE AACENC_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);

    TRACE(INIT, _b("AAC encoder component destroyed"));

    return OMX_ErrorNone;
}

/* ...component instantiation function */
static OMX_ERRORTYPE AACENC_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent,  OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXAacEncoder    *pData = (XAOMXAacEncoder *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_encoder.aac", "audio-encoder/aac"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.xa.aac.encoder";
    pData->base.SetParameter = AACENC_SetParameter;
    pData->base.GetParameter = AACENC_GetParameter;
    pData->base.CodecSetup = AACENC_CodecSetup;
    pData->base.CodecRuntimeInit = AACENC_CodecRuntimeInit;
    pData->base.CodecGetParam = AACENC_CodecGetParam;
    pData->base.CodecTimeStamp = AACENC_CodecTimeStamp;

    /* ...override component interface */
    pComp->ComponentDeInit = AACENC_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_LENGTH;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...initialize the audio parameters for output port (format only) */
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingAAC;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "audio/aac";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_TRUE;

    /* ...initialize the compression format for ouput port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioAac;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingAAC;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 0;
    pData->sPCM.nChannels = 2;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    /* ...AAC format defaults */
    XAOMX_INIT_STRUCT(&pData->sAAC, OMX_AUDIO_PARAM_AACPROFILETYPE);
    pData->sAAC.nPortIndex = 1;
    pData->sAAC.nChannels = 2;
    pData->sAAC.nSampleRate = 44100;
    pData->sAAC.nBitRate = 0;
    pData->sAAC.eChannelMode = OMX_AUDIO_ChannelModeStereo;
    pData->sAAC.eAACProfile = OMX_AUDIO_AACObjectLC;
    pData->sAAC.eAACStreamFormat = OMX_AUDIO_AACStreamFormatMP2ADTS;
    pData->sAAC.nFrameLength = 0;

    TRACE(INIT, _b("Encoder instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

OMX_ERRORTYPE AACENC_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp;
    XAOMXAacEncoder    *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    if ((pComp = calloc(1, sizeof(*pComp))) == NULL)
        goto error;

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    if ((pData = calloc(1, sizeof(*pData))) == NULL)
        goto error1;

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    if ((eError = AACENC_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks)) != OMX_ErrorNone)
        goto error2;

    TRACE(INIT, _b("AAC encoder initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error2:
    /* ...deallocate all component resources */
    AACENC_ComponentDeInit((OMX_HANDLETYPE)pComp);

    goto error;

error1:
    /* ...destroy component handle data */
    free(pComp);

error:
    TRACE(INIT, _b("AAC encoder component creation failed: %X"), eError);

    return eError;
}
