/** *****************************************************************************
  \file       xa-tdm-renderer-api.h
  \brief      Header file of TDM Renderer component
  \addtogroup ADSP Framework
 ********************************************************************************
  \date       Nov. 21, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * xa-tdm-renderer-api.h
 *
 * TDM Renderer component API
 ******************************************************************************/

#ifndef __XA_TDM_RENDERER_API_H__
#define __XA_TDM_RENDERER_API_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa_type_def.h"
#include "xa_error_standards.h"
#include "xa_apicmd_standards.h"
#include "xa_memory_standards.h"

/*******************************************************************************
 * Constants definitions
 ******************************************************************************/

/* Memory counter number */
#define XA_MEMCNT_PERSIST                   (1)                                 /**< persistent memory count    */
#define XA_MEMCNT_SCRATCH                   (1)                                 /**< scratch memory count       */
#define XA_MEMCNT_INPUT                     (4)                                 /**< input memory count         */
#define XA_MEMCNT_DTCM                      (1)                                 /**< dtcm memory count          */
#define XA_MEMCNT_BTM                       (1)                                 /**< descriptor memory count    */

/* Memory index */
#define XA_MEMIDX_INPUT1                    (0)                                 /**< input1 memory index        */
#define XA_MEMIDX_INPUT2                    (1)                                 /**< input2 memory index        */
#define XA_MEMIDX_INPUT3                    (2)                                 /**< input3 memory index        */
#define XA_MEMIDX_INPUT4                    (3)                                 /**< input4 memory index        */
#define XA_MEMIDX_PERSIST                   (4)                                 /**< persistent memory index    */
#define XA_MEMIDX_SCRATCH                   (5)                                 /**< Scratch memory index       */
#define XA_MEMIDX_DTCM                      (6)                                 /**< DTCM memory index          */
#define XA_MEMIDX_BTM                       (7)                                 /**< Built-in memory index      */

#define XA_TDM_RDR_GET_MEMTABS_IDX(N, IN_CNT)       ((N < IN_CNT) ? (N) : (N + XA_MEMCNT_INPUT - IN_CNT))      /**< Get memory table index  */

#define XA_GET_INBUF_IDX(N)                 (N - XA_MEMIDX_INPUT1)              /**< Get index of input buffer  */

/* ...tdm-renderer-specific configuration parameters */
enum xa_config_param_tdm_renderer {
    XA_TDM_RDR_CONFIG_PARAM_PCM_WIDTH       = 0,
    XA_TDM_RDR_CONFIG_PARAM_CHANNEL_MODE    = 1,
    XA_TDM_RDR_CONFIG_PARAM_IN_SAMPLE_RATE  = 2,
    XA_TDM_RDR_CONFIG_PARAM_FRAME_SIZE      = 3,
    XA_TDM_RDR_CONFIG_PARAM_OUTPUT1         = 4,
    XA_TDM_RDR_CONFIG_PARAM_DMACHANNEL1     = 5,
    XA_TDM_RDR_CONFIG_PARAM_OUTPUT2         = 6,
    XA_TDM_RDR_CONFIG_PARAM_DMACHANNEL2     = 7,
    XA_TDM_RDR_CONFIG_PARAM_OUT_SAMPLE_RATE = 8,
    XA_TDM_RDR_CONFIG_PARAM_VOLUME_RATE     = 9
};

enum xa_rel_tdm_renderer_channel_mode
{
    XA_TDM_RDR_CHANNEL_MODE_2X4             = 0,         /**< 4 stereo TDM data                           */
    XA_TDM_RDR_CHANNEL_MODE_1X8             = 1,         /**< 1 eight-channel TDM data                    */
    XA_TDM_RDR_CHANNEL_MODE_6_2             = 2,         /**< 1 six-channels plus 1 two-channels TDM data */
    XA_TDM_RDR_CHANNEL_MODE_2X3             = 3,         /**< 3 stereo TDM data                           */
    XA_TDM_RDR_CHANNEL_MODE_1X6             = 4          /**< 1 six-channel TDM data                      */
};

/* ...component identifier (informative) */
#define XA_CODEC_TDM_RDR                    (2)

/*******************************************************************************
 * Class 1: Configuration Errors
 ******************************************************************************/

#define XA_TDM_RDR_CONFIG_NONFATAL(e)  \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_TDM_RDR, (e))

#define XA_TDM_RDR_CONFIG_FATAL(e)     \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_TDM_RDR, (e))

enum xa_error_fatal_config_tdm_renderer {
    XA_TDM_RDR_CONFIG_FATAL_STATE           = XA_TDM_RDR_CONFIG_FATAL(0),
    XA_TDM_RDR_CONFIG_FATAL_PCM_WIDTH       = XA_TDM_RDR_CONFIG_FATAL(1),
    XA_TDM_RDR_CONFIG_FATAL_CHANNEL_MODE    = XA_TDM_RDR_CONFIG_FATAL(2),
    XA_TDM_RDR_CONFIG_FATAL_SAMPLE_RATE     = XA_TDM_RDR_CONFIG_FATAL(3),
    XA_TDM_RDR_CONFIG_FATAL_FRAME_SIZE      = XA_TDM_RDR_CONFIG_FATAL(4),
    XA_TDM_RDR_CONFIG_FATAL_INVALID_OUTPUT  = XA_TDM_RDR_CONFIG_FATAL(5),
    XA_TDM_RDR_CONFIG_FATAL_DMACHANNEL      = XA_TDM_RDR_CONFIG_FATAL(6),
    XA_TDM_RDR_CONFIG_FATAL_VOLUME_RATE     = XA_TDM_RDR_CONFIG_FATAL(7)
};

/*******************************************************************************
 * Class 2: Execution Class Errors
 ******************************************************************************/

#define XA_TDM_RDR_EXEC_NONFATAL(e)    \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_TDM_RDR, (e))

#define XA_TDM_RDR_EXEC_FATAL(e)       \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_TDM_RDR, (e))

enum xa_error_nonfatal_execute_tdm_renderer {
    XA_TDM_RDR_EXEC_NONFATAL_INPUT          = XA_TDM_RDR_EXEC_NONFATAL(0)
};

enum xa_error_fatal_execute_tdm_renderer {
    XA_TDM_RDR_EXEC_FATAL_STATE             = XA_TDM_RDR_EXEC_FATAL(0),
    XA_TDM_RDR_EXEC_FATAL_INPUT             = XA_TDM_RDR_EXEC_FATAL(1),
    XA_TDM_RDR_EXEC_FATAL_INTERNAL          = XA_TDM_RDR_EXEC_FATAL(2)
};

/*******************************************************************************
 * API entry point
 ******************************************************************************/
XA_ERRORCODE xa_rel_tdm_renderer(xa_codec_handle_t p_xa_module_obj, WORD32 i_cmd, WORD32 i_idx, pVOID pv_value);

/*******************************************************************************
 * API function definition (tbd)
 ******************************************************************************/

#if defined(USE_DLL) && defined(_WIN32)
#define DLL_SHARED __declspec(dllimport)
#elif defined (_WINDLL)
#define DLL_SHARED __declspec(dllexport)
#else
#define DLL_SHARED
#endif

#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */
DLL_SHARED xa_codec_func_t xa_rel_tdm_rdr;
#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_TDM_RENDERER_API_H__ */
