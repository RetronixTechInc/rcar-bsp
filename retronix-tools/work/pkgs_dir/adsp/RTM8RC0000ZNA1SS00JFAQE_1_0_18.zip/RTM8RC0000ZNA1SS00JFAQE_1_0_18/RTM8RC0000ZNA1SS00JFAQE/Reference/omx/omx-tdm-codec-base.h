/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-codec-base.h
 *
 * OMX IL component for Xtensa HiFi2 Audio codecs
 ******************************************************************************/

#ifndef __XA_OMX_TDM_CODEC_BASE_H
#define __XA_OMX_TDM_CODEC_BASE_H

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include <OMX_Component.h>

/*******************************************************************************
 * Types definitions
 ******************************************************************************/

/* ...max port of input/output */
#define XAOMX_PORT_MAX              (4)

/*******************************************************************************
 * XA_BUFFERLIST
 *
 * Buffers list
 ******************************************************************************/

typedef struct XA_BUFFERLIST {
    /* ...submitted buffers queue */
    OMX_BUFFERHEADERTYPE  **pPending;

    /* ...pointer to the first buffer submitted by client (oldest) */
    OMX_U32                 nHead;

    /* ...number of active (submitted to proxy) buffers */
    OMX_U32                 nActiveCount;

    /* ...number of pending (not yet submitted to proxy) buffers */
    OMX_U32                 nPendingCount;

    /* ...number of buffers owned by client buffers in the list */
    OMX_U32                 nUsedCount;

    /* ...total size of the queue */
    OMX_U32                 nQueueLength;

    /* ...proxy buffer pool */
    xf_pool_t              *pPool;

}   XA_BUFFERLIST;

/* ...base codec structure */
typedef struct XAOMXTDMCodecBase
{
    /***************************************************************************
     * OMX IL data
     **************************************************************************/

    /* ...OMX IL component handle */
    OMX_HANDLETYPE          hSelf;

    /* ...application callbacks */
    OMX_CALLBACKTYPE       *pCallbacks;

    /* ...application callback client data */
    OMX_PTR                 pAppData;

    /* ...component thread handle */
    pthread_t               thread_id;

    /* ...pipes for communication with thread */
    int                     command[2], response[2];

    /* ...serialization lock */
    pthread_mutex_t         mutex;

    /***************************************************************************
     * Interface definition
     **************************************************************************/

    /* ...component name */
    OMX_STRING              pComponentName;

    /* ...standard component role */
    OMX_STRING              cRole;

    /* ...codec-specific parameter set/get callbacks */
    OMX_ERRORTYPE         (*GetParameter)(struct XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
    OMX_ERRORTYPE         (*SetParameter)(struct XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam);

    /* ...output stream parameters processing */
    int                   (*CodecSetup)(struct XAOMXTDMCodecBase *pData, xf_set_param_msg_t *msg);
    int                   (*CodecRuntimeInit)(struct XAOMXTDMCodecBase *pData, xf_start_msg_t *msg);
    int                   (*CodecGetParam)(struct XAOMXTDMCodecBase *pData, xf_get_param_msg_t *msg, u32 length);
    void                  (*CodecBufferPreprocess)(struct XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr);
    void                  (*CodecTimeStamp)(struct XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr);

    /***************************************************************************
     * Xtensa Audio proxy driver interface
     **************************************************************************/

    /* ...component handle */
    xf_handle_t             handle;

    /* ...conditional variable for synchronous operations with proxy */
    pthread_cond_t          wait;
    
    /* ...mutex for synchronous operation completion */
    pthread_mutex_t         wait_lock;

    /***************************************************************************
     * Ports definition
     **************************************************************************/

    OMX_PORT_PARAM_TYPE             sPortParam;
    OMX_PARAM_PORTDEFINITIONTYPE    sPortDef[XAOMX_PORT_MAX + 1];
    OMX_AUDIO_PARAM_PORTFORMATTYPE  sPortFormat[XAOMX_PORT_MAX + 1];
    OMX_PRIORITYMGMTTYPE            sPriorityMgmt;

    /***************************************************************************
     * Tunneled data
     **************************************************************************/
    /** ...tunneled handle component */
    OMX_HANDLETYPE                  hTunnelComp[2];

    /** ...tunneled port index */
    OMX_U32                         nTunnelPort[2];

    /** ...buffer supplier structure */
    OMX_PARAM_BUFFERSUPPLIERTYPE    sSupplier[2];

    /** ...tunneled flag */
    OMX_U32                         nTunnelFlags[2];

    /***************************************************************************
     * Internal data
     **************************************************************************/

    /* ...control state-machine flags */
    u32                     eos_codec;

    /* ...control port state flags */
    u32                     eos_port;

    /* ...current component state */
    OMX_STATETYPE           state;

    /* ...input/output ports buffers queues */
    XA_BUFFERLIST           sBufList[XAOMX_PORT_MAX + 1];

    /* ...pending port commands */
    OMX_COMMANDTYPE         nPortCommand[XAOMX_PORT_MAX + 1];

    /* ...target state for transition */
    OMX_STATETYPE           nTargetState;

    /* ...pending buffer marking request */
    OMX_MARKTYPE           *pMarkBuf;

    /* ...active marker data */
    OMX_PTR                 pMarkData;

    /* ...target recipient for active mark data */
    OMX_HANDLETYPE          hMarkTargetComponent;

    /* ...current playback timestamp */
    OMX_TICKS               nTimeStamp;

}   XAOMXTDMCodecBase;

/*******************************************************************************
 * Macros definitions
 ******************************************************************************/

/* ...initialize OMX structure in standard way */
#define XAOMX_INIT_STRUCT(p, name)              \
do {                                            \
    (p)->nSize = sizeof(name);                  \
    (p)->nVersion.s.nVersionMajor = 0x1;        \
    (p)->nVersion.s.nVersionMinor = 0x0;        \
    (p)->nVersion.s.nRevision = 0x0;            \
    (p)->nVersion.s.nStep = 0x0;                \
} while (0)

/* ...check OMX structure version compliance */
#define XAOMX_CHK_VERSION(p, name)                  \
do {                                                \
    if ((p)->nSize != sizeof(name)) {               \
        TRACE(ERROR, _x("bad size"));               \
        return OMX_ErrorBadParameter;               \
    }                                               \
    if (((p)->nVersion.s.nVersionMajor != 0x1) ||   \
        ((p)->nVersion.s.nVersionMinor != 0x0) ||   \
        ((p)->nVersion.s.nRevision != 0x0) ||       \
        ((p)->nVersion.s.nStep != 0x0)) {           \
        TRACE(ERROR, _x("bad version"));            \
        return OMX_ErrorVersionMismatch;            \
    }                                               \
} while (0)

/* ...standard way to execute "OMX_ERRORTYPE (*) (...)" function */
#define XAOMX_CHK_API(call)                     \
({                                              \
    OMX_ERRORTYPE   __error = (call);           \
    if (__error != OMX_ErrorNone) {             \
        TRACE(ERROR, _x("error: %X"), __error); \
        return  __error;                        \
    }                                           \
                                                \
    __error;                                    \
})

/* ...check for a bug */
#define XAOMX_BUG(error, format, ...)           \
({                                              \
    TRACE(ERROR, _x(format), ##__VA_ARGS__);    \
    return error;                               \
})

/*******************************************************************************
 * Public API
 ******************************************************************************/

/* ...component instantiation */
extern OMX_ERRORTYPE XAOMXTDM_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks, OMX_STRING cRole, xf_id_t id);

/* ...set codec parameters */
extern OMX_ERRORTYPE XAOMXTDM_CodecSetParam(XAOMXTDMCodecBase *pData, size_t length, OMX_ERRORTYPE *pError);

/* ...get codec parameters */
extern OMX_ERRORTYPE XAOMX_CodecGetParam(XAOMXTDMCodecBase *pData, void *message, size_t length);

/* ...component deletion */
extern OMX_ERRORTYPE XAOMXTDM_ComponentDeInit(OMX_HANDLETYPE hComponent);

#endif  /* __XA_OMX_CODEC_BASE_H */
