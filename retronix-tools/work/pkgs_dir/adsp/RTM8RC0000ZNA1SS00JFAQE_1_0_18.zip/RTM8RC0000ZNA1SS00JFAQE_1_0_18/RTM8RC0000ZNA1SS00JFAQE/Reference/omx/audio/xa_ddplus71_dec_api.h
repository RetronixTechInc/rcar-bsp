/*
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 */

#ifndef __XA_DDPLUS71_DEC_API_H__
#define __XA_DDPLUS71_DEC_API_H__

/*****************************************************************************/
/* Dolby Digital Plus 7.1 Decoder specific API definitions                   */
/*****************************************************************************/

#define XA_DDPLUS71_DEC_MAX_BLOCKS_PER_FRAME 6  /* # of blocks per frame */
#define XA_DDPLUS71_DEC_SAMPLES_PER_BLOCK 256
#define XA_DDPLUS71_DEC_MAX_PCM_CHANNELS 8
#define XA_DDPLUS71_DEC_MAXIPRGMS 2 /* max # of dual mono channels */

/* ddplus71_dec-specific configuration parameters */
enum xa_config_param_ddplus71_dec {
  XA_DDPLUS71_DEC_CONFIG_PARAM_CHANROUTING              = 0,
  XA_DDPLUS71_DEC_CONFIG_PARAM_NUM_OCH                  = 1,
  XA_DDPLUS71_DEC_CONFIG_PARAM_LFE_OUT                  = 2,
  XA_DDPLUS71_DEC_CONFIG_PARAM_OCFG                     = 3,
  XA_DDPLUS71_DEC_CONFIG_PARAM_STEREO_MODE              = 4,
  XA_DDPLUS71_DEC_CONFIG_PARAM_MONO_REP                 = 5,
  XA_DDPLUS71_DEC_CONFIG_PARAM_KARAC                    = 6,
  XA_DDPLUS71_DEC_CONFIG_PARAM_PCM_SCALE                = 7,
  XA_DDPLUS71_DEC_CONFIG_PARAM_DYNRNG_MODE              = 8,
  XA_DDPLUS71_DEC_CONFIG_PARAM_DYN_CUT_HI               = 9,
  XA_DDPLUS71_DEC_CONFIG_PARAM_DYN_BOOST_LO             = 10,
  XA_DDPLUS71_DEC_CONFIG_PARAM_QUITONERR                = 11,
  XA_DDPLUS71_DEC_CONFIG_PARAM_KARAC_PARAMPTR           = 12,
  XA_DDPLUS71_DEC_CONFIG_PARAM_ZERO_UNUSED_CHANS        = 13,

  XA_DDPLUS71_DEC_CONFIG_PARAM_SAMP_FREQ                = 50,
  XA_DDPLUS71_DEC_CONFIG_PARAM_DATA_RATE                = 51,
  XA_DDPLUS71_DEC_CONFIG_PARAM_ACMOD                    = 52,
  XA_DDPLUS71_DEC_CONFIG_PARAM_CHANMAP                  = 53,
  XA_DDPLUS71_DEC_CONFIG_PARAM_BSI                      = 54,  /* For Independent substream I0: Returns a pointer to the BSI structure as defined below. */
  XA_DDPLUS71_DEC_CONFIG_PARAM_DSUREXMOD                = 55,
  XA_DDPLUS71_DEC_CONFIG_PARAM_D0_BSI                   = 56,  /* For Dependent substream D0: Returns a pointer to the BSI structure as defined below. */



  XA_DDPLUS71_DEC_CONFIG_PARAM_FRAMESTART               = 100,
  XA_DDPLUS71_DEC_CONFIG_PARAM_FRAMEEND                 = 101,
};

/* commands */
#include "xa_apicmd_standards.h"

/* ddplus71_dec-specific commands */
/* (none) */

/* ddplus71_dec-specific command types */
/* (none) */

/* error codes */
#include "xa_error_standards.h"

#define XA_CODEC_DDPLUS71_DEC   11

/* ddplus71_dec-specific error codes */
/*****************************************************************************/
/* Class 0: API Errors                                                       */
/*****************************************************************************/
/* Non Fatal Errors */
/* Fatal Errors */
/* (none) */

/*****************************************************************************/
/* Class 1: Configuration Errors                                             */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_config_ddplus71_dec {
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_CHANROUTING           = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 0),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_NUM_OCH               = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 1),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_LFE_OUT               = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 2),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_OCFG                  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 3),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_STEREO_MODE           = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 4),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_MONO_REP              = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 5),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_KARAC                 = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 6),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_PCM_SCALE             = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 7),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_DYNRNG_MODE           = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 8),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_DYN_CUT_HI            = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 9),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_DYN_BOOST_LO          = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 10),

  XA_DDPLUS71_DEC_CONFIG_NONFATAL_ERR_SAMPRATE                  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 11),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_ERR_DATARATE                  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 12),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_ERR_ACMOD                     = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 13),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_ERR_CHANMAP                   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 14),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_GEN_STRM_POS          = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 15),

  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_FRAMESTART            = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 16),
  XA_DDPLUS71_DEC_CONFIG_NONFATAL_INVALID_FRAMEEND              = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 17),

  XA_DDPLUS71_DEC_CONFIG_NONFATAL_ERR_BSI                       = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 18),
};

/* Fatal Errors */
enum xa_error_fatal_config_ddplus71_dec {
  XA_DDPLUS71_DEC_CONFIG_FATAL_INVALID_CHANROUTING              = XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_DDPLUS71_DEC, 0),
};
/* None */

/*****************************************************************************/
/* Class 2: Execution Class Errors                                           */
/*****************************************************************************/
/* Nonfatal Errors */
enum xa_error_nonfatal_execute_ddplus71_dec {
 XA_DDPLUS71_DEC_EXECUTE_NONFATAL_ERR_INSUFFICIENT_DATA         = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 0),
 XA_DDPLUS71_DEC_EXECUTE_NONFATAL_ERR_BADFRAME                  = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 1),
 XA_DDPLUS71_DEC_EXECUTE_NONFATAL_ERR_BADSYNC                   = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 2),
 XA_DDPLUS71_DEC_EXECUTE_NONFATAL_ERR_RUNTIME_RESET             = XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 3)
};

/* Fatal Errors */
enum xa_error_fatal_execute_ddplus71_dec {
 XA_DDPLUS71_DEC_EXECUTE_FATAL_ERR_POSTCONFIG_INIT              = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 0),
 XA_DDPLUS71_DEC_EXECUTE_FATAL_ERR_INIT                         = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 1),
 XA_DDPLUS71_DEC_EXECUTE_FATAL_ERR_EXECUTE                      = XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_DDPLUS71_DEC, 2),
};

#include "xa_type_def.h"

/* Structure Details of the BSI structure for independent and dependent substreams */
typedef struct
{
        WORD16          bse_fscod;              /* sampling frequency code */
} xa_ddplus71_dec_gbl_samprate_t;

typedef struct
{
        WORD16          bse_cmixlev;            /* Center downmix level  */
        WORD16          bse_surmixlev;          /* Surround downmix level */
} xa_ddplus71_dec_bsi_dmixlevs_t;

typedef struct
{
        const UWORD16   *p_pkbuf;
        WORD16          pkbitptr;
        WORD16          pkdata;
} xa_ddplus71_dec_bsod_bstrm_t;

typedef struct
{
        WORD16          bse_dialnorm;   /* dialog normalization word (1+1) */
        WORD16          bse_compre;     /* heavy compression word exists */
        WORD16          bse_compr;      /* heavy compression word */
} xa_ddplus71_dec_drcd_frm_t;

typedef struct
{
        /* synchronization information */
        WORD16          bse_syncword;                   /* Synchronization word */
        WORD16          bse_crc1;                       /* First CRC word */
        xa_ddplus71_dec_gbl_samprate_t samprate;        /* Fscod and halfratecod */
        WORD16          bse_frmsizecod;                 /* Frame size code */

        /* bitstream information */
        WORD16          bse_bsid;                       /* Bitstream identification */
        WORD16          bse_bsmod;                      /* Bitstream mode */
        WORD16          bse_acmod;                      /* Audio coding mode */
        WORD16          bse_lfeon;                      /* Low freq effects chan flag */
        WORD16          nfchans;                        /* Derived # of full bw chans */
        WORD16          nchans;                         /* Derived # of channels */
        WORD16          niprgms;                        /* Derived # of independent programs */
        WORD16          karaokeflag;                    /* Derived karaoke flag */

        xa_ddplus71_dec_bsi_dmixlevs_t legacy_dmixlevs; /* Legacy downmix levels */
        WORD16          bse_dsurmod;                    /* Dolby surround mode  */
        xa_ddplus71_dec_drcd_frm_t frmdrc[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Dialnorm and compr (1+1) */
        xa_ddplus71_dec_drcd_frm_t extfrmdrc[XA_DDPLUS71_DEC_MAXIPRGMS]; /* External Dialnorm and compr (1+1) */
        WORD16          bse_langcode[XA_DDPLUS71_DEC_MAXIPRGMS];        /* Language code exists */
        WORD16          bse_langcod[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Language code */
        WORD16          bse_audprodie[XA_DDPLUS71_DEC_MAXIPRGMS];       /* Audio production info exists */
        WORD16          bse_mixlevel[XA_DDPLUS71_DEC_MAXIPRGMS];        /* Mixing level */
        WORD16          bse_roomtyp[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Room type */
        WORD16          bse_copyrightb;                 /* Copyright bit */
        WORD16          bse_origbs;                     /* Original bitstream flag */

        WORD16          bse_timecod1e;                  /* Time code first half exists */
        WORD16          bse_timecod1;                   /* Time code first half */
        WORD16          bse_timecod2e;                  /* Time code second half exists */
        WORD16          bse_timecod2;                   /* Time code second half*/

        /* extended bitstream information 1 */
        WORD16          bse_xbsi1e;                     /* Extra BSI1 info exists */
        WORD16          bse_dmixmod;                    /* Preferred dmxd_process mode */
        xa_ddplus71_dec_bsi_dmixlevs_t ltrt_dmixlevs;   /* Lt/Rt downmix levels  */
        xa_ddplus71_dec_bsi_dmixlevs_t loro_dmixlevs;   /* Lo/Ro downmix levels */
        WORD16          lxrxmixlevsd;                   /* Stereo downmix levels defined */
        WORD16          dmixmodd;                       /* Derived dmixmod defined */

        /* extended bitstream information 2 (system data) */
        WORD16          bse_xbsi2e;                     /* Extra BSI2 info exists */
        WORD16          bse_dsurexmod;                  /* Surround EX mode flag */
        WORD16          bse_dheadphonmod;               /* Dolby Headphone encoded flag */
        WORD16          bse_adconvtyp[XA_DDPLUS71_DEC_MAXIPRGMS];       /* Advanced converter flag */
        WORD16          bse_xbsi2;                      /* Reserved bsi parameters */
        WORD16          bse_encinfo;                    /* Encoder Information bit */
        WORD16          dsurexmodd;                     /* Derived dsurexmod defined */
        WORD16          dheadphonmodd;                  /* Derived dheadphonmod defined */

        WORD16          bse_addbsie;                    /* Additional bsi exists */
        WORD16          bse_addbsil;                    /* Additional bsi length */
        xa_ddplus71_dec_bsod_bstrm_t bstrm_addbsi;      /* Ptr to additional bsi */

        /* DDPlus bitstream information variables */
        WORD16          bse_strmtyp;                    /* Stream type */
        WORD16          bse_substreamid;                /* Sub-stream identification */
        WORD16          bse_frmsiz;                     /* Frame size (in 16-bit words) */
        WORD16          bse_fscod2;                     /* Sample rate code 2 (halfrate) */
        WORD16          bse_chanmape;                   /* Channel map exists flag */
        WORD16          bse_chanmap;                    /* Channel map data */
        WORD16          bse_mixmdate;                   /* Mixing metadata exists flag */
        WORD16          bse_lfemixlevcode;              /* LFE Mix Level Code exists flag */
        WORD16          bse_lfemixlevcod;               /* LFE Mix Level Code */
        WORD16          bse_pgmscle[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Program scale factor exists flags */
        WORD16          bse_pgmscl[XA_DDPLUS71_DEC_MAXIPRGMS];  /* Program scale factor */
        WORD16          bse_extpgmscle;                 /* External program scale factor exists flags */
        WORD16          bse_extpgmscl;                  /* External program scale factor exists */
        WORD16          bse_mixdef;                     /* Mix control type */
        WORD16          bse_mixdeflen;                  /* Lenght of mixing parameter data field */
        WORD16          bse_mixdata2e;                  /* Mixing data 2 exists */
        WORD16          bse_premixcmpsel;               /* Premix compression word select */
        WORD16          bse_drcsrc;                     /* Dynamic range control word source (external or current) */
        WORD16          bse_premixcmpscl;               /* Premix compression word scale factor */
        WORD16          bse_extpgmlscle;                /* External program left scale factor exists */
        WORD16          bse_extpgmcscle;                /* External program center scale factor exists */
        WORD16          bse_extpgmrscle;                /* External program right scale factor exists */
        WORD16          bse_extpgmlsscle;               /* External program left surround scale factor exists */
        WORD16          bse_extpgmrsscle;               /* External program right surround scale factor exists */
        WORD16          bse_extpgmlfescle;              /* External program LFE scale factor exists */
        WORD16          bse_extpgmlscl;                 /* External program left scale factor */
        WORD16          bse_extpgmcscl;                 /* External program center scale factor */
        WORD16          bse_extpgmrscl;                 /* External program right scale factor */
        WORD16          bse_extpgmlsscl;                /* External program left surround scale factor */
        WORD16          bse_extpgmrsscl;                /* External program right surround scale factor */
        WORD16          bse_extpgmlfescl;               /* External program LFE scale factor */
        WORD16          bse_dmixscle;                   /* Downmix scale factor exists */
        WORD16          bse_dmixscl;                    /* Downmix scale factor */
        WORD16          bse_addche;                     /* Additional scale factors exist */
        WORD16          bse_extpgmaux1scle;             /* External program 1st auxiliary channel scale factor exists */
        WORD16          bse_extpgmaux1scl;              /* External program 1st auxiliary channel scale factor */
        WORD16          bse_extpgmaux2scle;             /* External program 2nd auxiliary channel scale factor exists */
        WORD16          bse_extpgmaux2scl;              /* External program 2nd auxiliary channel scale factor */
        WORD16          bse_frmmixcfginfoe;             /* Frame mixing configuration information exists flag */
        WORD16          bse_blkmixcfginfoe;             /* Block mixing configuration information exists flag */
        WORD16          bse_blkmixcfginfo[XA_DDPLUS71_DEC_MAX_BLOCKS_PER_FRAME]; /* Block mixing configuration information */
        WORD16          bse_paninfoe[XA_DDPLUS71_DEC_MAXIPRGMS];        /* Pan information exists flag */
        WORD16          bse_panmean[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Pan mean angle data */
        WORD16          bse_paninfo[XA_DDPLUS71_DEC_MAXIPRGMS]; /* Pan information */
        WORD16          bse_infomdate;                  /* Information Meta-Data exists flag */
        WORD16          bse_sourcefscod;                /* Source sample rate code */
        WORD16          bse_convsync;                   /* Converter synchronization flag */
        WORD16          bse_blkid;                              /* Block identification */

        /* Derived variables */
        WORD16          blks_per_frm;                   /* Number of blocks per frame */
} xa_ddplus71_dec_bsi_t;


#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */

xa_codec_func_t xa_ddplus71_dec;

#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_DDPLUS71_DEC_API_H__ */
