/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-decoder-aac.c
 *
 * OMX IL component for Xtensa HiFi2 AAC decoder
 ******************************************************************************/

#define MODULE_TAG                      XA_AACDEC

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa_aac_dec_api.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * AAC decoder (both AAC-LC and HE-AAC)
 ******************************************************************************/

typedef struct XAOMXAacDecoder
{
    /* ...generic codec structure */
    XAOMXCodecBase                  base;

    /* ...AAC-specific parameters (input port) */
    OMX_AUDIO_PARAM_AACPROFILETYPE  sAAC;

    /* ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

    /* ...length of the sample in bytes */
    u8                              nPCMWidth;

    /* ...total amount of output channels present in the chunk */
    u8                              nChannels;

    /* ...left/right channel indices in the output sample */
    u8                              iChannel[2];

}   XAOMXAacDecoder;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/* ...total amount of input buffers */
#define NUM_INPUT_BUFFERS               4

/* ...default input buffer length */
#define INPUT_BUFFER_LENGTH             4096

/* ...total amount of output buffers */
#define NUM_OUTPUT_BUFFERS              4

/* ...default input buffer length */
#define OUTPUT_BUFFER_LENGTH            4096

/* ...required data alignment */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Low-level codec commands
 ******************************************************************************/

/* ...channel mapping from decoder to OMX indices */
static const u8 aacdec_channel_route[8] = {
    /* ...left-front */
    OMX_AUDIO_ChannelLF,
    /* ...center-front */
    OMX_AUDIO_ChannelCF,
    /* ...right-front */
    OMX_AUDIO_ChannelRF,
    /* ...left-rear */
    OMX_AUDIO_ChannelLR,
    /* ...right-rear */
    OMX_AUDIO_ChannelRR,
    /* ...left-surround */
    OMX_AUDIO_ChannelLS,
    /* ...right-surround */
    OMX_AUDIO_ChannelRS,
    /* ...low-frequency effects */
    OMX_AUDIO_ChannelLFE,
};

/* ...codec setup hook */
static int AACDEC_CodecSetup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *)pBase;
    u32                 nChannels = pData->sAAC.nChannels;

    /* ...prepare parameters to set */
    msg->item[0].id = XA_AACDEC_CONFIG_PARAM_PCM_WDSZ;
    msg->item[0].value = 16;

    /* ...specify total amount of output channels (mono is by default expanded to stereo) */
    msg->item[1].id = XA_AACDEC_CONFIG_PARAM_OUTNCHANS;
    msg->item[1].value = (nChannels == 1 ? 2 : nChannels);

    /* ...setup parameers basing on stream format */
    if (pData->sAAC.eAACStreamFormat == OMX_AUDIO_AACStreamFormatRAW) {
        /* ...set external sampling rate */
        msg->item[2].id = XA_AACDEC_CONFIG_PARAM_EXTERNALSAMPLINGRATE;
        msg->item[2].value = pData->sAAC.nSampleRate;

        /* ...specify we have RAW header-less format */
        msg->item[3].id = XA_AACDEC_CONFIG_PARAM_EXTERNALBSFORMAT;
        msg->item[3].value = XA_AACDEC_EBITSTREAM_TYPE_AAC_RAW;

        /* ...return number of parameters we want to set */
        return XF_SET_PARAM_CMD_LEN(4);
    }
    else {
        /* ...try to determine stream format automatically (ADTS or ADIF) */
        return XF_SET_PARAM_CMD_LEN(2);
    }
}

/* ...codec runtime initialization hook */
static int AACDEC_CodecRuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *)pBase;
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;

    TRACE(INIT, _b("AAC stream prepared: f=%u, c=%u, w=%u, i=%u, o=%u"), msg->sample_rate, msg->channels, msg->pcm_width, msg->input_length, msg->output_length);

    /* ...update parameters requiring port reconfiguration */
    pData->sPCM.nSamplingRate = msg->sample_rate;
    pData->nChannels = msg->channels;
    pData->nPCMWidth = (msg->pcm_width == 16 ? 2 : 4);

    /* ...prepare parameters to get */
    get->c.id[0] = XA_AACDEC_CONFIG_PARAM_CHANMAP;

    /* ...return total number of parameters we query */
    return XF_GET_PARAM_CMD_LEN(1);
}

/* ...process output stream parameters */
static int AACDEC_CodecGetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *get, u32 length)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *) pBase;
    u32                 chmap;
    u8                  ch;

    /* ...check the message length is correct */
    XF_CHK_ERR(length == XF_GET_PARAM_RSP_LEN(1), -EBADF);

    /* ...save total amount of output channels */
    chmap = get->r.value[0];
    
    /* ...dump effective stream parameters */
    TRACE(INIT, _b("AAC stream parameters"));
    TRACE(INIT, _b("Channel map:        %X"), chmap);
    TRACE(INIT, _b("Out channels:       %X"), pData->nChannels);
    TRACE(INIT, _b("PCM width:          %u"), pData->nPCMWidth);
    TRACE(INIT, _b("Number of channels: %u"), pData->sPCM.nChannels);
    TRACE(INIT, _b("Sampling rate:      %u"), pData->sPCM.nSamplingRate);

    /* ...save indices of left and right channels (shall be rewritten for true multi-channel case) */
    for (ch = 0; ch < pData->nChannels; ch++, chmap >>= 4) {
        if ((chmap & 0xF) == 0)
            pData->iChannel[0] = ch;
        else if ((chmap & 0xF) == 2)
            pData->iChannel[1] = ch;
    }

    return 0;
}

/* ...timestamp advance function */
static void AACDEC_CodecTimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *) pBase;
    u32                 length = pBufHdr->nFilledLen;
    u8                  chunk = pData->nChannels * pData->nPCMWidth;
    u32                 n = length / chunk;
    u16                *pos_out = (u16 *)pBufHdr->pBuffer;
    u32                 i;

    /* ...manually remap output into stereo */
    if (pData->nPCMWidth == 2) {
        u16    *pos_in = (u16 *)pBufHdr->pBuffer;
        u16     left, right;

        for (i = 0; i < n; i++, pos_in += pData->nChannels) {
            left = pos_in[pData->iChannel[0]];
            right = pos_in[pData->iChannel[1]];
            
            *pos_out++ = left;
            *pos_out++ = right;
        }
    }
    else {
        u32    *pos_in = (u32 *)pBufHdr->pBuffer;
        u32     left, right;

        for (i = 0; i < n; i++, pos_in += pData->nChannels) {
            left = pos_in[pData->iChannel[0]];
            right = pos_in[pData->iChannel[1]];

            *pos_out++ = (u16)(left >> 16);
            *pos_out++ = (u16)(right >> 16);
        }
    }

    /* ...adjust buffer filled length (stereo, 16bpp) */
    pBufHdr->nFilledLen = n * 2 * 2;

    /* ...set current timestamp  */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...update reference timestamp (not really accurate) */
    pBase->nTimeStamp += (n * 1000000U) / pData->sPCM.nSamplingRate;;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/* ...get parameter */
static OMX_ERRORTYPE AACDEC_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioAac:
    {
        /* ...gets OMX_AUDIO_AACPROFILETYPE structure */
        OMX_AUDIO_PARAM_AACPROFILETYPE *param = (OMX_AUDIO_PARAM_AACPROFILETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sAAC.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sAAC, sizeof(*param));

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPcm:
    {
        /* ...get OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...set parameter */
static OMX_ERRORTYPE AACDEC_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioAac:
    {
        /* ...set OMX_AUDIO_PARAM_AACPROFILETYPE structure */
        OMX_AUDIO_PARAM_AACPROFILETYPE *param = (OMX_AUDIO_PARAM_AACPROFILETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sAAC.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sAAC, param, sizeof(*param));

        TRACE(INIT, _b("AAC parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sAAC.nChannels);
        TRACE(INIT, _b("Bitrate:            %lu"), pData->sAAC.nBitRate);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sAAC.nSampleRate);
        TRACE(INIT, _b("Channel mode:       %u"),  pData->sAAC.eChannelMode);
        TRACE(INIT, _b("AAC profile:        %u"),  pData->sAAC.eAACProfile);
        TRACE(INIT, _b("AAC stream format:  %u"),  pData->sAAC.eAACStreamFormat);

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...component destructor */
static OMX_ERRORTYPE AACDEC_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *) pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);

    TRACE(INIT, _b("AAC decoder component destroyed"));

    return OMX_ErrorNone;
}

/* ...component constructor */
static OMX_ERRORTYPE AACDEC_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent,  OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXAacDecoder    *pData = (XAOMXAacDecoder *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_decoder.aac", "audio-decoder/aac"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.xa.aac.decoder";
    pData->base.SetParameter = AACDEC_SetParameter;
    pData->base.GetParameter = AACDEC_GetParameter;
    pData->base.CodecSetup = AACDEC_CodecSetup;
    pData->base.CodecRuntimeInit = AACDEC_CodecRuntimeInit;
    pData->base.CodecGetParam = AACDEC_CodecGetParam;
    pData->base.CodecTimeStamp = AACDEC_CodecTimeStamp;

    /* ...override component interface */
    //pComp->GetComponentVersion = AACDEC_GetComponentVersion;
    pComp->ComponentDeInit = AACDEC_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_LENGTH;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingAAC;
    pData->base.sPortDef[0].format.audio.cMIMEType = NULL;
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_TRUE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioAac;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingAAC;

    /* ...initialize the audio parameters for output port (format only) */
    pData->base.sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pData->base.sPortDef[1].nBufferSize = OUTPUT_BUFFER_LENGTH;
    pData->base.sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...AAC format defaults */
    XAOMX_INIT_STRUCT(&pData->sAAC, OMX_AUDIO_PARAM_AACPROFILETYPE);
    pData->sAAC.nPortIndex = 0;
    pData->sAAC.nChannels = 2;
    pData->sAAC.nSampleRate = 0;
    pData->sAAC.nBitRate = 0;
    pData->sAAC.eChannelMode = OMX_AUDIO_ChannelModeStereo;
#if XA_AACDEC_MCHV2
    pData->sAAC.eAACProfile = OMX_AUDIO_AACObjectHE_PS;
#else
    pData->sAAC.eAACProfile = OMX_AUDIO_AACObjectLC;
#endif
    pData->sAAC.eAACStreamFormat = OMX_AUDIO_AACStreamFormatMP2ADTS;
    pData->sAAC.nFrameLength = 2048;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 1;
    pData->sPCM.nChannels = 2;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    TRACE(INIT, _b("Decoder instantiated"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry point
 ******************************************************************************/

OMX_ERRORTYPE AACDEC_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp;
    XAOMXAacDecoder    *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    if ((pComp = calloc(1, sizeof(*pComp))) == NULL)
        goto error;

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    if ((pData = calloc(1, sizeof(*pData))) == NULL)
        goto error1;

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    if ((eError = AACDEC_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks)) != OMX_ErrorNone)
        goto error2;

    TRACE(INIT, _b("AAC decoder initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error2:
    /* ...deallocate all component resources */
    AACDEC_ComponentDeInit((OMX_HANDLETYPE)pComp);

    goto error;

error1:
    /* ...destroy component handle data */
    free(pComp);

error:
    TRACE(INIT, _b("AAC decoder component creation failed: %X"), eError);

    return eError;
}
