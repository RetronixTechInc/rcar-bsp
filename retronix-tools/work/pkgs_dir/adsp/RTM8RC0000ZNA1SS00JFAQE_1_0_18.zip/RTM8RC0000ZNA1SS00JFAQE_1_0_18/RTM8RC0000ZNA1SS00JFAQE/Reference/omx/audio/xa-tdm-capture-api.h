/** *****************************************************************************
  \file       xa-tdm-capture-api.h
  \brief      Header file of Capture component
  \addtogroup ADSP Framework
 ********************************************************************************
  \date       Nov. 21, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information
   of Renesas Electronics Corporation. They must be used and modified solely for
   the purpose for which it was furnished by Renesas Electronics Corporation.
   All part of them must not be reproduced nor disclosed to others in any form,
   without the prior written permission of Renesas Electronics Corporation.
 ********************************************************************************/

/*******************************************************************************
 * xa-tdm-capture-api.h
 *
 * TDM Capture component API
 ******************************************************************************/

#ifndef __XA_TDM_CAPTURE_API_H__
#define __XA_TDM_CAPTURE_API_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xa_type_def.h"
#include "xa_error_standards.h"
#include "xa_apicmd_standards.h"
#include "xa_memory_standards.h"

/*******************************************************************************
 * Constants definitions
 ******************************************************************************/

/* Memory counter number */
#define XA_MEMCNT_PERSIST                   (1)                                     /**< persistent memory block */
#define XA_MEMCNT_SCRATCH                   (1)                                     /**< stack memory block      */
#define XA_MEMCNT_OUTPUT                    (4)                                     /**< output memory block     */
#define XA_MEMCNT_DTCM                      (1)                                     /**< dtcm memory count       */
#define XA_MEMCNT_BTM                       (1)                                     /**< descriptor memory count */

/* Define memory block index*/
#define XA_MEMIDX_OUTPUT1                   (0)                                     /**< output1 memory index    */
#define XA_MEMIDX_OUTPUT2                   (1)                                     /**< output2 memory index    */
#define XA_MEMIDX_OUTPUT3                   (2)                                     /**< output3 memory index    */
#define XA_MEMIDX_OUTPUT4                   (3)                                     /**< output4 memory index    */
#define XA_MEMIDX_PERSIST                   (4)                                     /**< persistent memory index */
#define XA_MEMIDX_SCRATCH                   (5)                                     /**< scratch memory index    */
#define XA_MEMIDX_DTCM                      (6)                                     /**< DTCM memory index       */
#define XA_MEMIDX_BTM                       (7)                                     /**< Built-in memory index   */

#define XA_TDM_CAP_GET_MEMTABS_IDX(N, OUT_CNT)      ((N < OUT_CNT) ? (N) : (N + XA_MEMCNT_OUTPUT - OUT_CNT))      /**< Get memory table index  */

#define XA_GET_OUTBUF_IDX(N)                (N - XA_MEMIDX_OUTPUT1)                 /**< Get output index memory */

/* ...TDM Capture-specific configuration parameters */
enum xa_config_param_tdm_capture {
    XA_TDM_CAP_CONFIG_PARAM_PCM_WIDTH       = 0,
    XA_TDM_CAP_CONFIG_PARAM_CHANNEL_MODE    = 1,
    XA_TDM_CAP_CONFIG_PARAM_IN_SAMPLE_RATE  = 2,
    XA_TDM_CAP_CONFIG_PARAM_FRAME_SIZE      = 3,
    XA_TDM_CAP_CONFIG_PARAM_INPUT1          = 4,
    XA_TDM_CAP_CONFIG_PARAM_DMACHANNEL1     = 5,
    XA_TDM_CAP_CONFIG_PARAM_INPUT2          = 6,
    XA_TDM_CAP_CONFIG_PARAM_DMACHANNEL2     = 7,
    XA_TDM_CAP_CONFIG_PARAM_OUT_SAMPLE_RATE = 8,
    XA_TDM_CAP_CONFIG_PARAM_VOLUME_RATE     = 9
};

enum xa_rel_tdm_capture_channel_mode
{
    XA_TDM_CAP_CHANNEL_MODE_2X4             = 0,         /**< 4 stereo TDM data                           */
    XA_TDM_CAP_CHANNEL_MODE_1X8             = 1,         /**< 1 eight-channel TDM data                    */
    XA_TDM_CAP_CHANNEL_MODE_6_2             = 2,         /**< 1 six-channels plus 1 two-channels TDM data */
    XA_TDM_CAP_CHANNEL_MODE_2X3             = 3,         /**< 3 stereo TDM data                           */
    XA_TDM_CAP_CHANNEL_MODE_1X6             = 4          /**< 1 six-channel TDM data                      */
};

/* ...component identifier (informative) */
#define XA_CODEC_TDM_CAP                    (3)

/*******************************************************************************
 * Class Configuration Errors
 ******************************************************************************/

#define XA_TDM_CAP_CONFIG_NONFATAL(e)  \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_config, XA_CODEC_TDM_CAP, (e))

#define XA_TDM_CAP_CONFIG_FATAL(e)     \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_config, XA_CODEC_TDM_CAP, (e))

enum xa_error_fatal_config_tdm_capture {
    XA_TDM_CAP_CONFIG_FATAL_STATE           = XA_TDM_CAP_CONFIG_FATAL(0),
    XA_TDM_CAP_CONFIG_FATAL_PCM_WIDTH       = XA_TDM_CAP_CONFIG_FATAL(1),
    XA_TDM_CAP_CONFIG_FATAL_CHANNEL_MODE    = XA_TDM_CAP_CONFIG_FATAL(2),
    XA_TDM_CAP_CONFIG_FATAL_SAMPLE_RATE     = XA_TDM_CAP_CONFIG_FATAL(3),
    XA_TDM_CAP_CONFIG_FATAL_FRAME_SIZE      = XA_TDM_CAP_CONFIG_FATAL(4),
    XA_TDM_CAP_CONFIG_FATAL_INVALID_INPUT   = XA_TDM_CAP_CONFIG_FATAL(5),
    XA_TDM_CAP_CONFIG_FATAL_DMACHANNEL      = XA_TDM_CAP_CONFIG_FATAL(6),
    XA_TDM_CAP_CONFIG_FATAL_VOLUME_RATE     = XA_TDM_CAP_CONFIG_FATAL(7)
};

/*******************************************************************************
 * Class 2: Execution Class Errors
 ******************************************************************************/

#define XA_TDM_CAP_EXEC_NONFATAL(e)    \
    XA_ERROR_CODE(xa_severity_nonfatal, xa_class_execute, XA_CODEC_TDM_CAP, (e))

#define XA_TDM_CAP_EXEC_FATAL(e)       \
    XA_ERROR_CODE(xa_severity_fatal, xa_class_execute, XA_CODEC_TDM_CAP, (e))

enum xa_error_nonfatal_execute_tdm_capture {
    XA_TDM_CAP_EXEC_NONFATAL_OUTPUT         = XA_TDM_CAP_EXEC_NONFATAL(0)
};

enum xa_error_fatal_execute_tdm_capture {
    XA_TDM_CAP_EXEC_FATAL_STATE             = XA_TDM_CAP_EXEC_FATAL(0),
    XA_TDM_CAP_EXEC_FATAL_INTERNAL          = XA_TDM_CAP_EXEC_FATAL(1)
};

/*******************************************************************************
 * API entry point
 ******************************************************************************/
XA_ERRORCODE xa_rel_tdm_capture(xa_codec_handle_t p_xa_module_obj, WORD32 i_cmd, WORD32 i_idx, pVOID pv_value);

/*******************************************************************************
 * API function definition (tbd)
 ******************************************************************************/

#if defined(USE_DLL) && defined(_WIN32)
#define DLL_SHARED __declspec(dllimport)
#elif defined (_WINDLL)
#define DLL_SHARED __declspec(dllexport)
#else
#define DLL_SHARED
#endif

#if defined(__cplusplus)
extern "C" {
#endif  /* __cplusplus */
DLL_SHARED xa_codec_func_t xa_rel_tdm_cap;
#if defined(__cplusplus)
}
#endif  /* __cplusplus */

#endif /* __XA_TDM_CAPTURE_API_H__ */
