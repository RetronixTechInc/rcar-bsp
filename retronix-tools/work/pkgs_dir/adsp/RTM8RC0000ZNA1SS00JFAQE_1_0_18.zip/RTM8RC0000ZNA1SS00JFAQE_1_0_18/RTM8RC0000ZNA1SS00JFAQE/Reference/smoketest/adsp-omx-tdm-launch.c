/** *****************************************************************************
  \addtogroup ADSP Smoketest Application
  \file       adsp-omx-tdm-launch.c
  \brief      Control of ADSP via ADSP Interface
 ********************************************************************************
  \date       Nov. 21, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation
 ********************************************************************************/
  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include <math.h>
#include <pthread.h>
#include <OMX_Core.h>
#include <OMX_Types.h>
#include <OMX_Index.h>
#include <OMX_Component.h>

#include "xa-omx-tdm-renderer.h"
#include "audio/xa-tdm-capture-api.h"
#include "audio/xa-tdm-renderer-api.h"
#ifdef TARGET_ANDROID
#include <tinyalsa/asoundlib.h>
#include <unistd.h>
#else
#include <alsa/asoundlib.h>
#endif

/* ...size of buffer to store read data from file */
#define MAX_LENGTH                      (40)

/* ...component is enabled */
#define ON                              (1)

/* ...component is disabled */
#define OFF                             (0)

/* ...number of buffers */
#define NUMBER_OF_BUFFERS               (4)

#define PORT_MAX                        (4)

/* ...status flag definition */
#define RENDERER_ON                     (1 << 0)
#define EQUALIZER_ON                    (1 << 1)
#define CAPTURE_ON                      (1 << 2)

#define CAPTURE_ENABLE(eos)             (eos & (CAPTURE_ON))
#define EQUALIZER_ENABLE(eos)           (eos & (EQUALIZER_ON))
#define RENDERER_ENABLE(eos)            (eos & (RENDERER_ON))

OMX_BUFFERHEADERTYPE	*bufin[PORT_MAX][NUMBER_OF_BUFFERS];
OMX_BUFFERHEADERTYPE	*bufou[PORT_MAX][NUMBER_OF_BUFFERS];

/* ...TEST_DATA structure with parameters to check */
typedef struct TEST_DATA {
    int     eos;
    char    *input_name[PORT_MAX];
    char    *output_name[PORT_MAX];
    int     time;
    int     channels;
    int     pwdsz;
    int     fs;
    int     ts;
    int     wav_length;
    int     ch_mod;
    int     port_total;
    /* OMX Component */
    OMX_HANDLETYPE                  pRenderer;
    OMX_HANDLETYPE                  pCapture;

    /* OMX Port definition */
    OMX_PARAM_PORTDEFINITIONTYPE    cap_inport_def;
    OMX_PARAM_PORTDEFINITIONTYPE    cap_outport_def[PORT_MAX];

    OMX_PARAM_PORTDEFINITIONTYPE    rdr_inport_def[PORT_MAX];
    OMX_PARAM_PORTDEFINITIONTYPE    rdr_outport_def;
} TEST_DATA;

/*******************************************************************************
 * Global variables and functions
 ******************************************************************************/
int queue_i[PORT_MAX];
int queue_o[PORT_MAX];
int queue_d[PORT_MAX];

int end, over;
int pluginerror;

pthread_mutex_t input_lock[PORT_MAX];
pthread_mutex_t output_lock[PORT_MAX];
pthread_mutex_t end_lock;

static OMX_ERRORTYPE cbEventHandler( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_EVENTTYPE eEvent, OMX_OUT OMX_U32 Data1, OMX_OUT OMX_U32 Data2, OMX_IN OMX_PTR pEventData )
{
    if (eEvent == OMX_EventError)
    {
        printf("Receive error from ADSP plug-in. Please check parameter setting again.\n");
        pluginerror = 1;
    }

    /* Event Handler for all component */
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbEmptyBufferDone_Rdr( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer)
{
    int idx = pBuffer->nInputPortIndex;

    pthread_mutex_lock(&input_lock[idx]);
    queue_i[idx]++;
    pthread_mutex_unlock(&input_lock[idx]);

    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbEmptyBufferDone_Cap( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer)
{
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbFillBufferDone_Cap( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    int idx = pBuffer->nOutputPortIndex - 1;

    pthread_mutex_lock(&output_lock[idx]);
    queue_d[idx]++;
    pthread_mutex_unlock(&output_lock[idx]);
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbFillBufferDone_Rdr( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    return OMX_ErrorNone;
}

static OMX_CALLBACKTYPE callbacks_Ren =
{
    .EventHandler = cbEventHandler,
    .EmptyBufferDone = cbEmptyBufferDone_Rdr,
    .FillBufferDone = cbFillBufferDone_Rdr,
};

static OMX_CALLBACKTYPE callbacks_Cap =
{
    .EventHandler = cbEventHandler,
    .EmptyBufferDone = cbEmptyBufferDone_Cap,
    .FillBufferDone = cbFillBufferDone_Cap,
};

#ifdef TARGET_ANDROID
static inline void alsa_close(struct pcm *alsa_handle)
{
    if(alsa_handle)
    {
        /* ...close ALSA handle */
        pcm_close(alsa_handle), alsa_handle = NULL;
    }
}
#else
static inline void alsa_close(snd_pcm_t *alsa_handle)
{
    if(alsa_handle)
    {
        /* ...close ALSA handle */
        snd_pcm_close(alsa_handle), alsa_handle = NULL;
    }
}
#endif

static OMX_ERRORTYPE get_and_wait_component_state(OMX_HANDLETYPE phandle, OMX_STATETYPE state)
{
    OMX_STATETYPE cur_state;

    while (1)
    {
        OMX_GetState(phandle, &cur_state);
        if( cur_state == state )
        {
            return OMX_ErrorNone;
        }
        else if (cur_state == OMX_StateInvalid)
        {
            /* return immediately when state changed to Invalid */
            break;
        }
    }

    return OMX_ErrorIncorrectStateTransition;
}

/*******************************************************************************
 * Main process: Process read files
 ******************************************************************************/

/*******************************************************************************
 * Input thread
 ******************************************************************************/
static void input_thread0(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    FILE *file;
    int count, size;
    int i, j;
    int port_idx = 0;
    OMX_ERRORTYPE err_code;

    file = fopen(pData->input_name[port_idx], "rb");

    if (!file)
        pthread_exit(NULL);

    queue_i[port_idx] = pData->rdr_inport_def[port_idx].nBufferCountActual;
    count = queue_i[port_idx];
    phandle = pData->pRenderer;

    i = 0;

    while(1)
    {
        if (pluginerror == 1) break;

        if (over == 1)
        {
            while(1)
            {
                pthread_mutex_lock(&input_lock[port_idx]);
                if(queue_i[port_idx] == count)
                {
                    pthread_mutex_unlock(&input_lock[port_idx]);
                    break;
                }
                pthread_mutex_unlock(&input_lock[port_idx]);

                if (pluginerror == 1) break;
            }
            break;
        }

        pthread_mutex_lock(&input_lock[port_idx]);
        if(queue_i[port_idx])
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
            pBuffer = bufin[port_idx][i++];

            pBuffer->nFilledLen += fread(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nAllocLen, file);

            if(pBuffer->nFilledLen == 0)
            {
                pBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
                over = 1;

                OMX_EmptyThisBuffer(phandle, pBuffer);
            }

            if (over == 0)
            {
                err_code = OMX_EmptyThisBuffer(phandle, pBuffer);

                if (err_code == OMX_ErrorNone)
                {
                    pthread_mutex_lock(&input_lock[port_idx]);
                    queue_i[port_idx]--;
                    pthread_mutex_unlock(&input_lock[port_idx]);
                }
            }

            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
        }
    }

    fclose(file);

    pthread_exit(NULL);
}

static void input_thread1(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    FILE *file;
    int count, size;
    int i, j;
    int port_idx = 1;
    OMX_ERRORTYPE err_code;

    file = fopen(pData->input_name[port_idx], "rb");

    if (!file)
        pthread_exit(NULL);

    queue_i[port_idx] = pData->rdr_inport_def[port_idx].nBufferCountActual;
    count = queue_i[port_idx];
    phandle = pData->pRenderer;

    i = 0;

    while(1)
    {
        if (pluginerror == 1) break;

        if (over == 1)
        {
            while(1)
            {
                pthread_mutex_lock(&input_lock[port_idx]);
                if(queue_i[port_idx] == count)
                {
                    pthread_mutex_unlock(&input_lock[port_idx]);
                    break;
                }
                pthread_mutex_unlock(&input_lock[port_idx]);

                if (pluginerror == 1) break;
            }
            break;
        }

        pthread_mutex_lock(&input_lock[port_idx]);
        if(queue_i[port_idx])
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
            pBuffer = bufin[port_idx][i++];

            pBuffer->nFilledLen += fread(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nAllocLen, file);

            if(pBuffer->nFilledLen == 0)
            {
                pBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
                over = 1;

                OMX_EmptyThisBuffer(phandle, pBuffer);
            }

            if (over == 0)
            {
                err_code = OMX_EmptyThisBuffer(phandle, pBuffer);

                if (err_code == OMX_ErrorNone)
                {
                    pthread_mutex_lock(&input_lock[port_idx]);
                    queue_i[port_idx]--;
                    pthread_mutex_unlock(&input_lock[port_idx]);
                }
            }

            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
        }
    }

    fclose(file);

    pthread_exit(NULL);
}

static void input_thread2(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    FILE *file;
    int count, size;
    int i, j;
    int port_idx = 2;
    OMX_ERRORTYPE err_code;

    file = fopen(pData->input_name[port_idx], "rb");

    if (!file)
        pthread_exit(NULL);

    queue_i[port_idx] = pData->rdr_inport_def[port_idx].nBufferCountActual;
    count = queue_i[port_idx];
    phandle = pData->pRenderer;

    i = 0;

    while(1)
    {
        if (pluginerror == 1) break;

        if (over == 1)
        {
            while(1)
            {
                pthread_mutex_lock(&input_lock[port_idx]);
                if(queue_i[port_idx] == count)
                {
                    pthread_mutex_unlock(&input_lock[port_idx]);
                    break;
                }
                pthread_mutex_unlock(&input_lock[port_idx]);

                if (pluginerror == 1) break;
            }
            break;
        }

        pthread_mutex_lock(&input_lock[port_idx]);
        if(queue_i[port_idx])
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
            pBuffer = bufin[port_idx][i++];

            pBuffer->nFilledLen += fread(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nAllocLen, file);

            if(pBuffer->nFilledLen == 0)
            {
                pBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
                over = 1;

                OMX_EmptyThisBuffer(phandle, pBuffer);
            }

            if (over == 0)
            {
                err_code = OMX_EmptyThisBuffer(phandle, pBuffer);

                if (err_code == OMX_ErrorNone)
                {
                    pthread_mutex_lock(&input_lock[port_idx]);
                    queue_i[port_idx]--;
                    pthread_mutex_unlock(&input_lock[port_idx]);
                }
            }

            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
        }
    }

    fclose(file);

    pthread_exit(NULL);
}

static void input_thread3(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    FILE *file;
    int count, size;
    int i, j;
    int port_idx = 3;
    OMX_ERRORTYPE err_code;

    file = fopen(pData->input_name[port_idx], "rb");

    if (!file)
        pthread_exit(NULL);

    queue_i[port_idx] = pData->rdr_inport_def[port_idx].nBufferCountActual;
    count = queue_i[port_idx];
    phandle = pData->pRenderer;

    i = 0;

    while(1)
    {
        if (pluginerror == 1) break;

        if (over == 1)
        {
            while(1)
            {
                pthread_mutex_lock(&input_lock[port_idx]);
                if(queue_i[port_idx] == count)
                {
                    pthread_mutex_unlock(&input_lock[port_idx]);
                    break;
                }
                pthread_mutex_unlock(&input_lock[port_idx]);

                if (pluginerror == 1) break;
            }
            break;
        }

        pthread_mutex_lock(&input_lock[port_idx]);
        if(queue_i[port_idx])
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
            pBuffer = bufin[port_idx][i++];

            pBuffer->nFilledLen += fread(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nAllocLen, file);

            if(pBuffer->nFilledLen == 0)
            {
                pBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
                over = 1;

                OMX_EmptyThisBuffer(phandle, pBuffer);
            }

            if (over == 0)
            {
                err_code = OMX_EmptyThisBuffer(phandle, pBuffer);

                if (err_code == OMX_ErrorNone)
                {
                    pthread_mutex_lock(&input_lock[port_idx]);
                    queue_i[port_idx]--;
                    pthread_mutex_unlock(&input_lock[port_idx]);
                }
            }

            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&input_lock[port_idx]);
        }
    }

    fclose(file);

    pthread_exit(NULL);
}

/*******************************************************************************
 * Output thread
 ******************************************************************************/
static void output_thread0(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    int i, j;
    FILE *file;
    int port_idx = 0;

    i = 0;
    j = 0;
    file = fopen(pData->output_name[port_idx], "wb");

    queue_o[port_idx] = pData->cap_outport_def[port_idx].nBufferCountActual;

    phandle = pData->pCapture;

    /* ...output to PCM file */
    while(1)
    {
        if (pluginerror == 1) break;

        if(queue_o[port_idx])
        {
            pBuffer = bufou[port_idx][i];

            if (end == 0)
                OMX_FillThisBuffer(phandle, pBuffer);

            queue_o[port_idx]--;

            i++;
            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }

        pthread_mutex_lock(&output_lock[port_idx]);
        if(queue_d[port_idx])
        {
            pthread_mutex_unlock(&output_lock[port_idx]);
            pBuffer = bufou[port_idx][j];

            fwrite(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nFilledLen, file);

            pthread_mutex_lock(&output_lock[port_idx]);
            queue_d[port_idx]--;
            pthread_mutex_unlock(&output_lock[port_idx]);

            if ((pBuffer->nFlags & OMX_BUFFERFLAG_EOS) && (queue_d[port_idx] == 0))
                break;

            queue_o[port_idx]++;

            j++;
            if(j >= NUMBER_OF_BUFFERS)
            {
                j = 0;
            }
        }
        else
            pthread_mutex_unlock(&output_lock[port_idx]);

        pthread_mutex_lock(&end_lock);
        if (end == 1)
        {
            pthread_mutex_unlock(&end_lock);

            pthread_mutex_lock(&output_lock[port_idx]);
            if (queue_d[port_idx] == 0)
            {
                pthread_mutex_unlock(&output_lock[port_idx]);
                break;
            }
            pthread_mutex_unlock(&output_lock[port_idx]);
        }
        pthread_mutex_unlock(&end_lock);
    }

    fclose(file);

    pthread_exit(NULL);
}

static void output_thread1(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    int i, j;
    FILE *file;
    int port_idx = 1;

    i = 0;
    j = 0;

    file = fopen(pData->output_name[port_idx], "wb");

    queue_o[port_idx] = pData->cap_outport_def[port_idx].nBufferCountActual;

    phandle = pData->pCapture;

    /* ...output to PCM file */
    while(1)
    {
        if (pluginerror == 1) break;

        if(queue_o[port_idx])
        {
            pBuffer = bufou[port_idx][i];

            if (end == 0)
                OMX_FillThisBuffer(phandle, pBuffer);

            queue_o[port_idx]--;

            i++;
            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }

        pthread_mutex_lock(&output_lock[port_idx]);
        if(queue_d[port_idx])
        {
            pthread_mutex_unlock(&output_lock[port_idx]);
            pBuffer = bufou[port_idx][j];

            fwrite(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nFilledLen, file);

            pthread_mutex_lock(&output_lock[port_idx]);
            queue_d[port_idx]--;
            pthread_mutex_unlock(&output_lock[port_idx]);

            if ((pBuffer->nFlags & OMX_BUFFERFLAG_EOS) && (queue_d[port_idx] == 0))
                break;

            queue_o[port_idx]++;

            j++;
            if(j >= NUMBER_OF_BUFFERS)
            {
                j = 0;
            }
        }
        else
            pthread_mutex_unlock(&output_lock[port_idx]);

        pthread_mutex_lock(&end_lock);
        if (end == 1)
        {
            pthread_mutex_unlock(&end_lock);

            pthread_mutex_lock(&output_lock[port_idx]);
            if (queue_d[port_idx] == 0)
            {
                pthread_mutex_unlock(&output_lock[port_idx]);
                break;
            }
            pthread_mutex_unlock(&output_lock[port_idx]);
        }
        pthread_mutex_unlock(&end_lock);
    }

    fclose(file);

    pthread_exit(NULL);
}

static void output_thread2(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    int i, j;
    FILE *file;
    int port_idx = 2;

    i = 0;
    j = 0;
    file = fopen(pData->output_name[port_idx], "wb");

    queue_o[port_idx] = pData->cap_outport_def[port_idx].nBufferCountActual;

    phandle = pData->pCapture;

    /* ...output to PCM file */
    while(1)
    {
        if (pluginerror == 1) break;

        if(queue_o[port_idx])
        {
            pBuffer = bufou[port_idx][i];

            if (end == 0)
                OMX_FillThisBuffer(phandle, pBuffer);

            queue_o[port_idx]--;

            i++;
            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }

        pthread_mutex_lock(&output_lock[port_idx]);
        if(queue_d[port_idx])
        {
            pthread_mutex_unlock(&output_lock[port_idx]);
            pBuffer = bufou[port_idx][j];

            fwrite(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nFilledLen, file);

            pthread_mutex_lock(&output_lock[port_idx]);
            queue_d[port_idx]--;
            pthread_mutex_unlock(&output_lock[port_idx]);

            if ((pBuffer->nFlags & OMX_BUFFERFLAG_EOS) && (queue_d[port_idx] == 0))
                break;

            queue_o[port_idx]++;

            j++;
            if(j >= NUMBER_OF_BUFFERS)
            {
                j = 0;
            }
        }
        else
            pthread_mutex_unlock(&output_lock[port_idx]);

        pthread_mutex_lock(&end_lock);
        if (end == 1)
        {
            pthread_mutex_unlock(&end_lock);

            pthread_mutex_lock(&output_lock[port_idx]);
            if (queue_d[port_idx] == 0)
            {
                pthread_mutex_unlock(&output_lock[port_idx]);
                break;
            }
            pthread_mutex_unlock(&output_lock[port_idx]);
        }
        pthread_mutex_unlock(&end_lock);
    }

    fclose(file);

    pthread_exit(NULL);
}

static void output_thread3(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    int i, j;
    FILE *file;
    int port_idx = 3;

    i = 0;
    j = 0;
    file = fopen(pData->output_name[port_idx], "wb");

    queue_o[port_idx] = pData->cap_outport_def[port_idx].nBufferCountActual;

    phandle = pData->pCapture;

    /* ...output to PCM file */
    while(1)
    {
        if (pluginerror == 1) break;

        if(queue_o[port_idx])
        {
            pBuffer = bufou[port_idx][i];

            if (end == 0)
                OMX_FillThisBuffer(phandle, pBuffer);

            queue_o[port_idx]--;

            i++;
            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }

        pthread_mutex_lock(&output_lock[port_idx]);
        if(queue_d[port_idx])
        {
            pthread_mutex_unlock(&output_lock[port_idx]);
            pBuffer = bufou[port_idx][j];

            fwrite(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nFilledLen, file);

            pthread_mutex_lock(&output_lock[port_idx]);
            queue_d[port_idx]--;
            pthread_mutex_unlock(&output_lock[port_idx]);

            if ((pBuffer->nFlags & OMX_BUFFERFLAG_EOS) && (queue_d[port_idx] == 0))
                break;

            queue_o[port_idx]++;

            j++;
            if(j >= NUMBER_OF_BUFFERS)
            {
                j = 0;
            }
        }
        else
            pthread_mutex_unlock(&output_lock[port_idx]);

        pthread_mutex_lock(&end_lock);
        if (end == 1)
        {
            pthread_mutex_unlock(&end_lock);

            pthread_mutex_lock(&output_lock[port_idx]);
            if (queue_d[port_idx] == 0)
            {
                pthread_mutex_unlock(&output_lock[port_idx]);
                break;
            }
            pthread_mutex_unlock(&output_lock[port_idx]);
        }
        pthread_mutex_unlock(&end_lock);
    }

    fclose(file);

    pthread_exit(NULL);
}

/*******************************************************************************
 * Print help menu
 ******************************************************************************/
static void help()
{
    printf("\nADSP TDM Smoketest program Help Menu\n\n"
            "Command: adsp-omx-tdm-launch [-<command> <value>]\n\n"

"Common commands:\n"
            " -w <value>       : PCM Bit per sample (16/24)\n"
            " -chmod <value>   : Channel mode ([0] 4 x stereo, [1] 1 x 8 channel, [3] 3 x stereo, [4] 1 x 6 channel)\n"
            " -l <value>       : Recording time (second)\n"
            " -card <name>     : Select audio card\n\n"

            " Example:\n"
            " ----------------------------------------\n"
            " adsp-omx-tdm-launch -w 16 -l 10 -chmod 0\n"
            " ----------------------------------------\n\n"

"TDM Capture commands:\n"
            " -i <ssi1>        : Use TDM Capture\n"
            " -o1 <name>       : 1st output stream (.pcm)\n"
            " -o2 <name>       : 2nd output stream (.pcm)\n"
            " -o3 <name>       : 3rd output stream (.pcm)\n"
            " -o4 <name>       : 4th output stream (.pcm)\n"
            " -capfs           : Input sampling frequency  : (32000/44100/48000/0). Set '0' to disable SRC module\n"
            " -capoutfs        : Output sampling frequency : (32000/44100/48000).\n"
            " -capdmachannel1  : 1st DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)\n"
            " -capinsource1    : 1st input device          : (SSI10)/(SCU_SRCI0, SCU_SRCI1, SCU_SRCI3, SCU_SRCI4)\n"
            " -capdmachannel2  : 2nd DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)\n"
            " -capinsource2    : 2nd input device          : (SSI10/NONCONFIG). If capinsource1 is 'SSI10', this value must be 'NONCONFIG'\n"
            " -capvol          : Volume gain               : (0 to 8)/FFFFFFFF. Set 'FFFFFFFF' to disable DVC module\n"
            " -capframe        : Frame size                : (512/1024/2048)\n\n"
            " Example:\n"
            " -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n"
            " -i ssi1 -o1 out1.pcm -o2 out2.pcm -o3 out3.pcm -o4 out4.pcm -capfs 48000 -capoutfs 44100 -capdmachannel1 ADMACPP_CH01 -capinsource1 SSI10 -capdmachannel2 ADMACPP_CH00 -capinsource2 NONCONFIG -capvol FFFFFFFF -capframe 1024 \n"
            " -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n\n"

"TDM Renderer commands:\n"
            " -o <ssi0>        : Use TDM Renderer\n"
            " -i1 <name>       : 1st input stream (.pcm)\n"
            " -i2 <name>       : 2nd input stream (.pcm)\n"
            " -i3 <name>       : 3rd input stream (.pcm)\n"
            " -i4 <name>       : 4th input stream (.pcm)\n"
            " -rdrfs           : Input sampling frequency  : (32000/44100/48000)\n"
            " -rdroutfs        : Output sampling frequency : (32000/44100/48000/0). Set '0' to disable SRC module\n"
            " -rdrdmachannel1  : 1st DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)\n"
            " -rdroutsource1   : 1st output device         : (SSI00)/(SCU_SRCI0, SCU_SRCI1, SCU_SRCI3, SCU_SRCI4)\n"
            " -rdrdmachannel2  : 2nd DMA channel           : (ADMAC_CH00 to ADMAC_CH31)/(ADMACPP_CH00 to ADMACPP_CH28)\n"
            " -rdroutsource2   : 2nd output device         : (SSI00/NONCONFIG). If rdroutsource1 is 'SSI00', this value must be 'NONCONFIG'\n"
            " -rdrvol          : Volume gain               : (0 to 8)/FFFFFFFF. Set 'FFFFFFFF' to disable DVC module\n"
            " -rdrframe        : Frame size                : (512/1024/2048)\n\n"
            " Example:\n"
            " -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n"
            " -o ssi0 -i1 input1.pcm -i2 input2.pcm -i3 input3.pcm -i4 input4.pcm -rdrfs 44100 -rdroutfs 48000 -rdrdmachannel1 ADMACPP_CH01 -rdroutsource1 SSI00 -rdrdmachannel2 ADMACPP_CH00 -rdroutsource2 NONCONFIG -rdrvol FFFFFFFF -rdrframe 1024 \n"
            " -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");
}


/*******************************************************************************
 * Read the source or destination setting for plugin
 ******************************************************************************/
static int dmach(char *string)
{
    int result = ADMAC_CHMAX;
    if((strstr(string, "ADMACPP_CH")) != NULL)
    {
        sscanf(string, "ADMACPP_CH%d", &result);
    }
    else if((strstr(string, "ADMAC_CH")) != NULL)
    {
        sscanf(string, "ADMAC_CH%d", &result);
        result = result + ADMAC_CH00;
    }

    return result;
}

/*******************************************************************************
 * Read the source or destination setting for plugin
 ******************************************************************************/
static int src_dst(char *string)
{
    int result = SRC_DST_MAX;
    if((strstr(string, "SSI")) != NULL)
    {
        sscanf(string, "SSI%d", &result);
    }
    else if((strstr(string, "DTCPPP")) != NULL)
    {
        sscanf(string, "DTCPPP%d", &result);
        result = result + DTCPPP0;
    }
    else if((strstr(string, "DTCPCP")) != NULL)
    {
        sscanf(string, "DTCPCP%d", &result);
        result = result + DTCPCP0;
    }
    else if ((strstr(string, "ADSP")) != NULL)
    {
        if (strstr(string, "ADSPI0") != NULL)
        {
            result = ADSPI0;
        }
        if (strstr(string, "ADSPI1") != NULL)
        {
            result = ADSPI1;
        }
        if (strstr(string, "ADSPI2") != NULL)
        {
            result = ADSPI2;
        }
        if (strstr(string, "ADSPI3") != NULL)
        {
            result = ADSPI3;
        }
        if (strstr(string, "ADSPO0") != NULL)
        {
            result = ADSPO0;
        }
        if (strstr(string, "ADSPO1") != NULL)
        {
            result = ADSPO1;
        }
        if (strstr(string, "ADSPO2") != NULL)
        {
            result = ADSPO2;
        }
        if (strstr(string, "ADSPO3") != NULL)
        {
            result = ADSPO3;
        }
    }
    else if ((strstr(string, "SCU_SRCI")) != NULL)
    {
        sscanf(string, "SCU_SRCI%d", &result);
        result = result + SCU_SRCI0;
    }
    else if ((strstr(string, "SCU_SRCO")) != NULL)
    {
        sscanf(string, "SCU_SRCO%d", &result);
        result = result + SCU_SRCO0;
    }
    else if ((strstr(string, "SCU_CMD")) != NULL)
    {
        sscanf(string, "SCU_CMD%d", &result);
        result = result + SCU_CMD0;
    }
    else if ((strstr(string, "MLM")) != NULL)
    {
        sscanf(string, "MLM%d", &result);
        result = result + MLM0;
    }
    else if ((strstr(string, "NONCONFIG")) != NULL)
    {
        result = NONCONFIG;
    }

    return result;
}


/*******************************************************************************
 * Main program
 ******************************************************************************/
int main(int argc, char *argv[])
{
    int                             i, j;
#ifdef TARGET_ANDROID
    struct pcm                      *alsa_out, *alsa_in;
#else
    snd_pcm_t                       *alsa_out, *alsa_in;
#endif
    OMX_ERRORTYPE                   status_code;
    OMX_PTR                         pCmd = NULL;

    OMX_AUDIO_PARAM_PCMMODETYPE     rdr_pcmin_params;
    OMX_AUDIO_PARAM_PCMMODETYPE     cap_pcmout_params;

    XAOMX_AUDIO_PARAM_TDM_CAPTURE   cap_params;
    XAOMX_AUDIO_PARAM_TDM_RENDERER  rdr_params;

    OMX_BUFFERHEADERTYPE            *pBuffer;
    OMX_STATETYPE                   state;
    int                             length_temp;
    char                            *s;
    
    volatile int                    endFlag = 0;
    pthread_t                       input_id[PORT_MAX], output_id[PORT_MAX];
    TEST_DATA                       data;
    char                            *cardname;

#ifdef TARGET_ANDROID
    int card_idx = 0, dev_idx = 0;

    struct pcm_config pcm_config_dac = {0};
    pcm_config_dac.channels = 8;
    pcm_config_dac.rate = 48000;
    pcm_config_dac.period_size = 512;
    pcm_config_dac.period_count = 4;
    pcm_config_dac.format = PCM_FORMAT_S16_LE;
#endif

    /** initialize data */
    for (i = 0; i < PORT_MAX; i++)
    {
        queue_i[i] = 0;
        queue_o[i] = 0;
        queue_d[i] = 0;
        data.input_name[i] = "";
        data.output_name[i] = "";
    }

    pluginerror = 0;
    end = 0;
    over = 0;
    data.eos = 0;
    data.channels = 2;
    data.pwdsz = 16;
    data.fs = 48000;
    data.ts = 0;
    data.ch_mod = XA_TDM_CAP_CHANNEL_MODE_2X4;
    cardname = "default";

    cap_params.nPCM_dma_channel1 = ADMACPP_CH00;
    cap_params.nPCM_input1 = SSI10;
    cap_params.nPCM_dma_channel2 = ADMACPP_CH01;
    cap_params.nPCM_input2 = NONCONFIG;
    cap_params.nPCM_frame_size = 1024;
    cap_params.nPCM_channel_mode = XA_TDM_CAP_CHANNEL_MODE_2X4;
    cap_params.nPCM_volume_rate = 0xffffffff;
    cap_params.nPCM_in_sample_rate = 0;
    cap_params.nPCM_out_sample_rate = 44100;

    rdr_params.nPCM_dma_channel1 = ADMACPP_CH00;
    rdr_params.nPCM_output1 = SSI00;
    rdr_params.nPCM_dma_channel2 = ADMACPP_CH01;
    rdr_params.nPCM_output2 = NONCONFIG;
    rdr_params.nPCM_frame_size = 1024;
    rdr_params.nPCM_channel_mode = XA_TDM_RDR_CHANNEL_MODE_2X4;
    rdr_params.nPCM_volume_rate = 0xffffffff;
    rdr_params.nPCM_in_sample_rate = 44100;
    rdr_params.nPCM_out_sample_rate = 0;

    if(argc == 1)
    {
        help();
        return 0;
    }

    /** processing user's input */
    for (i = 1; i < argc; i++)
    {
        /** check if user input -i */
        if (strcmp(argv[i], "-i") == 0)
        {
            i++;
            if (strcmp(argv[i],"ssi1") == 0)
            {
                data.eos |= CAPTURE_ON;
            }
        }
        else if (strcmp(argv[i], "-o") == 0)
        {
            i++;
            if (strcmp(argv[i], "ssi0") == 0)
            {
                data.eos |= RENDERER_ON;
            }
        }
        else if (strcmp(argv[i], "-i1") == 0)
        {
            i++;
            data.input_name[0] = argv[i];
        }
        else if (strcmp(argv[i], "-i2") == 0)
        {
            i++;
            data.input_name[1] = argv[i];

        }
        else if (strcmp(argv[i], "-i3") == 0)
        {
            i++;
            data.input_name[2] = argv[i];
        }
        else if (strcmp(argv[i], "-i4") == 0)
        {
            i++;
            data.input_name[3] = argv[i];
        }
        else if (strcmp(argv[i], "-o1") == 0)
        {
            i++;
            data.output_name[0] = argv[i];
        }
        else if (strcmp(argv[i], "-o2") == 0)
        {
            i++;
            data.output_name[1] = argv[i];
        }
        else if (strcmp(argv[i], "-o3") == 0)
        {
            i++;
            data.output_name[2] = argv[i];
        }
        else if (strcmp(argv[i], "-o4") == 0)
        {
            i++;
            data.output_name[3] = argv[i];
        }
        else if (strcmp(argv[i], "-w") == 0)
        {
            i++;
            data.pwdsz = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-chmod") == 0)
        {
            i++;
            data.ch_mod = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-l") == 0)
        {
            i++;
            data.ts = atoi(argv[i]);
        }

        /* Capture parameters structure */
        else if (strcmp(argv[i], "-capframe") == 0)
        {
            i++;
            cap_params.nPCM_frame_size = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-capdmachannel1") == 0)
        {
            i++;
            cap_params.nPCM_dma_channel1 = dmach(argv[i]);
        }
        else if (strcmp(argv[i], "-capinsource1") == 0)
        {
            i++;
            cap_params.nPCM_input1 = src_dst(argv[i]);
        }
        else if (strcmp(argv[i], "-capdmachannel2") == 0)
        {
            i++;
            cap_params.nPCM_dma_channel2 = dmach(argv[i]);
        }
        else if (strcmp(argv[i], "-capinsource2") == 0)
        {
            i++;
            cap_params.nPCM_input2 = src_dst(argv[i]);
        }
        else if (strcmp(argv[i], "-capfs") == 0)
        {
            i++;
            cap_params.nPCM_in_sample_rate = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-capoutfs") == 0)
        {
            i++;
            cap_params.nPCM_out_sample_rate = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-capvol") == 0)
        {
            float voltemp;
            i++;
            sscanf(argv[i], "%f", &voltemp);
            if(strcmp(argv[i], "FFFFFFFF") == 0)
            {
                cap_params.nPCM_volume_rate = 0xFFFFFFFF;
            }
            else if((OMX_U32)(voltemp * (1 << 20)) > 0x7FFFFF)
            {
                cap_params.nPCM_volume_rate = 0x7FFFFF;
            }
            else
            {
                cap_params.nPCM_volume_rate = (OMX_U32)(voltemp * (1 << 20));
            }
        }
        /* Renderer parameters structure */
        else if (strcmp(argv[i], "-rdrframe") == 0)
        {
            i++;
            rdr_params.nPCM_frame_size = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-rdrdmachannel1") == 0)
        {
            i++;
            rdr_params.nPCM_dma_channel1 = dmach(argv[i]);
        }
        else if (strcmp(argv[i], "-rdroutsource1") == 0)
        {
            i++;
            rdr_params.nPCM_output1 = src_dst(argv[i]);
        }
        else if (strcmp(argv[i], "-rdrdmachannel2") == 0)
        {
            i++;
            rdr_params.nPCM_dma_channel2 = dmach(argv[i]);
        }
        else if (strcmp(argv[i], "-rdroutsource2") == 0)
        {
            i++;
            rdr_params.nPCM_output2 = src_dst(argv[i]);
        }
        else if (strcmp(argv[i], "-rdrfs") == 0)
        {
            i++;
            rdr_params.nPCM_in_sample_rate = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-rdroutfs") == 0)
        {
            i++;
            rdr_params.nPCM_out_sample_rate = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-rdrvol") == 0)
        {
            float voltemp;
            i++;
            sscanf(argv[i], "%f", &voltemp);
            if(strcmp(argv[i], "FFFFFFFF") == 0)
            {
                rdr_params.nPCM_volume_rate = 0xFFFFFFFF;
            }
            else if((OMX_U32)(voltemp * (1 << 20)) > 0x7FFFFF)
            {
                rdr_params.nPCM_volume_rate = 0x7FFFFF;
            }
            else
            {
                rdr_params.nPCM_volume_rate = (OMX_U32)(voltemp * (1 << 20));
            }
        }
        /* Select card name */
        else if (strcmp(argv[i], "-card") == 0)
        {
            i++;
#ifdef TARGET_ANDROID
            sscanf(argv[i], "%d,%d", &card_idx, &dev_idx);
#else
            cardname = argv[i];
#endif
        }
    }

    /*******************************************************************************
     * Calling Main_process
     ******************************************************************************/

    switch (data.ch_mod)
    {
        case XA_TDM_RDR_CHANNEL_MODE_1X6:
//        case XA_TDM_CAP_CHANNEL_MODE_1X6:
            data.channels = 6;
            data.port_total = 1;
            break;

        case XA_TDM_RDR_CHANNEL_MODE_1X8:
//        case XA_TDM_CAP_CHANNEL_MODE_1X8:
            data.channels = 8;
            data.port_total = 1;
            break;

        case XA_TDM_RDR_CHANNEL_MODE_2X3:
//        case XA_TDM_CAP_CHANNEL_MODE_2X3:
            data.channels = 2;
            data.port_total = 3;
            break;

        case XA_TDM_RDR_CHANNEL_MODE_2X4:
//        case XA_TDM_CAP_CHANNEL_MODE_2X4:
            data.channels = 2;
            data.port_total = 4;
            break;

        case XA_TDM_RDR_CHANNEL_MODE_6_2:
//        case XA_TDM_CAP_CHANNEL_MODE_6_2:
            data.channels = 2;
            data.port_total = 2;
            break;

        default:
            /* invalid channel mode */
            printf("Invalid channel mode\n");
            return 0;
    }

    /* ...check the valid input files */
    if (RENDERER_ENABLE(data.eos))
    {
        FILE* file;

        for (i = 0; i < data.port_total; i++)
        {
            file = fopen(data.input_name[i], "rb");

            if (!file)
            {
                printf("\nInvalid input[%d] file: %s\n\n", i, data.input_name[i]);
                return 0;
            }
            fclose(file);
        }
    }

    /** ...port index control */
    if( RENDERER_ENABLE(data.eos) )
    {
        for (i = 0; i < data.port_total; i++)
        {
            data.rdr_inport_def[i].nPortIndex = i;
        }

        data.rdr_outport_def.nPortIndex = data.port_total;

        for (i = data.port_total; i < PORT_MAX; i++)
        {
            data.rdr_inport_def[i].nPortIndex = i + 1;
        }
    }

    if( CAPTURE_ENABLE(data.eos) )
    {
        data.cap_inport_def.nPortIndex = 0;

        for (i = 0; i < PORT_MAX; i++)
        {
            data.cap_outport_def[i].nPortIndex = 1 + i;
        }
    }

    /* ...get user's input parameters to set */
    rdr_params.nPCM_channel_mode = data.ch_mod;
    cap_params.nPCM_channel_mode = data.ch_mod;

    rdr_pcmin_params.nPortIndex = 0;
    rdr_pcmin_params.nChannels = data.channels;
    rdr_pcmin_params.nSamplingRate = rdr_params.nPCM_in_sample_rate;
    rdr_pcmin_params.nBitPerSample = data.pwdsz;

    cap_pcmout_params.nPortIndex = PORT_MAX;
    cap_pcmout_params.nChannels = data.channels;
    cap_pcmout_params.nSamplingRate = cap_params.nPCM_out_sample_rate;
    cap_pcmout_params.nBitPerSample = data.pwdsz;

    /* No component in use -> exit immediately */
    if(!data.eos)
    {
        printf("\nNo component in used\n\n");
        return 0;
    }

    /*******************************************************************************
     * OMX Initialization
     ******************************************************************************/
    /* ...OMX test */
    if( (status_code = OMX_Init()) != OMX_ErrorNone )
    {
        printf("OMX Initialization failed!!!\n");
        return 0;
    }

    /*******************************************************************************
     * Components Initialization
     ******************************************************************************/
    if( CAPTURE_ENABLE(data.eos) )
    {
        int r;
        int buffer_size = cap_params.nPCM_frame_size * cap_pcmout_params.nChannels * (cap_pcmout_params.nBitPerSample >> 3);
        int buffer_align = 32;
        int alsa_fs;

        alsa_fs = cap_params.nPCM_in_sample_rate;
        if (alsa_fs == 0)
        {
#if TARGET_ANDROID
            alsa_fs = cap_params.nPCM_out_sample_rate;
#else
            /* because PCM3168a codec only support 48000 Hz only,
             * it is necessary to fix this sample rate setting to ensure the output quality */
            alsa_fs = 48000;
#endif
        }

#ifdef TARGET_ANDROID
        /* modify for Android */
	pcm_config_dac.rate = alsa_fs;

        alsa_in = pcm_open(card_idx, dev_idx, PCM_IN, &pcm_config_dac);
        if ((alsa_in == NULL) || !pcm_is_ready(alsa_in) || (pcm_prepare(alsa_in) < 0)) {
            printf("cannot open pcm_in driver normal: %s", pcm_get_error(alsa_in));
            pcm_close(alsa_in);
            alsa_in = NULL;
            return -1;
        }
#else
        /* ...open PCM device for playback */
        if((r = snd_pcm_open(&alsa_in, cardname, SND_PCM_STREAM_CAPTURE, 0)) < 0)
        {
            printf("Failed to open pcm device: %s\n", snd_strerror(r));
            return r;
        }

        printf("alsa in sample rate %d\n", alsa_fs);

        /* ...set ALSA parameters */
        if((r = snd_pcm_set_params(alsa_in, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, data.channels, alsa_fs, 0, 0)) < 0)
        {
            printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
            alsa_close(alsa_in);
            return r;
        }
#endif
        /* ...get Renderer's handle */
        OMX_GetHandle(&data.pCapture, "OMX.RENESAS.AUDIO.DSP.TDMCAPTURE", (OMX_PTR)&data, &callbacks_Cap);

        /* ..set parameters */
        OMX_SetParameter(data.pCapture, OMX_IndexParamAudioPcm, &cap_pcmout_params);
        OMX_SetParameter(data.pCapture, XAOMX_IndexParamAudioTDMCapture, &cap_params);

        /* modify port definition */
        if(data.pwdsz == 24)
        {
            buffer_align = 24;
        }
        else if (data.pwdsz == 16)
        {
            buffer_align = 32;
        }

        for (i = 0; i < data.port_total; i++)
        {
            OMX_GetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def[i]);

            data.cap_outport_def[i].eDir = OMX_DirOutput;
            data.cap_outport_def[i].nBufferCountMin = 4;
            data.cap_outport_def[i].nBufferCountActual = 4;
            data.cap_outport_def[i].nBufferAlignment = buffer_align;
            data.cap_outport_def[i].nBufferSize = buffer_size;

            OMX_SetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def[i]);
        }

        for (i = data.port_total; i < PORT_MAX; i++)
        {
            OMX_GetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def[i]);
            data.cap_outport_def[i].eDir = OMX_DirMax;
            OMX_SetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def[i]);
        }

        OMX_GetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_inport_def);

        data.cap_inport_def.eDir = OMX_DirInput;
        data.cap_inport_def.nBufferCountMin = 1;
        data.cap_inport_def.nBufferCountActual = 1;
        data.cap_inport_def.nBufferAlignment = buffer_align;
        data.cap_inport_def.nBufferSize = 1;

        OMX_SetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_inport_def);
    }

    if( RENDERER_ENABLE(data.eos) )
    {
        int r;
#if 0
        int buffer_size = rdr_params.nPCM_frame_size * rdr_pcmin_params.nChannels * (rdr_pcmin_params.nBitPerSample >> 3);
#else
        int buffer_size = 2048 * rdr_pcmin_params.nChannels * (rdr_pcmin_params.nBitPerSample >> 3);
#endif
        int buffer_align = 16;
        int alsa_fs;

        alsa_fs = rdr_params.nPCM_out_sample_rate;
        if (alsa_fs == 0)
        {
#ifdef TARGET_ANDROID
            alsa_fs = rdr_params.nPCM_in_sample_rate;
#else
            /* because PCM3168a codec only support 48000 Hz only,
             * it is necessary to fix this sample rate setting to ensure the output quality */
            alsa_fs = 48000;
#endif
        }

#ifdef TARGET_ANDROID
	pcm_config_dac.rate = alsa_fs;

        alsa_out = pcm_open(card_idx, dev_idx, PCM_OUT, &pcm_config_dac);
        if ((alsa_out == NULL) || !pcm_is_ready(alsa_out) || pcm_prepare(alsa_out)) {
            printf("cannot open pcm_out driver normal 4: %s", pcm_get_error(alsa_out));
            pcm_close(alsa_out);
            alsa_out = NULL;
            return -1;
        }
#else
        /* ...open PCM device for playback */
        if((r = snd_pcm_open(&alsa_out, cardname, SND_PCM_STREAM_PLAYBACK, 0)) < 0)
        {
            printf("Failed to open pcm device: %s\n", snd_strerror(r));
            return r;
        }

        printf("alsa out sample rate %d\n", alsa_fs);

        /* ...set ALSA parameters */
        if((r = snd_pcm_set_params(alsa_out, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, data.channels, alsa_fs, 0, 0)) < 0)
        {
            printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
            alsa_close(alsa_out);
            return r;
        }
#endif
        /* ...get Renderer's handle */
        OMX_GetHandle(&data.pRenderer, "OMX.RENESAS.AUDIO.DSP.TDMRENDERER", (OMX_PTR)&data, &callbacks_Ren);

        /* ...set parameters for Renderer */
        OMX_SetParameter(data.pRenderer, OMX_IndexParamAudioPcm, &rdr_pcmin_params);
        OMX_SetParameter(data.pRenderer, XAOMX_IndexParamAudioTDMRenderer, &rdr_params);

        /* ...modify port definition */
        if(data.pwdsz == 24)
        {
            buffer_align = 32;
        }
        else if(data.pwdsz == 16)
        {
            buffer_align = 16;
        }

        for (i = 0; i < data.port_total; i++)
        {
            OMX_GetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def[i]);

            data.rdr_inport_def[i].eDir = OMX_DirInput;
            data.rdr_inport_def[i].nBufferCountMin = 4;
            data.rdr_inport_def[i].nBufferCountActual = 4;
            data.rdr_inport_def[i].nBufferAlignment = buffer_align;
            data.rdr_inport_def[i].nBufferSize = buffer_size;

            OMX_SetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def[i]);
        }

        for (i = data.port_total; i < PORT_MAX; i++)
        {
            OMX_GetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def[i]);
            data.rdr_inport_def[i].eDir = OMX_DirMax;
            OMX_SetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def[i]);
        }

        OMX_GetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_outport_def);

        data.rdr_outport_def.eDir = OMX_DirOutput;
        data.rdr_outport_def.nBufferCountMin = 1;
        data.rdr_outport_def.nBufferCountActual = 1;
        data.rdr_outport_def.nBufferAlignment = buffer_align;;
        data.rdr_outport_def.nBufferSize = 1;

        OMX_SetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_outport_def);
    }

    if (CAPTURE_ENABLE(data.eos))
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateIdle, pCmd);

    if (RENDERER_ENABLE(data.eos))
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

    if (pluginerror)
    {
        OMX_Deinit();
        printf("[TEST] Invalid parameters!\n");
        return 1;
    }

    if (CAPTURE_ENABLE(data.eos) )
    {
        for (i = 0; i < data.cap_inport_def.nBufferCountActual; i++)
        {
            OMX_AllocateBuffer(data.pCapture, &bufin[0][i], data.cap_inport_def.nPortIndex, NULL, data.cap_inport_def.nBufferSize);
        }

        for (j = 0; j < data.port_total; j++)
        {
            /* there is no sink component - need to allacte output port buffer */
            for (i = 0; i < data.cap_outport_def[j].nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pCapture, &bufou[j][i], data.cap_outport_def[j].nPortIndex, NULL, data.cap_outport_def[j].nBufferSize);
            }
        }
    }

    if (RENDERER_ENABLE(data.eos) )
    {
        for (i = 0; i < data.rdr_outport_def.nBufferCountActual; i++)
        {
            OMX_AllocateBuffer(data.pRenderer, &bufou[0][i], data.rdr_outport_def.nPortIndex, NULL, data.rdr_outport_def.nBufferSize);
        }

        for (j = 0; j < data.port_total; j++)
        {
            /* there is only renderer plugin - need to allocate input port buffer */
            for (i = 0; i < data.rdr_inport_def[j].nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pRenderer, &bufin[j][i], data.rdr_inport_def[j].nPortIndex, NULL, data.rdr_inport_def[j].nBufferSize);
            }
        }
    }

    if (pluginerror == 1)
    {
        if (CAPTURE_ENABLE(data.eos))
        {
            OMX_FreeHandle(data.pCapture);
            alsa_close(alsa_in);
        }

        if (RENDERER_ENABLE(data.eos))
        {
            OMX_FreeHandle(data.pRenderer);
            alsa_close(alsa_out);
        }

        OMX_Deinit();
        printf("[Test] Invalid parameters!\n");
        return 1;
    }

    /* after this point - the component have already changed to state idle */
    if (CAPTURE_ENABLE(data.eos))
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateExecuting, pCmd);

    if (RENDERER_ENABLE(data.eos))
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateExecuting, pCmd);

    for (i = 0; i < data.port_total; i++)
    {
        pthread_mutex_init(&input_lock[i], NULL);
        pthread_mutex_init(&output_lock[i], NULL);
    }

    pthread_mutex_init(&end_lock, NULL);

    /*******************************************************************************
     * Prepare for run
     ******************************************************************************/
    if (RENDERER_ENABLE(data.eos))
    {
        i = data.port_total - 1;

        if (i >= 0) pthread_create(&input_id[0], NULL, (void*)input_thread0, (void*)&data);
        if (i >= 1) pthread_create(&input_id[1], NULL, (void*)input_thread1, (void*)&data);
        if (i >= 2) pthread_create(&input_id[2], NULL, (void*)input_thread2, (void*)&data);
        if (i >= 3) pthread_create(&input_id[3], NULL, (void*)input_thread3, (void*)&data);
    }

    if (CAPTURE_ENABLE(data.eos))
    {
        i = data.port_total - 1;

        if (i >= 0) pthread_create(&output_id[0], NULL, (void*)output_thread0, (void*)&data);
        if (i >= 1) pthread_create(&output_id[1], NULL, (void*)output_thread1, (void*)&data);
        if (i >= 2) pthread_create(&output_id[2], NULL, (void*)output_thread2, (void*)&data);
        if (i >= 3) pthread_create(&output_id[3], NULL, (void*)output_thread3, (void*)&data);
    }

    if (CAPTURE_ENABLE(data.eos))
    {
        /* Need to add empty buffer in case only Capture is available */
        bufin[0][0]->nFilledLen = 1;
        OMX_EmptyThisBuffer(data.pCapture, bufin[0][0]);

        /* Sleep ts second */
        if (data.ts)
        {
            sleep(data.ts);
        }
        else
        {
            char tmp[3] = {0};

            printf("Press 's' to stop TDM Capture:\n");
            while((tmp[0] != 's'))
                fgets(tmp, sizeof(tmp), stdin);
        }

        bufin[0][0]->nFilledLen = 0;
        bufin[0][0]->nFlags |= OMX_BUFFERFLAG_EOS;
        end = 1;

        OMX_EmptyThisBuffer(data.pCapture, bufin[0][0]);

        sleep(1);
    }

    if (RENDERER_ENABLE(data.eos))
    {
        for (i = 0; i < data.port_total; i++)
            pthread_join(input_id[i], NULL);

        sleep(1);
    }

    if (CAPTURE_ENABLE(data.eos))
    {
        for (i = 0; i < data.port_total; i++)
            pthread_join(output_id[i], NULL);
    }

    /*******************************************************************************
     * End process change components to Idle, Loaded and free all buffer
     ******************************************************************************/
    if(CAPTURE_ENABLE(data.eos))
    {
        /* ...change state to IDLE */
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        /* ...wait until Renderer's state is IDLE */
        get_and_wait_component_state(data.pCapture, OMX_StateIdle);

        /* ...change state to LOADED */
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateLoaded, pCmd);

        /* ...free buffer of input/output port */
        for(i = 0; i < data.cap_inport_def.nBufferCountActual; i++)
        {
            OMX_FreeBuffer(data.pCapture, data.cap_inport_def.nPortIndex, bufin[0][i]);
        }

        for (j = 0; j < data.port_total; j++)
        {
            /* there is no tunnel setup -> need free output port buffer */
            for(i = 0; i < data.cap_outport_def[j].nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pCapture, data.cap_outport_def[j].nPortIndex, bufou[j][i]);
            }
        }

        /* ...free handle */
        OMX_FreeHandle(data.pCapture);

        alsa_close(alsa_in);
    }

    if(RENDERER_ENABLE(data.eos))
    {
        /* ...change state to IDLE */
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        /* ...wait until Renderer's state is EXECUTING */
        get_and_wait_component_state(data.pRenderer, OMX_StateIdle);

        /* ...change state to LOADED */
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateLoaded, pCmd);

        /* ...free buffer of input/output port */
        for (j = 0; j < data.port_total; j++)
        {
            /* ...there is no setup tunnel -> need free input port buffer manually */
            for(i = 0; i < data.rdr_inport_def[j].nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pRenderer, data.rdr_inport_def[j].nPortIndex, bufin[j][i]);
            }
        }

        for(i = 0; i < data.rdr_outport_def.nBufferCountActual; i++)
        {
            OMX_FreeBuffer(data.pRenderer, data.rdr_outport_def.nPortIndex, bufou[0][i]);
        }

        /* ...free handle */
        OMX_FreeHandle(data.pRenderer);

        alsa_close(alsa_out);
    }

    OMX_Deinit();

    printf("[TEST] All Test Complete!\n");
    
    return 0;
}
