/** *****************************************************************************
  \file       xa_rel_eqz.h
  \brief      Header file of ADSP Equalizer Plugin
  \addtogroup ADSP Equalizer Plugin
 ********************************************************************************
  \date       Mar. 02, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation. All Rights Reserved.

           RENESAS ELECTRONICS CONFIDENTIAL AND PROPRIETARY

   These instructions, statements, and programs are the confidential information

   of Renesas Electronics Corporation. They must be used and modified solely for

   the purpose for which it was furnished by Renesas Electronics Corporation.

   All part of them must not be reproduced nor disclosed to others in any form,

   without the prior written permission of Renesas Electronics Corporation.

 ********************************************************************************/

#ifndef __XA_RELEQZ_LIB_H__
#define __XA_RELEQZ_LIB_H__

/*****************************************************************************/
/* Equalizer specific API definitions                                        */
/*****************************************************************************/

/**< range of bandwidth value; fixed point Q5.27 */
#define XA_REL_EQZ_BW_MIN					(26843546)		/**< 0.2 x 2 ^ 27 */
#define XA_REL_EQZ_BW_MAX					(2013265920)	/**< 15 x 2 ^ 27 */

/**< range of gain value; fixed point Q4.28 */
#define XA_REL_EQZ_GA_MIN					(47735325)		/**< 10^(-15/20) x 2 ^ 28 */
#define XA_REL_EQZ_GA_MAX					(1509523500)	/**< 10^( 15/20) x 2 ^ 28 */

/**< range of base gain value; fixed point Q4.28 */
#define XA_REL_EQZ_BA_MIN					(84886744)		/**< 10^(-10/20) x 2^28 */
#define XA_REL_EQZ_BA_MAX					(848867445)		/**< 10^( 10/20) x 2^28 */

/**< total Fc's range value */
#define XA_REL_EQZ_FC_MIN					(20)			/**< the minimum value */
#define XA_REL_EQZ_FC_MAX					(20000)			/**< the maximum value */

/**< range of gain value of graphic equalizer; fixed point Q4.28 */
#define XA_REL_GEQZ_GA_MIN					(84886744)		/**< 10^(-10/20) x 2^28 */
#define XA_REL_GEQZ_GA_MAX					(848867445)		/**< 10^( 10/20) x 2^28 */

/**< Fc's range value of peaking filter */
#define XA_REL_EQZ_FC_PEAKING_MIN			(20)			/**< the minimum value */
#define XA_REL_EQZ_FC_PEAKING_MAX			(20000)			/**< the maximum value */

/**< Fc's range value of bass filter */
#define XA_REL_EQZ_FC_BASS_MIN_NUM			(50)			/**< the minimum value */
#define XA_REL_EQZ_FC_BASS_MAX_NUM			(500)			/**< the maximum value */

/**< Fc's range value of treble filter */
#define XA_REL_EQZ_FC_TREBLE_MIN_NUM		(5000)			/**< the minimum value */
#define XA_REL_EQZ_FC_TREBLE_MAX_NUM		(11000)			/**< the maximum value */

#define XA_REL_EQZ_CH_MAX_NUM				(2)				/**< max channel of equalizer */

#define XA_REL_EQZ_FILTER_NUM				(9)				/**< number of filter */

#define XA_REL_EQZ_GRAPHIC_BAND_NUM			(5)				/**< number of graphic band */

/** \enum   xa_rel_eqz_filter_type
    \brief  type of filter
 */
enum xa_rel_eqz_filter_type {
	XA_REL_EQZ_TYPE_THROUGH = 0,
	XA_REL_EQZ_TYPE_PEAK	= 1,
	XA_REL_EQZ_TYPE_BASS	= 2,
	XA_REL_EQZ_TYPE_TREBLE	= 3
};

/** \enum   xa_rel_eqz_type
   \brief  type of equalizer
 */
enum xa_rel_eqz_type {
	XA_REL_EQZ_TYPE_PARAMETRIC	= 0,
	XA_REL_EQZ_TYPE_GRAPHIC		= 1
};

/** \enum   xa_add_cmd_type_generic
   \brief  additional subcommand indices
 */
enum xa_add_cmd_type_generic {
	/* XA_API_CMD_SET_CONFIG_PARAM indices */
	XA_EQZ_CONFIG_PARAM_COEF_FS				= 0x0000,
	XA_EQZ_CONFIG_PARAM_PCM_WIDTH			= 0x0001,
	XA_EQZ_CONFIG_PARAM_CH					= 0x0002,
	XA_EQZ_CONFIG_PARAM_EQZ_TYPE			= 0x0003,

	XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_FC	= 0x0010,
	XA_EQZ_CONFIG_PARAM_FILTER_1_COEF_FC	= 0x0011,
	XA_EQZ_CONFIG_PARAM_FILTER_2_COEF_FC	= 0x0012,
	XA_EQZ_CONFIG_PARAM_FILTER_3_COEF_FC	= 0x0013,
	XA_EQZ_CONFIG_PARAM_FILTER_4_COEF_FC	= 0x0014,
	XA_EQZ_CONFIG_PARAM_FILTER_5_COEF_FC	= 0x0015,
	XA_EQZ_CONFIG_PARAM_FILTER_6_COEF_FC	= 0x0016,
	XA_EQZ_CONFIG_PARAM_FILTER_7_COEF_FC	= 0x0017,
	XA_EQZ_CONFIG_PARAM_FILTER_8_COEF_FC	= 0x0018,

	XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_TYPE	= 0x0020,
	XA_EQZ_CONFIG_PARAM_FILTER_1_COEF_TYPE	= 0x0021,
	XA_EQZ_CONFIG_PARAM_FILTER_2_COEF_TYPE	= 0x0022,
	XA_EQZ_CONFIG_PARAM_FILTER_3_COEF_TYPE	= 0x0023,
	XA_EQZ_CONFIG_PARAM_FILTER_4_COEF_TYPE	= 0x0024,
	XA_EQZ_CONFIG_PARAM_FILTER_5_COEF_TYPE	= 0x0025,
	XA_EQZ_CONFIG_PARAM_FILTER_6_COEF_TYPE	= 0x0026,
	XA_EQZ_CONFIG_PARAM_FILTER_7_COEF_TYPE	= 0x0027,
	XA_EQZ_CONFIG_PARAM_FILTER_8_COEF_TYPE	= 0x0028,

	XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_BW	= 0x0030,
	XA_EQZ_CONFIG_PARAM_FILTER_1_COEF_BW	= 0x0031,
	XA_EQZ_CONFIG_PARAM_FILTER_2_COEF_BW	= 0x0032,
	XA_EQZ_CONFIG_PARAM_FILTER_3_COEF_BW	= 0x0033,
	XA_EQZ_CONFIG_PARAM_FILTER_4_COEF_BW	= 0x0034,
	XA_EQZ_CONFIG_PARAM_FILTER_5_COEF_BW	= 0x0035,
	XA_EQZ_CONFIG_PARAM_FILTER_6_COEF_BW	= 0x0036,
	XA_EQZ_CONFIG_PARAM_FILTER_7_COEF_BW	= 0x0037,
	XA_EQZ_CONFIG_PARAM_FILTER_8_COEF_BW	= 0x0038,

	XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_GA	= 0x0040,
	XA_EQZ_CONFIG_PARAM_FILTER_1_COEF_GA	= 0x0041,
	XA_EQZ_CONFIG_PARAM_FILTER_2_COEF_GA	= 0x0042,
	XA_EQZ_CONFIG_PARAM_FILTER_3_COEF_GA	= 0x0043,
	XA_EQZ_CONFIG_PARAM_FILTER_4_COEF_GA	= 0x0044,
	XA_EQZ_CONFIG_PARAM_FILTER_5_COEF_GA	= 0x0045,
	XA_EQZ_CONFIG_PARAM_FILTER_6_COEF_GA	= 0x0046,
	XA_EQZ_CONFIG_PARAM_FILTER_7_COEF_GA	= 0x0047,
	XA_EQZ_CONFIG_PARAM_FILTER_8_COEF_GA	= 0x0048,

	XA_EQZ_CONFIG_PARAM_FILTER_0_COEF_BA	= 0x0050,
	XA_EQZ_CONFIG_PARAM_FILTER_1_COEF_BA	= 0x0051,
	XA_EQZ_CONFIG_PARAM_FILTER_2_COEF_BA	= 0x0052,
	XA_EQZ_CONFIG_PARAM_FILTER_3_COEF_BA	= 0x0053,
	XA_EQZ_CONFIG_PARAM_FILTER_4_COEF_BA	= 0x0054,
	XA_EQZ_CONFIG_PARAM_FILTER_5_COEF_BA	= 0x0055,
	XA_EQZ_CONFIG_PARAM_FILTER_6_COEF_BA	= 0x0056,
	XA_EQZ_CONFIG_PARAM_FILTER_7_COEF_BA	= 0x0057,
	XA_EQZ_CONFIG_PARAM_FILTER_8_COEF_BA	= 0x0058,

	XA_EQZ_CONFIG_PARAM_BAND_0_GCOEF_GA		= 0x0060,
	XA_EQZ_CONFIG_PARAM_BAND_1_GCOEF_GA		= 0x0061,
	XA_EQZ_CONFIG_PARAM_BAND_2_GCOEF_GA		= 0x0062,
	XA_EQZ_CONFIG_PARAM_BAND_3_GCOEF_GA		= 0x0063,
	XA_EQZ_CONFIG_PARAM_BAND_4_GCOEF_GA		= 0x0064,
};

#endif /* __XA_RELEQZ_LIB_H__ */