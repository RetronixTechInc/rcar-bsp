/** *****************************************************************************
  \addtogroup ADSP Smoketest Application
  \file       adsp-omx-launch.c
  \brief      Control of ADSP via ADSP Interface
 ********************************************************************************
  \date       Apr. 08, 2016
  \author     Renesas Electronics Corporation
 ********************************************************************************
  \par        Copyright

   Copyright(C) 2016 Renesas Electronics Corporation
 ********************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <malloc.h>
#include <math.h>
#include <pthread.h>
#include <OMX_Core.h>
#include <OMX_Types.h>
#include <OMX_Index.h>
#include <OMX_Component.h>

#include "xa-omx-renderer.h"
#include "xa-omx-equalizer.h"
#include "audio/xa_rel_eqz.h"
#ifdef TARGET_ANDROID
#include <tinyalsa/asoundlib.h>
#include <unistd.h>  
#else
#include <alsa/asoundlib.h>
#endif

/* ...support testing for developer */
#ifndef DEV
#define DEV                             (0)
#endif
/* ...size of buffer to store read data from file */
#define MAX_LENGTH						(100)

/* ...component is enabled */
#define ON 								(1)

/* ...component is disabled */
#define OFF 							(0)

/* ...number of buffers */
#define NUMBER_OF_BUFFERS				(4)

/* ...status flag definition */
#define RENDERER_ON						(1 << 0)
#define EQUALIZER_ON					(1 << 1)
#define CAPTURE_ON						(1 << 2)

#define CAPTURE_ENABLE(eos)				(eos & (CAPTURE_ON))
#define EQUALIZER_ENABLE(eos)			(eos & (EQUALIZER_ON))
#define RENDERER_ENABLE(eos)			(eos & (RENDERER_ON))

OMX_BUFFERHEADERTYPE	*bufin[NUMBER_OF_BUFFERS];
OMX_BUFFERHEADERTYPE	*bufou[NUMBER_OF_BUFFERS];

/* ...Equalizer's parameters */
typedef struct equalizer {
    int 	type;
    int 	filter_type[9];
    int 	frequency_center[9];
    double 	band_width[9];
    double 	gain[9];
    double 	gain_base[9];
    double 	graphic_gain[5];
} equalizer;

/* ...Renderer's parameters */
typedef struct renderer {
    int		dmachannel1;
    int		output1;
    int		dmachannel2;
    int		output2;
    int		infs;
    int		outfs;
    int		outvol;
    int		framesize;
    int     in_ch;
    int     out_ch;
    int     mix_ctrl;
} renderer;

/* ...Capture's parameters */
typedef struct capture {
    int		dmachannel1;
    int		input1;
    int		dmachannel2;
    int		input2;
    int		infs;
    int		outfs;
    int		outvol;
    int		framesize;
} capture;

typedef struct wav_header_info {
    char	ck_id[4];
    int		cksize;
    char	wav_id[4];
    char	ch_id[4];
    int		chsize;
    short	fmttag;
    short	nChannel;
    int		nSamplingRate;
    int		nDataRate;
    short	nBlockAlign;
    short	nBitPerSample;
} wav_header_info;

/* ...TEST_DATA structure with parameters to check */
typedef struct TEST_DATA {
    int		eos;
    char 	*input_name;
    char 	*output_name;
    char 	*config_name;
    char 	*capconfig_name;
    char 	*rdrconfig_name;
    int 	time;
    int 	channels;
    int 	pwdsz;
    int 	eqzfs;
    int		ts;
    int		iwav;
    equalizer	eqz;
    capture     cap;
    renderer    rdr;
    wav_header_info wav;
    int 	wav_length;

    /* OMX Component */
    OMX_HANDLETYPE					pEqualizer;
    OMX_HANDLETYPE 					pRenderer;
    OMX_HANDLETYPE 					pCapture;

    /* OMX Port definition */
    OMX_PARAM_PORTDEFINITIONTYPE	cap_inport_def;
    OMX_PARAM_PORTDEFINITIONTYPE	cap_outport_def;
    OMX_PARAM_PORTDEFINITIONTYPE	eqz_inport_def;
    OMX_PARAM_PORTDEFINITIONTYPE	eqz_outport_def;
    OMX_PARAM_PORTDEFINITIONTYPE	rdr_inport_def;
    OMX_PARAM_PORTDEFINITIONTYPE	rdr_outport_def;
} TEST_DATA;

/*******************************************************************************
 * Global variables and functions
 ******************************************************************************/
int queue_i;
int queue_o;
int queue_d;

int g_end;
int pluginerror;
int g_vol_up_cmd;
int g_vol_down_cmd;
int g_stop_cmd;

/* indicate the last buffer from output port have been responded */
int last_buff;

pthread_mutex_t input_lock;
pthread_mutex_t output_lock;
pthread_mutex_t end_lock;
pthread_mutex_t user_lock;
pthread_mutex_t main_lock;
pthread_mutex_t event_lock;

static OMX_ERRORTYPE cbEventHandler( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_EVENTTYPE eEvent, OMX_OUT OMX_U32 Data1, OMX_OUT OMX_U32 Data2, OMX_IN OMX_PTR pEventData )
{
    if (eEvent == OMX_EventError)
    {
        printf("Receive a fatal error from ADSP plug-in\n");
        pthread_mutex_lock(&event_lock);
        pluginerror = 1;
        pthread_mutex_unlock(&event_lock);
    }
    else if (eEvent == OMX_EventBufferFlag)
    {
        pthread_mutex_lock(&event_lock);
        last_buff = 1;
        pthread_mutex_unlock(&event_lock);
    }

    /* Event Handler for all component */
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbEmptyBufferDone_Eqz( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    pthread_mutex_lock(&input_lock);
    queue_i++;
    pthread_mutex_unlock(&input_lock);
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbEmptyBufferDone_Rdr( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer)
{
    pthread_mutex_lock(&input_lock);
    queue_i++;
    pthread_mutex_unlock(&input_lock);
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbEmptyBufferDone_Cap( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer)
{
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbFillBufferDone_Eqz( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    pthread_mutex_lock(&output_lock);
    queue_d++;
    pthread_mutex_unlock(&output_lock);
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbFillBufferDone_Cap( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    pthread_mutex_lock(&output_lock);
    queue_d++;
    pthread_mutex_unlock(&output_lock);
    return OMX_ErrorNone;
}

static OMX_ERRORTYPE cbFillBufferDone_Rdr( OMX_OUT OMX_HANDLETYPE hComponent, OMX_OUT OMX_PTR pAppData, OMX_OUT OMX_BUFFERHEADERTYPE* pBuffer )
{
    return OMX_ErrorNone;
}

static OMX_CALLBACKTYPE callbacks_Eqz =
{
    .EventHandler = cbEventHandler,
    .EmptyBufferDone = cbEmptyBufferDone_Eqz,
    .FillBufferDone = cbFillBufferDone_Eqz,
};

static OMX_CALLBACKTYPE callbacks_Ren =
{
    .EventHandler = cbEventHandler,
    .EmptyBufferDone = cbEmptyBufferDone_Rdr,
    .FillBufferDone = cbFillBufferDone_Rdr,
};

static OMX_CALLBACKTYPE callbacks_Cap =
{
    .EventHandler = cbEventHandler,
    .EmptyBufferDone = cbEmptyBufferDone_Cap,
    .FillBufferDone = cbFillBufferDone_Cap,
};

#ifdef TARGET_ANDROID
static inline void alsa_close(struct pcm *alsa_handle)
{
    if(alsa_handle)
    {
        /* ...close ALSA handle */
        pcm_close(alsa_handle), alsa_handle = NULL;
    }
}
#else
static inline void alsa_close(snd_pcm_t *alsa_handle)
{
    if(alsa_handle)
    {
        /* ...close ALSA handle */
        snd_pcm_close(alsa_handle), alsa_handle = NULL;
    }
}
#endif

static OMX_ERRORTYPE get_and_wait_component_state(OMX_HANDLETYPE phandle, OMX_STATETYPE state)
{
    OMX_STATETYPE cur_state;

    while (1)
    {
        OMX_GetState(phandle, &cur_state);
        if( cur_state == state )
        {
            return OMX_ErrorNone;
        }
        else if (cur_state == OMX_StateInvalid)
        {
            /* return immediately when state changed to Invalid */
            break;
        }
    }

    return OMX_ErrorIncorrectStateTransition;
}

/*******************************************************************************
 * Read the source or destination setting for plugin
 ******************************************************************************/
static int dmach(char *string)
{
    int result = ADMAC_CHMAX;
    if((strstr(string, "ADMACPP_CH")) != NULL)
    {
        sscanf(string, "ADMACPP_CH%d", &result);
    }
    else if((strstr(string, "ADMAC_CH")) != NULL)
    {
        sscanf(string, "ADMAC_CH%d", &result);
        result = result + ADMAC_CH00;
    }

    return result;
}

/*******************************************************************************
 * rdr_config file parameters checking function
 ******************************************************************************/
static int rdr_param_ok(TEST_DATA *pData, float voltemp)
{
    /*Check volume rate setting */
    if(((voltemp < 0) || (voltemp > 8)) && (voltemp != -1))
    {
        printf("\nRenderer volume control error.\nPlease input volume gain from 0 to 8 or disable DVC module by inputing volume gain = -1\n");
        return -1;
    }

    /*Check DMA channel 1 setting */
    if ((pData->rdr.dmachannel1 > 60) || (pData->rdr.dmachannel1 < 0))
    {
        printf("\nParameters file is wrong. Please input correct renderer DMA channel 1 \n"
                "from ADMAC_CH00 to ADMAC_CH31 \n"
                "or from ADMACPP_CH00 to ADMACPP_CH28 \n");
        return -1;
    }

    /*Check DMA channel 2 setting */
    if ((pData->rdr.dmachannel2 > 60) || (pData->rdr.dmachannel2 < 0))
    {
        printf("\nParameters file is wrong. Please input correct renderer DMA channel 2 \n"
                "from ADMAC_CH00 to ADMAC_CH31 \n"
                "or from ADMACPP_CH00 to ADMACPP_CH28 \n");
        return -1;
    }

    /*Check output source 1 setting */
    if ((pData->rdr.output1 != SSI00) &&
        (pData->rdr.output1 != SSI10) &&
        (pData->rdr.output1 != SSI20) &&
        (pData->rdr.output1 != SSI30) &&
        (pData->rdr.output1 != SSI40) &&
        (pData->rdr.output1 != SSI50) &&
        (pData->rdr.output1 != SSI60) &&
        (pData->rdr.output1 != SSI70) &&
        (pData->rdr.output1 != SSI80) &&
        (pData->rdr.output1 != SSI90) &&
        ((pData->rdr.output1 < SCU_SRCI0) || (pData->rdr.output1 > SCU_SRCI9)) &&
        (pData->rdr.output1 != NONCONFIG))
    {
        printf("\nParameters file is wrong. Please input correct renderer output source 1 \n"
                "SSI00 "
                "or from SRC0 to SRC9 \n");
        return -1;
    }

    /*Check output source 2 setting */
    if ((pData->rdr.output2 != SSI00) &&
        (pData->rdr.output2 != SSI10) &&
        (pData->rdr.output2 != SSI20) &&
        (pData->rdr.output2 != SSI30) &&
        (pData->rdr.output2 != SSI40) &&
        (pData->rdr.output2 != SSI50) &&
        (pData->rdr.output2 != SSI60) &&
        (pData->rdr.output2 != SSI70) &&
        (pData->rdr.output2 != SSI80) &&
        (pData->rdr.output2 != SSI90) &&
        ((pData->rdr.output2 < SCU_SRCI0) || (pData->rdr.output2 > SCU_SRCI9)) &&
        (pData->rdr.output2 != NONCONFIG))
    {
        printf("\nParameters file is wrong. Please input correct renderer output source 2 \n"
                "SSI00 "
                "or from SRC0 to SRC9 \n");
        return -1;
    }

    /*Check in sampling rate setting */
    if ((pData->rdr.infs != 48000) && (pData->rdr.infs != 32000) && (pData->rdr.infs != 44100))
    {
        printf("\nParameters file is wrong. Please input correct renderer input sampling rate 32000/44100/48000\n");
        return -1;
    }

    /*Check out sampling rate setting */
    if ((pData->rdr.outfs != 48000) && (pData->rdr.outfs != 32000) && (pData->rdr.outfs != 44100))
    {
        printf("\nParameters file is wrong. Please input correct renderer output sampling rate 32000/44100/48000\n");
        return -1;
    }

    /*Check framesize setting */
    if ((pData->rdr.framesize != 1024) &&
        (pData->rdr.framesize != 2048))
    {
        printf("\nParameters file is wrong. Please input correct renderer frame size 1024/2048\n");
        return -1;
    }

    /*Check in channel setting */
    if((pData->rdr.in_ch != 1) && (pData->rdr.in_ch != 2)
        && (pData->rdr.in_ch != 4) && (pData->rdr.in_ch != 6 )
        && (pData->rdr.in_ch != 8))
    {
        printf("\nParameters file is wrong. Please input correct renderer input channel 1/2/4/6/8\n");
        return -1;
    }

    /*Check out channel setting */
    if((pData->rdr.out_ch != 1) && (pData->rdr.out_ch != 2))
    {
        printf("\nParameters file is wrong. Please input correct renderer input channel 1/2\n");
        return -1;
    }

    /*Check PCM Width setting */
    if((pData->pwdsz != 16) && (pData->pwdsz != 24))
    {
        printf("\nParameters is wrong. Please input correct PCM Width 16/24\n");
        return -1;
    }

    /*Check 24bit-1channel mode setting */
    if((pData->rdr.out_ch == 1) && (pData->pwdsz == 24))
    {
        printf("\nParameters file is wrong. Current hardware do not support 24bit-1channel mode\n");
        return -1;
    }

    /*Check mix control setting */
    if((pData->rdr.mix_ctrl != 1) && (pData->rdr.mix_ctrl != 0))
    {
        printf("\nParameters file is wrong. Please input correct renderer mix control flags 0/1\n");
        return -1;
    }

    return 0;
}

/*******************************************************************************
 * cap_config file parameters checking function
 ******************************************************************************/
static int cap_param_ok(TEST_DATA *pData, float voltemp)
{
    /*check volume rate setting */
    if(((voltemp < 0) || (voltemp > 8)) && (voltemp != -1))
    {
        printf("\nCapture volume control error.\nPlease input volume gain from 0 to 8 or disable DVC module by inputing volume gain = -1\n");
        return -1;
    }

    /*Check DMA channel 1 setting */
    if ((pData->cap.dmachannel1 > 60) || (pData->cap.dmachannel1 < 0))
    {
        printf("\nParameters file is wrong. Please input correct capture DMA channel 1 \n"
                "from ADMAC_CH00 to ADMAC_CH31 \n"
                "or from ADMACPP_CH00 to ADMACPP_CH28 \n");
        return -1;
    }

    /*Check DMA channel 2 setting */
    if ((pData->cap.dmachannel2 > 60) || (pData->cap.dmachannel2 < 0))
    {
        printf("\nParameters file is wrong. Please input correct capture DMA channel 2 \n"
                "from ADMAC_CH00 to ADMAC_CH31 \n"
                "or from ADMACPP_CH00 to ADMACPP_CH28 \n");
        return -1;
    }

    /*Check input source 1 setting */
    if ((pData->cap.input1 != SSI00) &&
        (pData->cap.input1 != SSI10) &&
        (pData->cap.input1 != SSI20) &&
        (pData->cap.input1 != SSI30) &&
        (pData->cap.input1 != SSI40) &&
        (pData->cap.input1 != SSI50) &&
        (pData->cap.input1 != SSI60) &&
        (pData->cap.input1 != SSI70) &&
        (pData->cap.input1 != SSI80) &&
        (pData->cap.input1 != SSI90) &&
        ((pData->cap.input1 < SCU_SRCI0) || (pData->cap.input1 > SCU_SRCI9)) &&
        (pData->cap.input1 != NONCONFIG))
    {
        printf("\nParameters file is wrong. Please input correct capture input source 1 \n"
                "SSI10 "
                "or from SRC0 to SRC9 \n");
        return -1;
    }

    /*Check input source 2 setting */
    if ((pData->cap.input2 != SSI00) &&
        (pData->cap.input2 != SSI10) &&
        (pData->cap.input2 != SSI20) &&
        (pData->cap.input2 != SSI30) &&
        (pData->cap.input2 != SSI40) &&
        (pData->cap.input2 != SSI50) &&
        (pData->cap.input2 != SSI60) &&
        (pData->cap.input2 != SSI70) &&
        (pData->cap.input2 != SSI80) &&
        (pData->cap.input2 != SSI90) &&
        ((pData->cap.input2 < SCU_SRCI0) || (pData->cap.input2 > SCU_SRCI9)) &&
        (pData->cap.input2 != NONCONFIG))
    {
        printf("\nParameters file is wrong. Please input correct capture input source 2 \n"
                "SSI10 "
                "or from SRC0 to SRC9 \n");
        return -1;
    }

    /*Check in sampling rate setting */
    if ((pData->cap.infs != 48000) && (pData->cap.infs != 44100) && (pData->cap.infs != 32000))
    {
        printf("\nParameters file is wrong. Please input correct capture input sampling rate 32000/44100/48000\n");
        return -1;
    }

    /*Check out sampling rate setting */
    if ((pData->cap.outfs != 48000) && (pData->cap.outfs != 44100) && (pData->cap.outfs != 32000))
    {
        printf("\nParameters file is wrong. Please input correct capture output sampling rate 32000/44100/48000\n");
        return -1;
    }

    /*Check framesize setting */
    if ((pData->cap.framesize != 1024) &&
        (pData->cap.framesize != 2048))
    {
        printf("\nParameters file is wrong. Please input correct capture frame size 1024/2048\n");
        return -1;
    }

    /*Check channel setting */
    if((pData->channels != 1) && (pData->channels != 2))
    {
        printf("\nParameters is wrong. Please input correct number of channel 1/2\n");
        return -1;
    }

    /*Check PCM Width setting */
    if((pData->pwdsz != 16) && (pData->pwdsz != 24))
    {
        printf("\nParameters is wrong. Please input correct PCM Width 16/24\n");
        return -1;
    }

    /*Check 24bit-1channel mode setting */
    if((pData->channels == 1) && (pData->pwdsz == 24))
    {
        printf("\nParameters is wrong. Current hardware do not support 24bit-1channel mode\n");
        return -1;
    }

    return 0;
}

/*******************************************************************************
 * Read the source or destination setting for plugin
 ******************************************************************************/
static int src_dst(char *string)
{
    int result = SRC_DST_MAX;
    if((strstr(string, "SSI")) != NULL)
    {
        sscanf(string, "SSI%d", &result);
    }
    else if ((strstr(string, "SRC")) != NULL)
    {
        sscanf(string, "SRC%d", &result);
        result = result + SCU_SRCI0;
    }
    else if ((strstr(string, "CMD")) != NULL)
    {
        sscanf(string, "CMD%d", &result);
        result = result + SCU_CMD0;
    }
    else if ((strstr(string, "NONCONFIG")) != NULL)
    {
        result = NONCONFIG;
    }

    return result;
}

/*******************************************************************************
 * Read file.wav header test
 ******************************************************************************/
static int wav_read(wav_header_info *wav_info, FILE *wav_file)
{
    char buf[MAX_LENGTH];
    OMX_U32 chunk_size;
    OMX_U32 pcm_data_pos = 0;
    int length;

    /* ...read WAVE ID */
    fread(wav_info, sizeof(wav_header_info), 1, wav_file);

    /* ...check if input file is WAV file */
    if(wav_info->ck_id[0] != 'R' || wav_info->ck_id[1] != 'I' || wav_info->ck_id[2] != 'F' || wav_info->ck_id[3] != 'F')
    {
        fseek(wav_file, 0, SEEK_SET);
        return 0;
    }

    /* ...reading "data" chunk info */
    fread(buf, sizeof(char), 4, wav_file);

    /* ...reading wav data length info */
    fread(&length, sizeof(int), 1, wav_file);

    return length;
}

/*******************************************************************************
 * Main process: Process read files
 ******************************************************************************/
int set_data_structure(TEST_DATA *pData)
{
    int pos = 0;
    /*******************************************************************************
     * Reading equalizer file.txt test
     ******************************************************************************/	
    if (strcmp(pData->config_name, "") != 0)
    {
        char 			filter_type_temp[16];
        char 			ch;
        int 			i = 0;
        char 			buf[MAX_LENGTH];
        FILE			*set_param_file;

        /** open file */
        set_param_file = fopen(pData->config_name, "r");

        if (set_param_file == NULL)
        {
            printf("Cannot open equalizer configuration file\n");
            return -1;
        }

        /** get each line in file and process */
        while (NULL != fgets(buf, MAX_LENGTH, set_param_file))
        {
            if (!strcmp(buf, "Parametric\n") ||
                !strcmp(buf, "Parametric\r\n") ||
                !strcmp(buf, "Graphic\n") ||
                !strcmp(buf, "Graphic\r\n"))
            {
                if(!strcmp(buf, "Parametric\n") || !strcmp(buf, "Parametric\r\n"))
                {
                    pData->eqz.type = XA_REL_EQZ_TYPE_PARAMETRIC;
                }
                else
                {
                    pData->eqz.type = XA_REL_EQZ_TYPE_GRAPHIC;
                }

                continue;
            }

            if (*buf == '#')
            {
                continue;
            }

            if ( (pData->eqz.type == XA_REL_EQZ_TYPE_PARAMETRIC) )
            {
                sscanf(buf, "%c %d %lf %lf %lf",
                    &filter_type_temp[i],
                    &pData->eqz.frequency_center[i],
                    &pData->eqz.band_width[i],
                    &pData->eqz.gain[i],
                    &pData->eqz.gain_base[i]);

                switch (filter_type_temp[i])
                {
                    case 'P':
                    {
                        pData->eqz.filter_type[i] = XA_REL_EQZ_TYPE_PEAK;
                        break;
                    }
                    case 'T':
                    {
                        pData->eqz.filter_type[i] = XA_REL_EQZ_TYPE_THROUGH;
                        break;
                    }
                    case 'B':
                    {
                        pData->eqz.filter_type[i] = XA_REL_EQZ_TYPE_BASS;
                        break;
                    }
                    case 'R':
                    {
                        pData->eqz.filter_type[i] = XA_REL_EQZ_TYPE_TREBLE;
                        break;
                    }
                    default:
                    {
                        puts("Unrecognized equalizer type!");
                        break;
                    }
                }

                i++;
            }
            else if( (pData->eqz.type == XA_REL_EQZ_TYPE_GRAPHIC) )
            {
                sscanf(buf, "%lf", &pData->eqz.graphic_gain[i]);
                i++;
            }

            printf("%s\n", buf);
        }

        fclose(set_param_file);
    }

#if !DEV
    /*******************************************************************************
     * Reading capfile.txt test
     ******************************************************************************/
    if (strcmp(pData->capconfig_name, "") != 0)
    {
        char 			buf[MAX_LENGTH];
        FILE			*set_param_file;
        char			*dmach1;
        char			*input1;
        char			*dmach2;
        char			*input2;
        float			voltemp;

        dmach1 = malloc(100*sizeof(char));
        dmach2 = malloc(100*sizeof(char));
        input1 = malloc(100*sizeof(char));
        input2 = malloc(100*sizeof(char));

        /** open file */
        set_param_file = fopen(pData->capconfig_name, "r");

        if (set_param_file == NULL)
        {
            printf("Cannot open capture configuration file\n");
            return -1;
        }

        /** get each line in file and process */
        while (NULL != fgets(buf, MAX_LENGTH, set_param_file))
        {
            if (*buf == '#')
            {
                continue;
            }

            sscanf(buf, "%d %d %s %s %s %s %f %d",
                &pData->cap.infs,
                &pData->cap.outfs,
                dmach1,
                input1,
                dmach2,
                input2,
                &voltemp,
                &pData->cap.framesize);

            printf("%s\n", buf);
        }

        fclose(set_param_file);

        /* Processing parameters */
        pData->cap.dmachannel1 = dmach(dmach1);
        pData->cap.input1 = src_dst(input1);
        pData->cap.dmachannel2 = dmach(dmach2);
        pData->cap.input2 = src_dst(input2);

        if(voltemp == -1)
        {
            pData->cap.outvol = 0xFFFFFFFF;
        }
        else if(voltemp == 8)
        {
            pData->cap.outvol = 0x7FFFFF;
        }
        else
        {
            pData->cap.outvol = (OMX_U32)(voltemp * (1 << 20));
        }

        free(dmach1);
        free(dmach2);
        free(input1);
        free(input2);

        if(cap_param_ok(pData,voltemp) < 0)
        {
            return -1;
        }
    }

    /*******************************************************************************
     * Reading rdrfile.txt test
     ******************************************************************************/
    if (strcmp(pData->rdrconfig_name, "") != 0)
    {
        char 			buf[MAX_LENGTH];
        FILE			*set_param_file;
        char			*dmach1;
        char			*output1;
        char			*dmach2;
        char			*output2;
        float			voltemp;

        dmach1 = malloc(100*sizeof(char));
        dmach2 = malloc(100*sizeof(char));
        output1 = malloc(100*sizeof(char));
        output2 = malloc(100*sizeof(char));

        /** open file */
        set_param_file = fopen(pData->rdrconfig_name, "r");

        if (set_param_file == NULL)
        {
            printf("Cannot open renderer configuration file\n");
            return -1;
        }

        /** get each line in file and process */
        while (NULL != fgets(buf, MAX_LENGTH, set_param_file))
        {
            if (*buf == '#')
            {
                continue;
            }

            sscanf(buf, "%d %d %s %s %s %s %f %d %d %d %d",
                &pData->rdr.infs,
                &pData->rdr.outfs,
                dmach1,
                output1,
                dmach2,
                output2,
                &voltemp,
                &pData->rdr.framesize,
                &pData->rdr.in_ch,
                &pData->rdr.out_ch,
                &pData->rdr.mix_ctrl);

            printf("%s\n", buf);
        }

        fclose(set_param_file);

        /* Processing parameters */
        pData->rdr.dmachannel1 = dmach(dmach1);
        pData->rdr.output1 = src_dst(output1);
        pData->rdr.dmachannel2 = dmach(dmach2);
        pData->rdr.output2 = src_dst(output2);

        if(voltemp == -1)
        {
            pData->rdr.outvol = 0xFFFFFFFF;
        }
        else if(voltemp == 8)
        {
            pData->rdr.outvol = 0x7FFFFF;
        }
        else
        {
            pData->rdr.outvol = (OMX_U32)(voltemp * (1 << 20));
        }

        free(dmach1);
        free(dmach2);
        free(output1);
        free(output2);

        /*Check rdr_config file parameters */
        if (rdr_param_ok(pData,voltemp) < 0)
        {
            return -1;
        }
    }
#endif

    /*******************************************************************************
     * Reading WAVE file
     ******************************************************************************/
    if ( !CAPTURE_ENABLE(pData->eos) )
    {
        FILE *wav_file;
        wav_file = fopen(pData->input_name, "rb");

        if (NULL == wav_file)
        {
            printf("Cannot open file %s\n", pData->input_name);
            return -1;
        }

        pos = wav_read(&pData->wav, wav_file);
        pData->wav_length = pos;

        if (pos == 0)
        {
            fclose(wav_file);
            return 0;
        }

        pData->iwav = 1;
        /* ...update data information*/
        pData->channels = pData->wav.nChannel;
        pData->rdr.in_ch = pData->wav.nChannel;
        pData->eqzfs = pData->wav.nSamplingRate;
        pData->rdr.infs = pData->wav.nSamplingRate;
        pData->pwdsz = pData->wav.nBitPerSample;

        fclose(wav_file);
    }

    return 0;
}

/*******************************************************************************
 * Process user volume update thread
 ******************************************************************************/
static void user_thread(void *arg)
{
    char tmp[3] = {0};

    for (;;)
    {
        fgets(tmp, sizeof(tmp), stdin);

        if(tmp[0] == 'u')
        {
            pthread_mutex_lock(&user_lock);
            g_vol_up_cmd = 1;
            pthread_mutex_unlock(&user_lock);
        }
        else if(tmp[0] == 'd')
        {
            pthread_mutex_lock(&user_lock);
            g_vol_down_cmd = 1;
            pthread_mutex_unlock(&user_lock);
        }
        else if(tmp[0] == 's')
        {
            pthread_mutex_lock(&user_lock);
            g_stop_cmd = 1;
            pthread_mutex_unlock(&user_lock);
        }

        tmp[0] = 0;
    }
}

/*******************************************************************************
 * Input thread
 ******************************************************************************/
static void input_thread(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    FILE	*file;
    int count, size;
    int i, j, idx;
    file = fopen(pData->input_name, "rb");

    queue_i = (EQUALIZER_ENABLE(pData->eos) ? pData->eqz_inport_def.nBufferCountActual : pData->rdr_inport_def.nBufferCountActual);
    count = queue_i;
    phandle = (EQUALIZER_ENABLE(pData->eos) ? pData->pEqualizer : pData->pRenderer);

    i = 0;
    if(pData->iwav)
    {
        fseek(file, sizeof(wav_header_info) + 8, SEEK_SET);
        pBuffer = bufin[i++];
        j = 0;
        for(idx = 0; idx < pBuffer->nAllocLen; idx+=1)
        {
            pBuffer->nFilledLen += fread(pBuffer->pBuffer + j, sizeof(OMX_U8), 1, file);
            j+= 1;
        }
        OMX_EmptyThisBuffer(phandle, pBuffer);
        queue_i--;
    }
    while(1)
    {
        pthread_mutex_lock(&event_lock);
        if (pluginerror == 1)
        {
            pthread_mutex_unlock(&event_lock);
            break;
        }
        else
        {
            pthread_mutex_unlock(&event_lock);
        }

        pthread_mutex_lock(&input_lock);
        if(queue_i)
        {
            pthread_mutex_unlock(&input_lock);
            pBuffer = bufin[i++];
            for(idx = 0; idx < pBuffer->nAllocLen; idx += 4)
                pBuffer->nFilledLen += fread(pBuffer->pBuffer + idx, sizeof(OMX_U8), 4, file);
            if(pBuffer->nFilledLen == 0)
            {
                pBuffer->nFlags |= OMX_BUFFERFLAG_EOS;
                fclose(file);

                while(1)
                {
                    pthread_mutex_lock(&input_lock);
                    if(queue_i == count)
                    {
                        pthread_mutex_unlock(&input_lock);
                        break;
                    }
                    pthread_mutex_unlock(&input_lock);

		    /* check the error from ADSP and return */
		    pthread_mutex_lock(&event_lock);
		    if (pluginerror == 1)
		    {
		        pthread_mutex_unlock(&event_lock);
		        break;
		    }
		    else
		    {
		        pthread_mutex_unlock(&event_lock);
		    }
                }

                pthread_mutex_lock(&end_lock);
                g_end = 1;
                pthread_mutex_unlock(&end_lock);

                if(EQUALIZER_ENABLE(pData->eos))
                {
                    OMX_EmptyThisBuffer(pData->pEqualizer, pBuffer);
                }
                if(RENDERER_ENABLE(pData->eos))
                {
                    if(!EQUALIZER_ENABLE(pData->eos))
                    {
                        OMX_EmptyThisBuffer(pData->pRenderer, pBuffer);
                    }
                }

                break;
            }

            OMX_EmptyThisBuffer(phandle, pBuffer);

            pthread_mutex_lock(&input_lock);
            queue_i--;
            pthread_mutex_unlock(&input_lock);

            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&input_lock);
        }
    }

    pthread_exit(NULL);
}

/*******************************************************************************
 * Output thread
 ******************************************************************************/
static void output_thread(void *arg)
{
    TEST_DATA *pData = (TEST_DATA*)arg;
    OMX_HANDLETYPE *phandle;
    OMX_BUFFERHEADERTYPE *pBuffer;
    int i, j;
    FILE *file;

    i = 0;
    j = 0;
    file = fopen(pData->output_name, "wb");

    queue_o = (EQUALIZER_ENABLE(pData->eos) ? pData->eqz_outport_def.nBufferCountActual : pData->cap_outport_def.nBufferCountActual);

    phandle = (EQUALIZER_ENABLE(pData->eos) ? pData->pEqualizer : pData->pCapture);

    /* ...output to PCM file */
    while(1)
    {
        pthread_mutex_lock(&event_lock);
        if ((pluginerror == 1) || (last_buff == 1))
        {
            pthread_mutex_unlock(&event_lock);
            break;
        }
        else
        {
            pthread_mutex_unlock(&event_lock);
        }

        pthread_mutex_lock(&end_lock);
        if (g_end == 1)
        {
            pthread_mutex_unlock(&end_lock);

            while (queue_o != 0)
            {
                pBuffer = bufou[i];

                OMX_FillThisBuffer(phandle, pBuffer);

                queue_o--;

                i++;
                if(i >= NUMBER_OF_BUFFERS)
                {
                    i = 0;
                }
            }
        }
        else if(queue_o)
        {
            pthread_mutex_unlock(&end_lock);

            pBuffer = bufou[i];

            OMX_FillThisBuffer(phandle, pBuffer);

            queue_o--;

            i++;
            if(i >= NUMBER_OF_BUFFERS)
            {
                i = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&end_lock);
        }

        pthread_mutex_lock(&output_lock);
        if(queue_d)
        {
            pthread_mutex_unlock(&output_lock);
            pBuffer = bufou[j];

            /* check the response message length */
            if (pBuffer->nFilledLen != 0)
            {
                fwrite(pBuffer->pBuffer, sizeof(OMX_U8), pBuffer->nFilledLen, file);
            }
            else
            {
                pthread_mutex_lock(&end_lock);
                if (g_end == 1)
                {
                    pthread_mutex_unlock(&end_lock);

                    pthread_mutex_lock(&event_lock);
                    last_buff = 1;
                    pthread_mutex_unlock(&event_lock);
                }
                else
                {
                    pthread_mutex_unlock(&end_lock);
                }
            }

            pthread_mutex_lock(&output_lock);
            queue_d--;
            pthread_mutex_unlock(&output_lock);

            queue_o++;

            j++;
            if(j >= NUMBER_OF_BUFFERS)
            {
                j = 0;
            }
        }
        else
        {
            pthread_mutex_unlock(&output_lock);
        }
    }

    pthread_exit(NULL);
}

/*******************************************************************************
 * Print help menu
 ******************************************************************************/
#if !DEV
static void help()
{
    printf("ADSP Smoke Test program Help Menu\n"
            "command: adsp-omx-launch -i <input> -o <output> [-<command> <value>]\n"
            "-i <name>       : Input file (.pcm or .wav) or Input device (capture)\n"
            "-o <name>       : Output file (.pcm) or Output device (renderer)\n"
            "-eq <value>     : Enable/Disable equalizer (on/off) (default: off)\n"
            "-w <value>      : PCM Bit per sample (16/24) (Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)\n"
            "-c <value>      : PCM channel number for Capture and Equalizer (1/2) (Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)\n"
            "-eqzfs <value>  : Equalizer PCM sampling frequency(32000/44100/48000)\n"
            "-l <value>      : Recording time (second)\n"
            "-eqz <name>     : Equalizer configuration file\n"
            "-cap <name>     : Capture configuration file\n"
            "-rdr <name>     : Renderer configuration file\n"
            "-card <name>    : Select audio card\n\n"
            "Equalizer configuration file example\n"
            "1. Parametric configuration file\n"
            " - Start 1st line with \"Parametric\" identity\n"
            " - 2nd line to 10th line will contain information structure like below:\n"
            "   \nType Fc Bandwidth Gain BaseGain\n"
            " - Type: Filter type (P: Peak, T: Treble, B: Bass, R: Through\n"
            " - Fc: Frequency center (Peak|Through: 20-20000, Treble: 5000-11000, Bass: 50-500)\n"
            " - Bandwidth: 0.5 - 15\n"
            " - Gain (dB): -15.0 - 15.0\n"
            " - BaseGain (dB): -10.0 - 10.0\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "Parametric\n"
            "P 20000 0.2 10.0 5.0\n"
            "R 8000 1.0 0.5 5.0\n"
            "T 18000 12.0 5.5 1.0\n"
            "B 400 14.0 1.6 6.4\n"
            "P 11000 8.4 6.4 7.1\n"
            "B 50 2.5 6.5 4.1\n"
            "B 100 8.6 1.5 4.6\n"
            "R 5000 2.5 6.4 5.5\n"
            "T 1200 1.6 4.5 4.5\n"
            "--------------------------------------------------------------------\n"
            "\n2. Graphic configuration file\n"
            " - Start 1st line with \"Graphic\" identity\n"
            " - 2nd line to 6th line with Gain (-10.0 - 10.0) dB value\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "Graphic\n"
            "-8.0\n"
            "10.0\n"
            "0.0\n"
            "6.0\n"
            "-6.0\n"
            "--------------------------------------------------------------------\n"
            "\nCapture configuration file example\n"
            "Parameters will be set in a row follow the order\n"
            "In_fs Out_fs Dmach1 Input1 Dmach2 Input2 Volume Framesize\n"
            "Parameters meaning:\n"
            "In_fs           : Capture input sampling frequency(32000/44100/48000). (*)\n"
            "Out_fs          : Capture output sampling frequency (32000/44100/48000).\n"
            "Dmach1          : Capture DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "Input1          : Capture input source 1(SSI10/SRC0 to SRC9) \n"
            "Dmach2          : Capture DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "Input2          : Capture input source 2(SSI10/NONCONFIG). If Input1 is SSI10, this value must be NONCONFIG\n"
            "Volume          : Capture volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1) (**)\n"
            "Framesize       : Capture frame size(1024/2048) (***)\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI10 1 1024\n"
            "--------------------------------------------------------------------\n"
            "\nRenderer configuration file example\n"
            "Parameters will be set in a row follow the order\n"
            "In_fs Out_fs Dmach1 Output1 Dmach2 Output2 Volume Framesize\n"
            "Parameters meaning:\n"
            "In_fs           : Renderer input sampling frequency(32000/44100/48000).\n"
            "Out_fs          : Renderer output sampling frequency (32000/44100/48000). (*)\n"
            "Dmach1          : Renderer DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "Output1         : Renderer output source 1(SSI00/SRC0 to SRC9) \n"
            "Dmach2          : Renderer DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "Output2         : Renderer output source 2(SSI00/NONCONFIG). If Output1 is SSI00, this value must be NONCONFIG\n"
            "Volume          : Renderer volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1) (**)\n"
            "Framesize       : Renderer frame size(1024/2048) (***)\n"
            "In_channel      : Number of Renderer in_channel (1/2/4/6/8)\n"
            "Out_channel     : Number of Renderer out channel (1/2)\n"
            "Mix_control     : Renderer 's mixer function control bit (0: Disable mixer, 1: Enable mixer) (**)\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "32000 48000 ADMACPP_CH15 SRC0 ADMACPP_CH00 SSI00 1 1024 2 2 0\n"
            "--------------------------------------------------------------------\n"
            "\nNote:\n"
            "(*) When routing between Capture-Renderer and using SRC, In_fs of Capture and Out_fs of Renderer must be the same.\n\n"
            "(**) Because hardware limitation has only 2 CMD modules."
            " Therefore, user can only use volume control or mixing stream up to maximum 2 different SSI output .\n\n"
            "(***) When two or more components are routing, framesize of each component must be the same. \n"
            " When two or more components are routing, framesize is only supported 1024.\n"
            " When component is run independently, framesize is supported 1024/2048.\n"
    );
}
#else
static void help()
{
    printf("ADSP Smoke Test program Help Menu\n"
            "command: adsp-omx-launch -i <input> -o <output> [-<command> <value>]\n"
            "-i <name>       : Input file (.pcm or .wav) or Input device (capture)\n"
            "-o <name>       : Output file (.pcm) or Output device (renderer)\n"
            "-eq <value>     : Enable/Disable equalizer (on/off) (default: off)\n"
            "-w <value>      : PCM Bit per sample (16/24) (Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)\n"
            "-c <value>      : PCM channel number for Capture and Equalizer (1/2) (Supporting mode is 24bit-2channel, 16bit-2channel, 16bit-1channel)\n"
            "-eqzfs <value>  : Equalizer PCM sampling frequency(32000/44100/48000)\n"
            "-l <value>      : Recording time (second)\n"
            "-eqz <name>     : Equalizer configuration file\n"
            "-card <name>    : Select audio card\n\n"
            "-capinfs <value>        : Capture input sampling frequency(32000/44100/48000).(*)\n"
            "-capoutfs <value>       : Capture output sampling frequency (32000/44100/48000).\n"
            "-capdmachannel1 <name>  : Capture DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "-capinsource1 <name>    : Capture input source 1(SSI10/SRC0 to SRC9)\n"
            "-capdmachannel2 <name>  : Capture DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "-capinsource2 <name>    : Capture input source 2(SSI10/NONCONFIG). If Input1 is SSI10, this value must be NONCONFIG\n"
            "-capvol <value>         : Capture volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1)(**)\n"
            "-capframe <value>       : Capture frame size(1024/2048) (***)\n\n"
            "-rdrinfs <value>        : Renderer input sampling frequency(32000/44100/48000).\n"
            "-rdroutfs <value>       : Renderer output sampling frequency (32000/44100/48000).(*)\n"
            "-rdrdmachannel1 <name>  : Renderer DMA channel1(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "-rdroutsource1 <name>   : Renderer output source 1(SSI00/SRC0 to SRC9)\n"
            "-rdrdmachannel2 <name>  : Renderer DMA channel2(ADMAC_CH00 to ADMAC_CH31/ADMACPP_CH00 to ADMACPP_CH28)\n"
            "-rdroutsource2 <name>   : Renderer output source 2(SSI00/NONCONFIG). If Output1 is SSI00, this value must be NONCONFIG\n"
            "-rdrvol <value>         : Renderer volume gain (gain from 0 to 8. If DVC module is not used, this value must be -1)(**)\n"
            "-rdrframe <value>       : Renderer frame size(1024/2048) (***)\n"
            "-rdrinch <value>        : Numbers of renderer in_channel (1/2/4/6/8)\n"
            "-rdroutch <value>       : Numbers of renderer out_channel (1/2)\n"
            "-rdrmix <value>         : Renderer 's mixer function control bit (0: Disable mixer, 1: Enable mixer) (**)\n\n"

            "Equalizer configuration file example\n"
            "1. Parametric configuration file\n"
            " - Start 1st line with \"Parametric\" identity\n"
            " - 2nd line to 10th line will contain information structure like below:\n"
            "   \nType Fc Bandwidth Gain BaseGain\n"
            " - Type: Filter type (P: Peak, T: Treble, B: Bass, R: Through\n"
            " - Fc: Frequency center (Peak|Through: 20-20000, Treble: 5000-11000, Bass: 50-500)\n"
            " - Bandwidth: 0.5 - 15\n"
            " - Gain (dB): -15.0 - 15.0\n"
            " - BaseGain (dB): -10.0 - 10.0\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "Parametric\n"
            "P 20000 0.2 10.0 5.0\n"
            "R 8000 1.0 0.5 5.0\n"
            "T 18000 12.0 5.5 1.0\n"
            "B 400 14.0 1.6 6.4\n"
            "P 11000 8.4 6.4 7.1\n"
            "B 50 2.5 6.5 4.1\n"
            "B 100 8.6 1.5 4.6\n"
            "R 5000 2.5 6.4 5.5\n"
            "T 1200 1.6 4.5 4.5\n"
            "--------------------------------------------------------------------\n"
            "\n2. Graphic configuration file\n"
            " - Start 1st line with \"Graphic\" identity\n"
            " - 2nd line to 6th line with Gain (-10.0 - 10.0) dB value\n"
            "\nExample:\n"
            "--------------------------------------------------------------------\n"
            "Graphic\n"
            "-8.0\n"
            "10.0\n"
            "0.0\n"
            "6.0\n"
            "-6.0\n"
            "--------------------------------------------------------------------\n"
            "\nNote:\n"
            "(*) When routing between Capture-Renderer and using SRC, In_fs of Capture and Out_fs of Renderer must be the same.\n\n"
            "(**) Because hardware limitation has only 2 CMD modules."
            " Therefore, user can only use volume control or mixing stream up to maximum 2 different SSI output .\n\n"
            "(***) When two or more components are routing, framesize of each component must be the same. \n"
            " When two or more components are routing, framesize is only supported 1024.\n"
            " When component is run independently, framesize is supported 1024/2048.\n"
    );
}
#endif

/*******************************************************************************
 * Main program
 ******************************************************************************/
int main(int argc, char *argv[])
{
    int                             snd_open_status;
    int 							i, j;
#ifdef TARGET_ANDROID
    struct pcm           			*alsa_out, *alsa_in;
#else
    snd_pcm_t           			*alsa_out, *alsa_in;
#endif
    OMX_ERRORTYPE       			status_code;
    OMX_PTR             			pCmd = NULL;

    OMX_AUDIO_PARAM_PCMMODETYPE 	eqz_pcmin_params;
    OMX_AUDIO_PARAM_PCMMODETYPE		eqz_pcmout_params;
    OMX_AUDIO_PARAM_PCMMODETYPE 	cap_pcmout_params;
    OMX_AUDIO_PARAM_PCMMODETYPE 	rdr_pcmin_params;

    XAOMX_AUDIO_PARAM_CAPTURE		cap_params;
    XAOMX_AUDIO_PARAM_EQUALIZER		eqz_params;
    XAOMX_AUDIO_PARAM_RENDERER		rdr_params;

    OMX_BUFFERHEADERTYPE 			*pBuffer;
    OMX_STATETYPE       			state;
    int 							length_temp;
    char 							*s;
    
    volatile int        			endFlag = 0;
    pthread_t						input_id, output_id, user_id;
    TEST_DATA 						data;
    float                           vol_step;
    char                            *cardname;

#ifdef TARGET_ANDROID
    int card_idx = 1, dev_idx = 0;

    struct pcm_config pcm_config_dac = {0};
    pcm_config_dac.channels = 2;
    pcm_config_dac.rate = 44100;
    pcm_config_dac.period_size = 512;
    pcm_config_dac.period_count = 4;
    pcm_config_dac.format = PCM_FORMAT_S16_LE;
#endif

    /** initialize data */
    snd_open_status = 0;
    queue_i = 0;
    queue_o = 0;
    queue_d = 0;
    g_end = 0;
    data.eos = 0;
    data.channels = 2;
    data.pwdsz = 16;
    data.eqzfs = 44100;
    data.input_name = "";
    data.output_name = "";
    data.config_name = "";
    data.capconfig_name = "";
    data.rdrconfig_name = "";
    data.ts = 0;
    data.iwav = 0;
    pluginerror = 0;
    g_stop_cmd = 0;
    g_vol_down_cmd = 0;
    g_vol_up_cmd = 0;
    vol_step = 0.5;
    cardname = "default";
    last_buff = 0;

    cap_params.nPCM_DMAchannel2 = ADMACPP_CH02;
    cap_params.nPCM_input2 = NONCONFIG;
    cap_params.nPCM_DMAchannel1 = ADMACPP_CH10;
    cap_params.nPCM_input1 = SSI10;
    cap_params.nPCM_in_sample_rate = 44100;
    cap_params.nPCM_out_sample_rate = 44100;
    cap_params.nPCM_volume_rate = 0xFFFFFFFF;
	cap_params.nPCM_frame_size = 1024;

    rdr_params.nPCM_DMAchannel2 = ADMACPP_CH01;
    rdr_params.nPCM_output2 = NONCONFIG;
    rdr_params.nPCM_DMAchannel1 = ADMACPP_CH00;
    rdr_params.nPCM_output1 = SSI00;
    rdr_params.nPCM_in_sample_rate = 44100;
    rdr_params.nPCM_out_sample_rate = 44100;
    rdr_params.nPCM_volume_rate = 0xFFFFFFFF;
    rdr_params.nPCM_frame_size = 1024;
    rdr_params.nPCM_in_channel = 2;
    rdr_params.nPCM_out_channel = 2;
    rdr_params.nPCM_mix_control = 0;

#if !DEV
    if(argc == 1)
    {
        help();
        return 0;
    }

    /** processing user's input */
    for (i = 1; i < argc; i++)
    {
        /** check if user input -i */
        if (strcmp(argv[i], "-i") == 0)
        {
            i++;
            if (strcmp(argv[i],"capture") == 0)
            {
                data.eos |= CAPTURE_ON;
            }
            else
            {
                data.input_name = argv[i];
            }
        }
        else if (strcmp(argv[i], "-o") == 0)
        {
            i++;
            if (strcmp(argv[i], "renderer") == 0)
            {
                data.eos |= RENDERER_ON;
            }
            else
            {
                data.output_name = argv[i];
            }
        }
        else if (strcmp(argv[i], "-eq") == 0)
        {
            i++;
            if (strcmp(argv[i], "on") == 0)
            {
                data.eos |= EQUALIZER_ON;
            }
        }
        else if (strcmp(argv[i], "-eqz") == 0)
        {
            i++;
            data.config_name = argv[i];
        }
        else if (strcmp(argv[i], "-w") == 0)
        {
            i++;
            data.pwdsz = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-c") == 0)
        {
            i++;
            data.channels = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-eqzfs") == 0)
        {
            i++;
            data.eqzfs = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-l") == 0)
        {
            i++;
            data.ts = atoi(argv[i]);
        }

        /* Capture parameters structure */
        else if (strcmp(argv[i], "-cap") == 0)
        {
            i++;
            data.capconfig_name = argv[i];
        }

        /* Renderer parameters structure */
        else if (strcmp(argv[i], "-rdr") == 0)
        {
            i++;
            data.rdrconfig_name = argv[i];
        }

        /* Select card name */
        else if (strcmp(argv[i], "-card") == 0)
        {
            i++;
#ifdef TARGET_ANDROID
            sscanf(argv[i], "%d,%d", &card_idx, &dev_idx);
#else
            cardname = argv[i];
#endif
        }
    }
#else
    if(argc == 1)
    {
        help();
        return 0;
    }

    /** processing user's input */
    for (i = 1; i < argc; i++)
    {
        /** check if user input -i */
        if (strcmp(argv[i], "-i") == 0)
        {
            i++;
            if (strcmp(argv[i],"capture") == 0)
            {
                data.eos |= CAPTURE_ON;
            }
            else
            {
                data.input_name = argv[i];
            }
        }
        else if (strcmp(argv[i], "-o") == 0)
        {
            i++;
            if (strcmp(argv[i], "renderer") == 0)
            {
                data.eos |= RENDERER_ON;
            }
            else
            {
                data.output_name = argv[i];
            }
        }
        else if (strcmp(argv[i], "-eq") == 0)
        {
            i++;
            if (strcmp(argv[i], "on") == 0)
            {
                data.eos |= EQUALIZER_ON;
            }
        }
        else if (strcmp(argv[i], "-eqz") == 0)
        {
            i++;
            data.config_name = argv[i];
        }
        else if (strcmp(argv[i], "-w") == 0)
        {
            i++;
            data.pwdsz = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-c") == 0)
        {
            i++;
            data.channels = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-eqzfs") == 0)
        {
            i++;
            data.eqzfs = atoi(argv[i]);
        }
        else if (strcmp(argv[i], "-l") == 0)
        {
            i++;
            data.ts = atoi(argv[i]);
        }

        /* Capture parameters structure */
        else if (strcmp(argv[i], "-capframe") == 0)
         {
             i++;
             cap_params.nPCM_frame_size = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-capdmachannel1") == 0)
         {
             i++;
             cap_params.nPCM_DMAchannel1 = dmach(argv[i]);
         }
         else if (strcmp(argv[i], "-capinsource1") == 0)
         {
             i++;
             cap_params.nPCM_input1 = src_dst(argv[i]);
         }
         else if (strcmp(argv[i], "-capdmachannel2") == 0)
         {
             i++;
             cap_params.nPCM_DMAchannel2 = dmach(argv[i]);
         }
         else if (strcmp(argv[i], "-capinsource2") == 0)
         {
             i++;
             cap_params.nPCM_input2 = src_dst(argv[i]);
         }
         else if (strcmp(argv[i], "-capoutfs") == 0)
         {
             i++;
             cap_params.nPCM_out_sample_rate = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-capinfs") == 0)
         {
             i++;
             cap_params.nPCM_in_sample_rate = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-capvol") == 0)
         {
             float voltemp;
             i++;
             sscanf(argv[i], "%f", &voltemp);
             if(voltemp == -1)
             {
                 cap_params.nPCM_volume_rate = 0xFFFFFFFF;
             }
             else if((OMX_U32)(voltemp * (1 << 20)) > 0x7FFFFF)
             {
                 cap_params.nPCM_volume_rate = 0x7FFFFF;
             }
             else
             {
                 cap_params.nPCM_volume_rate = (OMX_U32)(voltemp * (1 << 20));
             }
         }

        /* Renderer parameters structure */
         else if (strcmp(argv[i], "-rdrframe") == 0)
         {
             i++;
             rdr_params.nPCM_frame_size = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrdmachannel1") == 0)
         {
             i++;
             rdr_params.nPCM_DMAchannel1 = dmach(argv[i]);
         }
         else if (strcmp(argv[i], "-rdroutsource1") == 0)
         {
             i++;
             rdr_params.nPCM_output1 = src_dst(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrdmachannel2") == 0)
         {
             i++;
             rdr_params.nPCM_DMAchannel2 = dmach(argv[i]);
         }
         else if (strcmp(argv[i], "-rdroutsource2") == 0)
         {
             i++;
             rdr_params.nPCM_output2 = src_dst(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrinfs") == 0)
         {
             i++;
             rdr_params.nPCM_in_sample_rate = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdroutfs") == 0)
         {
             i++;
             rdr_params.nPCM_out_sample_rate = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrinch") == 0)
         {
             i++;
             rdr_params.nPCM_in_channel = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdroutch") == 0)
         {
             i++;
             rdr_params.nPCM_out_channel = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrmix") == 0)
         {
             i++;
             rdr_params.nPCM_mix_control = atoi(argv[i]);
         }
         else if (strcmp(argv[i], "-rdrvol") == 0)
         {
             float voltemp;
             i++;
             sscanf(argv[i], "%f", &voltemp);
             if(voltemp == -1)
             {
                 rdr_params.nPCM_volume_rate = 0xFFFFFFFF;
             }
             else if((OMX_U32)(voltemp * (1 << 20)) > 0x7FFFFF)
             {
                 rdr_params.nPCM_volume_rate = 0x7FFFFF;
             }
             else
             {
                 rdr_params.nPCM_volume_rate = (OMX_U32)(voltemp * (1 << 20));
             }
         }
         /* Select card name */
         else if (strcmp(argv[i], "-card") == 0)
         {
             i++;
             cardname = argv[i];
         }
    }
#endif

    /*******************************************************************************
     * Calling Main_process
     ******************************************************************************/ 
    if (set_data_structure(&data) < 0)
        return 1;

    if( EQUALIZER_ENABLE(data.eos) )
    {
        /* ...get equalizer param from file if any*/
        if( strcmp(data.config_name, "") != 0)
        {
            if( data.eqz.type == XA_REL_EQZ_TYPE_PARAMETRIC )
            {
                eqz_params.Eqz_type = XA_REL_EQZ_TYPE_PARAMETRIC;
                for (i = 0; i < 9; i++)
                {
                    eqz_params.stEqCoef.Type[i] = data.eqz.filter_type[i];
                    eqz_params.stEqCoef.FreqCenter[i] = data.eqz.frequency_center[i];
                    eqz_params.stEqCoef.BandWidth[i] = (OMX_S32)(data.eqz.band_width[i] * (1 << 27));
                    eqz_params.stEqCoef.Gain[i] = (OMX_S32)(pow(10, data.eqz.gain[i] / 20) * (1 << 28));
                    eqz_params.stEqCoef.GainBase[i] = (OMX_S32)(pow(10, data.eqz.gain_base[i] / 20) * (1 << 28));
                }
            }
            else
            {
                eqz_params.Eqz_type = XA_REL_EQZ_TYPE_GRAPHIC;
                for (i = 0; i < 5; i++)
                {
                    eqz_params.stEqGCoef.Gain_g[i] = (OMX_S32)(pow(10, data.eqz.graphic_gain[i] / 20) * (1 << 28));
                }
            }
        }

        data.eqz_inport_def.nPortIndex = 0;
        data.eqz_outport_def.nPortIndex = 1;
    }

    if( RENDERER_ENABLE(data.eos) )
    {
#if !DEV
        /* ...get renderer param from file if any*/
        if( strcmp(data.rdrconfig_name, "") != 0)
        {
            rdr_params.nPCM_frame_size = data.rdr.framesize;
            rdr_params.nPCM_output1 = data.rdr.output1;
            rdr_params.nPCM_DMAchannel1 = data.rdr.dmachannel1;
            rdr_params.nPCM_output2 = data.rdr.output2;
            rdr_params.nPCM_DMAchannel2 = data.rdr.dmachannel2;
            rdr_params.nPCM_in_sample_rate = data.rdr.infs;
            rdr_params.nPCM_out_sample_rate = data.rdr.outfs;
            rdr_params.nPCM_volume_rate = data.rdr.outvol;
            rdr_params.nPCM_in_channel = data.rdr.in_ch;
            rdr_params.nPCM_out_channel = data.rdr.out_ch;
            rdr_params.nPCM_mix_control = data.rdr.mix_ctrl;
        }
#else
        /* update specific parameters if input .wav file  */
        if (data.iwav == 1)
        {
            rdr_params.nPCM_in_sample_rate = data.rdr.infs;
            rdr_params.nPCM_in_channel = data.rdr.in_ch;
        }
#endif

        data.rdr_inport_def.nPortIndex = 0;
        data.rdr_outport_def.nPortIndex = 1;
    }

    if( CAPTURE_ENABLE(data.eos) )
    {
#if !DEV
        /* ...get capture param from file if any*/
        if( strcmp(data.capconfig_name, "") != 0)
        {
            cap_params.nPCM_frame_size = data.cap.framesize;
            cap_params.nPCM_input1 = data.cap.input1;
            cap_params.nPCM_DMAchannel1 = data.cap.dmachannel1;
            cap_params.nPCM_input2 = data.cap.input2;
            cap_params.nPCM_DMAchannel2 = data.cap.dmachannel2;
            cap_params.nPCM_in_sample_rate = data.cap.infs;
            cap_params.nPCM_out_sample_rate = data.cap.outfs;
            cap_params.nPCM_volume_rate = data.cap.outvol;
        }
#endif

        data.cap_inport_def.nPortIndex = 0;
        data.cap_outport_def.nPortIndex = 1;
    }

    /* ...get user's input parameters to set */
    eqz_pcmin_params.nPortIndex = 0;
    eqz_pcmin_params.nChannels = data.channels;
    eqz_pcmin_params.nSamplingRate = data.eqzfs;
    eqz_pcmin_params.nBitPerSample = data.pwdsz;

    eqz_pcmout_params.nPortIndex = 1;
    eqz_pcmout_params.nChannels = data.channels;
    eqz_pcmout_params.nSamplingRate = data.eqzfs;
    eqz_pcmout_params.nBitPerSample = data.pwdsz;

    cap_pcmout_params.nPortIndex = 1;
    cap_pcmout_params.nChannels = data.channels;
    cap_pcmout_params.nBitPerSample = data.pwdsz;

    rdr_pcmin_params.nPortIndex = 0;
    rdr_pcmin_params.nBitPerSample = data.pwdsz;

    /* No component in use -> exit immediately */
    if(!data.eos)
    {
        return 0;
    }

    /*******************************************************************************
     * OMX Initialization
     ******************************************************************************/
    /* ...OMX test */
    if( (status_code = OMX_Init()) != OMX_ErrorNone )
    {
        printf("OMX Initialization failed!!!\n");
        return 1;
    }

    /*******************************************************************************
     * Components Initialization
     ******************************************************************************/
    if( CAPTURE_ENABLE(data.eos) )
    {
        int r;
        int alsa_fs;

        alsa_fs = cap_params.nPCM_in_sample_rate;
        if (alsa_fs == 0)
        {
            alsa_fs = cap_params.nPCM_out_sample_rate;
        }

        printf("alsa in sample rate %d\n", alsa_fs);

#ifdef TARGET_ANDROID
        /* modify for Android */
        alsa_in = pcm_open(card_idx, dev_idx, PCM_IN, &pcm_config_dac);
	    if ((alsa_in == NULL) || !pcm_is_ready(alsa_in) || (pcm_prepare(alsa_in) < 0)) {
            printf("cannot open pcm_in driver normal: %s", pcm_get_error(alsa_in));
            pcm_close(alsa_in);
            alsa_in = NULL;
            return -1;
        }
#else
        /* ...open PCM device for playback */
        if((r = snd_pcm_open(&alsa_in, cardname, SND_PCM_STREAM_CAPTURE, 0)) < 0)
        {
            printf("Failed to open pcm device: %s\n", snd_strerror(r));
            return r;
        }

        if (data.pwdsz == 16)
        {
            /* ...set ALSA parameters */
            if((r = snd_pcm_set_params(alsa_in, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, data.channels, alsa_fs, 0, 0)) < 0)
            {
                printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
                alsa_close(alsa_in);
                return r;
            }
        }
        else if (data.pwdsz == 24)
        {
            if((r = snd_pcm_set_params(alsa_in, SND_PCM_FORMAT_S24_LE, SND_PCM_ACCESS_RW_INTERLEAVED, data.channels, alsa_fs, 0, 0)) < 0)
            {
                printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
                alsa_close(alsa_in);
                return r;
            }
        }
#endif

        /* ...get Capture's handle */
        OMX_GetHandle(&data.pCapture, "OMX.RENESAS.AUDIO.DSP.CAPTURE", (OMX_PTR)&data, &callbacks_Cap);

        /* ..set parameters */
        OMX_SetParameter(data.pCapture, OMX_IndexParamAudioPcm, &cap_pcmout_params);
        OMX_SetParameter(data.pCapture, XAOMX_IndexParamAudioCapture, &cap_params);

        OMX_GetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_inport_def);
        OMX_GetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def);

        /* modify buffer size if needed*/
        if(data.pwdsz == 24)
        {
            data.cap_outport_def.nBufferAlignment = 32;
            data.cap_outport_def.nBufferSize = cap_params.nPCM_frame_size * cap_pcmout_params.nChannels * (32 >> 3);

            OMX_SetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def);
        }
        else if (data.pwdsz == 16)
        {
            data.cap_outport_def.nBufferAlignment = 32;
            data.cap_outport_def.nBufferSize = cap_params.nPCM_frame_size * cap_pcmout_params.nChannels * (cap_pcmout_params.nBitPerSample >> 3);

            OMX_SetParameter(data.pCapture, OMX_IndexParamPortDefinition, &data.cap_outport_def);
        }
    }

    if( EQUALIZER_ENABLE(data.eos) )
    {
        /* ...get Equalizer's handle */
        OMX_GetHandle(&data.pEqualizer, "OMX.RENESAS.AUDIO.DSP.EQUALIZER", (OMX_PTR)&data, &callbacks_Eqz);

        /* ...set parameters */
        OMX_SetParameter(data.pEqualizer, OMX_IndexParamAudioPcm, &eqz_pcmin_params);
        OMX_SetParameter(data.pEqualizer, OMX_IndexParamAudioPcm, &eqz_pcmout_params);
        if( strcmp(data.config_name, "") )
        {
            OMX_SetParameter(data.pEqualizer, XAOMX_IndexParamAudioEqualizer, &eqz_params);
        }

        OMX_GetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_inport_def);
        OMX_GetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_outport_def);

        if(data.pwdsz == 24)
        {
            data.eqz_outport_def.nBufferAlignment = 32;
            data.eqz_outport_def.nBufferSize = 1024 * eqz_pcmout_params.nChannels * (32 >> 3);
            data.eqz_inport_def.nBufferAlignment = 32;
            data.eqz_inport_def.nBufferSize = 1024 * eqz_pcmin_params.nChannels * (32 >> 3);

            OMX_SetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_outport_def);
            OMX_SetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_inport_def);
        }
        else if(data.pwdsz == 16)
        {
            data.eqz_outport_def.nBufferAlignment = 32;
            data.eqz_outport_def.nBufferSize = 1024 * eqz_pcmout_params.nChannels * (eqz_pcmout_params.nBitPerSample >> 3);
            data.eqz_inport_def.nBufferAlignment = 32;
            data.eqz_inport_def.nBufferSize = 1024 * eqz_pcmin_params.nChannels * (eqz_pcmin_params.nBitPerSample >> 3);

            OMX_SetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_outport_def);
            OMX_SetParameter(data.pEqualizer, OMX_IndexParamPortDefinition, &data.eqz_inport_def);
        }
    }

    if( RENDERER_ENABLE(data.eos) )
    {
        int r;
        int alsa_fs;

        alsa_fs = rdr_params.nPCM_out_sample_rate;
        if (alsa_fs == 0)
        {
            alsa_fs = rdr_params.nPCM_in_sample_rate;
        }

        printf("alsa out sample rate %d\n", alsa_fs);

#ifdef TARGET_ANDROID
        alsa_out = pcm_open(card_idx, dev_idx, PCM_OUT, &pcm_config_dac);
        if ((alsa_out == NULL) || !pcm_is_ready(alsa_out) || pcm_prepare(alsa_out)) {
            printf("cannot open pcm_out driver normal 4: %s", pcm_get_error(alsa_out));
            pcm_close(alsa_out);
            alsa_out = NULL;
        }
        else
        {
            /* mask pcm is opened */
            snd_open_status = 1;
        }
#else
        /* ...open PCM device for playback */
        if((r = snd_pcm_open(&alsa_out, cardname, SND_PCM_STREAM_PLAYBACK, 0)) < 0)
        {
            printf("Failed to open pcm device or pcm device already open: %s\n", snd_strerror(r));
//            return r;
        }
        else
        {
            snd_open_status = 1;
            if(data.pwdsz == 16)
            {
                /* ...set ALSA parameters */
                if((r = snd_pcm_set_params(alsa_out, SND_PCM_FORMAT_S16_LE, SND_PCM_ACCESS_RW_INTERLEAVED, rdr_params.nPCM_out_channel, alsa_fs, 1, 0)) < 0)
                {
                    printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
                    alsa_close(alsa_out);
                    return r;
                }
            }
            else if(data.pwdsz == 24)
            {
                if((r = snd_pcm_set_params(alsa_out, SND_PCM_FORMAT_S24_LE, SND_PCM_ACCESS_RW_INTERLEAVED, rdr_params.nPCM_out_channel, alsa_fs, 1, 0)) < 0)
                {
                    printf("Failed to set ALSA parameters: %s\n", snd_strerror(r));
                    alsa_close(alsa_out);
                    return r;
                }
            }
        }
#endif
        /* ...get Renderer's handle */
        OMX_GetHandle(&data.pRenderer, "OMX.RENESAS.AUDIO.DSP.RENDERER", (OMX_PTR)&data, &callbacks_Ren);

        /* ...set parameters for Renderer */
        OMX_SetParameter(data.pRenderer, OMX_IndexParamAudioPcm, &rdr_pcmin_params);
        OMX_SetParameter(data.pRenderer, XAOMX_IndexParamAudioRenderer, &rdr_params);

        OMX_GetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def);
        OMX_GetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_outport_def);

        if(data.pwdsz == 24)
        {
            data.rdr_inport_def.nBufferAlignment = 32;
            data.rdr_inport_def.nBufferSize = rdr_params.nPCM_frame_size * rdr_params.nPCM_in_channel * (32 >> 3);

            OMX_SetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def);
        }
        else if(data.pwdsz == 16)
        {
            data.rdr_inport_def.nBufferAlignment = 32;
            data.rdr_inport_def.nBufferSize = rdr_params.nPCM_frame_size * rdr_params.nPCM_in_channel * (rdr_pcmin_params.nBitPerSample >> 3);

            OMX_SetParameter(data.pRenderer, OMX_IndexParamPortDefinition, &data.rdr_inport_def);
        }
    }

    /* Start routing if possible and change component state to state Idle */
    if (CAPTURE_ENABLE(data.eos))
    {
        if (EQUALIZER_ENABLE(data.eos))
        {
            OMX_SetupTunnel(data.pCapture, data.cap_outport_def.nPortIndex, data.pEqualizer, data.eqz_inport_def.nPortIndex);
        }
        else if (RENDERER_ENABLE(data.eos))
        {
            OMX_SetupTunnel(data.pCapture, data.cap_outport_def.nPortIndex, data.pRenderer, data.rdr_inport_def.nPortIndex);
        }
    }
    
    if (EQUALIZER_ENABLE(data.eos))
    {
        if (RENDERER_ENABLE(data.eos))
            OMX_SetupTunnel(data.pEqualizer, data.eqz_outport_def.nPortIndex, data.pRenderer, data.rdr_inport_def.nPortIndex);
    }

    if ( RENDERER_ENABLE(data.eos) )
    {
        /* start with most-right plugin */
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        for (i = 0; i < data.rdr_outport_def.nBufferCountActual; i++)
        {
            OMX_AllocateBuffer(data.pRenderer, &bufou[i], data.rdr_outport_def.nPortIndex, NULL, data.rdr_outport_def.nBufferSize);
        }

        if ( !CAPTURE_ENABLE(data.eos) && !EQUALIZER_ENABLE(data.eos) )
        {
            /* there is only renderer plugin - need to allocate input port buffer */
            for (i = 0; i < data.rdr_inport_def.nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pRenderer, &bufin[i], data.rdr_inport_def.nPortIndex, NULL, data.rdr_inport_def.nBufferSize);
            }
        }
    }

    if ( EQUALIZER_ENABLE(data.eos) )
    {
        OMX_SendCommand(data.pEqualizer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        if( !RENDERER_ENABLE(data.eos) )
        {
            for (i = 0; i < data.eqz_outport_def.nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pEqualizer, &bufou[i], data.eqz_outport_def.nPortIndex, NULL, data.eqz_outport_def.nBufferSize);
            }
        }

        if( !CAPTURE_ENABLE(data.eos) )
        {
            for (i = 0; i < data.eqz_inport_def.nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pEqualizer, &bufin[i], data.eqz_inport_def.nPortIndex, NULL, data.eqz_inport_def.nBufferSize);
            }
        }
    }

    if ( CAPTURE_ENABLE(data.eos) )
    {
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        for (i = 0; i < data.cap_inport_def.nBufferCountActual; i++)
        {
            OMX_AllocateBuffer(data.pCapture, &bufin[i], data.cap_inport_def.nPortIndex, NULL, data.cap_inport_def.nBufferSize);
        }
        
        if( !EQUALIZER_ENABLE(data.eos) && !RENDERER_ENABLE(data.eos) )
        {
            /* there is no sink component - need to allacte output port buffer */
            for (i = 0; i < data.cap_outport_def.nBufferCountActual; i++)
            {
                OMX_AllocateBuffer(data.pCapture, &bufou[i], data.cap_outport_def.nPortIndex, NULL, data.cap_outport_def.nBufferSize);
            }
        }
    }

    /*Check error return from ADSP Plug-in if any before changing to audio executing state*/
    pthread_mutex_lock(&event_lock);
    if (pluginerror)
    {
        pthread_mutex_unlock(&event_lock);
        if(CAPTURE_ENABLE(data.eos))
        {
            /* ...free handle */
            OMX_FreeHandle(data.pCapture);
            alsa_close(alsa_in);
        }

        if(EQUALIZER_ENABLE(data.eos))
        {
            /* ...free handle */
            OMX_FreeHandle(data.pEqualizer);
        }

        if(RENDERER_ENABLE(data.eos))
        {
            /* ...free handle */
            OMX_FreeHandle(data.pRenderer);
            alsa_close(alsa_out);
        }

        OMX_Deinit();
        printf("[TEST] Invalid parameters!\n");
        return 1;
    }
    else
    {
        pthread_mutex_unlock(&event_lock);
    }

    /* after this point - the component have already changed to state idle.
     * if there is no error, component state will be changed to state executing */
    if (CAPTURE_ENABLE(data.eos))
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateExecuting, pCmd);
    if (EQUALIZER_ENABLE(data.eos))
        OMX_SendCommand(data.pEqualizer, OMX_CommandStateSet, OMX_StateExecuting, pCmd);
    if (RENDERER_ENABLE(data.eos))
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateExecuting, pCmd);

    pthread_mutex_init(&input_lock, NULL);
    pthread_mutex_init(&output_lock, NULL);
    pthread_mutex_init(&end_lock, NULL);
    pthread_mutex_init(&user_lock, NULL);
    pthread_mutex_init(&main_lock, NULL);
    pthread_mutex_init(&event_lock, NULL);

    /*******************************************************************************
     * Prepare for run
     ******************************************************************************/
    if (!CAPTURE_ENABLE(data.eos))
        pthread_create(&input_id, NULL, (void*)input_thread, (void*)&data);
    if (!RENDERER_ENABLE(data.eos))
        pthread_create(&output_id, NULL, (void*)output_thread, (void*)&data);
    if (RENDERER_ENABLE(data.eos) || CAPTURE_ENABLE(data.eos))
        pthread_create(&user_id, NULL, (void*)user_thread, (void*)&data);

    /* Process renderer volume received from user */
    if (RENDERER_ENABLE(data.eos) && !CAPTURE_ENABLE(data.eos))
    {
        printf("\nPress 'u' to increase volume\n Press 'd' to decrease volume\n\n");

        for (;;)
        {
            pthread_mutex_lock(&event_lock);
            if (pluginerror == 1)
            {
                pthread_mutex_unlock(&event_lock);
                break;
            }
            else
            {
                pthread_mutex_unlock(&event_lock);
            }

            pthread_mutex_lock(&main_lock);
            if(g_vol_up_cmd == 1)
            {
                pthread_mutex_unlock(&main_lock);

                if ((rdr_params.nPCM_volume_rate + (OMX_U32)(vol_step * (1 << 20))) >= 0x7FFFFF)
                {
                    rdr_params.nPCM_volume_rate = 0x7FFFFF;
                }
                else
                {
                    rdr_params.nPCM_volume_rate = rdr_params.nPCM_volume_rate + (OMX_U32)(vol_step * (1 << 20));
                }

                OMX_SetConfig(data.pRenderer,XAOMX_IndexParamAudioRenderer,&rdr_params);

                pthread_mutex_lock(&main_lock);
                g_vol_up_cmd = 0;
                pthread_mutex_unlock(&main_lock);
            }
            else
            {
                pthread_mutex_unlock(&main_lock);
            }

            pthread_mutex_lock(&main_lock);
            if(g_vol_down_cmd == 1)
            {
                pthread_mutex_unlock(&main_lock);

                if (rdr_params.nPCM_volume_rate <= (OMX_U32)(vol_step * (1 << 20)))
                {
                    rdr_params.nPCM_volume_rate = 0;
                }
                else
                {
                    rdr_params.nPCM_volume_rate = rdr_params.nPCM_volume_rate - (OMX_U32)(vol_step * (1 << 20));
                }

                OMX_SetConfig(data.pRenderer,XAOMX_IndexParamAudioRenderer,&rdr_params);

                pthread_mutex_lock(&main_lock);
                g_vol_down_cmd = 0;
                pthread_mutex_unlock(&main_lock);
            }
            else
            {
                pthread_mutex_unlock(&main_lock);
            }

            pthread_mutex_lock(&end_lock);
            if (g_end == 1)
            {
                pthread_mutex_unlock(&end_lock);
                break;
            }
            else
            {
                pthread_mutex_unlock(&end_lock);
            }
        }

        sleep(1);
    }

    /* Process capture volume and stop command received from user */
    if (CAPTURE_ENABLE(data.eos))
    {
        /* Need to add empty buffer in case only Capture is available */
        if (!EQUALIZER_ENABLE(data.eos) && !RENDERER_ENABLE(data.eos))
        {
            bufin[0]->nFilledLen = 1;
            OMX_EmptyThisBuffer(data.pCapture, bufin[0]);
        }

        /* Sleep ts second */
        if (data.ts)
        {
            sleep(data.ts);
        }
        else
        {
            printf("\nPress 's' to stop:\n Press 'u' to increase volume\n Press 'd' to decrease volume\n\n");
            for (;;)
            {
                pthread_mutex_lock(&event_lock);
                if (pluginerror == 1)
                {
                    pthread_mutex_unlock(&event_lock);
                    break;
                }
                else
                {
                    pthread_mutex_unlock(&event_lock);
                }

                pthread_mutex_lock(&main_lock);
                if(g_vol_up_cmd == 1)
                {
                    pthread_mutex_unlock(&main_lock);

                    if ((cap_params.nPCM_volume_rate + (OMX_U32)(vol_step * (1 << 20))) >= 0x7FFFFF)
                    {
                        cap_params.nPCM_volume_rate = 0x7FFFFF;
                    }
                    else
                    {
                        cap_params.nPCM_volume_rate = cap_params.nPCM_volume_rate + (OMX_U32)(vol_step * (1 << 20));
                    }

                    OMX_SetConfig(data.pCapture,XAOMX_IndexParamAudioCapture,&cap_params);

                    pthread_mutex_lock(&main_lock);
                    g_vol_up_cmd = 0;
                    pthread_mutex_unlock(&main_lock);
                }
                else
                {
                    pthread_mutex_unlock(&main_lock);
                }

                pthread_mutex_lock(&main_lock);
                if(g_vol_down_cmd == 1)
                {
                    pthread_mutex_unlock(&main_lock);

                    if (cap_params.nPCM_volume_rate <= (OMX_U32)(vol_step * (1 << 20)))
                    {
                        cap_params.nPCM_volume_rate = 0;
                    }
                    else
                    {
                        cap_params.nPCM_volume_rate = cap_params.nPCM_volume_rate - (OMX_U32)(vol_step * (1 << 20));
                    }

                    OMX_SetConfig(data.pCapture,XAOMX_IndexParamAudioCapture,&cap_params);

                    pthread_mutex_lock(&main_lock);
                    g_vol_down_cmd = 0;
                    pthread_mutex_unlock(&main_lock);
                }
                else
                {
                    pthread_mutex_unlock(&main_lock);
                }

                pthread_mutex_lock(&main_lock);
                if(g_stop_cmd == 1)
                {
                    g_stop_cmd = 0;
                    pthread_mutex_unlock(&main_lock);
                    break;
                }
                else
                {
                    pthread_mutex_unlock(&main_lock);
                }
            }
        }

        /* Audio data transfer complete, send end of stream signal to plug-in*/
        bufin[0]->nFilledLen = 0;
        bufin[0]->nFlags |= OMX_BUFFERFLAG_EOS;

        pthread_mutex_lock(&end_lock);
        g_end = 1;
        pthread_mutex_unlock(&end_lock);

        OMX_EmptyThisBuffer(data.pCapture, bufin[0]);
    }

    if (!CAPTURE_ENABLE(data.eos))
        pthread_join(input_id, NULL);
    if (!RENDERER_ENABLE(data.eos))
        pthread_join(output_id, NULL);
#ifndef TARGET_ANDROID
    if (RENDERER_ENABLE(data.eos) || CAPTURE_ENABLE(data.eos))
    {
    	pthread_cancel(user_id);
        pthread_join(user_id, NULL);
    }
#endif

    /*******************************************************************************
     * End process change components to Idle, Loaded and free all buffer
     ******************************************************************************/
    /* wait for all the messages reponds from ADSP to OMX */
    sleep(1);

    if(CAPTURE_ENABLE(data.eos))
    {
        /* ...change state to IDLE */
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        /* ...wait until Renderer's state is IDLE */
        get_and_wait_component_state(data.pCapture, OMX_StateIdle);

        /* ...change state to LOADED */
        OMX_SendCommand(data.pCapture, OMX_CommandStateSet, OMX_StateLoaded, pCmd);

        /* ...free buffer of input/output port */
        for(i = 0; i < data.cap_inport_def.nBufferCountActual; i++)
        {
            OMX_FreeBuffer(data.pCapture, data.cap_inport_def.nPortIndex, bufin[i]);
        }

        if(!EQUALIZER_ENABLE(data.eos) && !RENDERER_ENABLE(data.eos))
        {
            /* there is no tunnel setup -> need free output port buffer */
            for(i = 0; i < data.cap_outport_def.nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pCapture, data.cap_outport_def.nPortIndex, bufou[i]);
            }
        }

        /* ...free handle */
        OMX_FreeHandle(data.pCapture);

        alsa_close(alsa_in);
    }

    if(EQUALIZER_ENABLE(data.eos))
    {
        /* ...change state to IDLE */
        OMX_SendCommand(data.pEqualizer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        /* ...wait until Renderer's state is IDLE */
        get_and_wait_component_state(data.pEqualizer, OMX_StateIdle);

        /* ...change state to LOADED */
        OMX_SendCommand(data.pEqualizer, OMX_CommandStateSet, OMX_StateLoaded, pCmd);

        /* ...free buffer of input/output port */
        if(!CAPTURE_ENABLE(data.eos))
        {
            /* ...there is no tunnel setup -> need free input port buffer manually */
            for(i = 0; i < data.eqz_inport_def.nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pEqualizer, data.eqz_inport_def.nPortIndex, bufin[i]);
            }
        }

        if(!RENDERER_ENABLE(data.eos))
        {
            /* ...there is no tunnel setup -> need free output port buffer manually */
            for(i = 0; i < data.eqz_outport_def.nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pEqualizer, data.eqz_outport_def.nPortIndex, bufou[i]);
            }
        }

        /* ...free handle */
        OMX_FreeHandle(data.pEqualizer);
    }

    if(RENDERER_ENABLE(data.eos))
    {
        /* ...change state to IDLE */
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateIdle, pCmd);

        /* ...wait until Renderer's state is EXECUTING */
        get_and_wait_component_state(data.pRenderer, OMX_StateIdle);

        /* ...change state to LOADED */
        OMX_SendCommand(data.pRenderer, OMX_CommandStateSet, OMX_StateLoaded, pCmd);

        /* ...free buffer of input/output port */
        if(!CAPTURE_ENABLE(data.eos) && !EQUALIZER_ENABLE(data.eos))
        {
            /* ...there is no setup tunnel -> need free input port buffer manually */
            for(i = 0; i < data.rdr_inport_def.nBufferCountActual; i++)
            {
                OMX_FreeBuffer(data.pRenderer, data.rdr_inport_def.nPortIndex, bufin[i]);
            }
        }

        for(i = 0; i < data.rdr_outport_def.nBufferCountActual; i++)
        {
            OMX_FreeBuffer(data.pRenderer, data.rdr_outport_def.nPortIndex, bufou[i]);
        }

        /* ...free handle */
        OMX_FreeHandle(data.pRenderer);

        if ( snd_open_status == 1)
        {
            alsa_close(alsa_out);
        }
    }

    OMX_Deinit();

    printf("[TEST] All Test Complete!\n");

#ifdef TARGET_ANDROID
    if (RENDERER_ENABLE(data.eos) || CAPTURE_ENABLE(data.eos))
    {
        pthread_kill(user_id, SIGUSR1);
    }
#endif
   
    return 0;
}
