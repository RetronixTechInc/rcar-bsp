/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-decoder-mp3.c
 *
 * OMX IL component for Xtensa HiFi2 VORBIS decoder
 ******************************************************************************/

#define MODULE_TAG                      XA_VORBISDEC

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-codec-base.h"
#include "audio/xa_vorbis_dec_api.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(INIT, 1);

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

typedef struct XAOMXVorbisDecoder
{
    /* ...generic codec structure */
    XAOMXCodecBase                  base;

    /* ...VORBIS-specific parameters (input port) */
    OMX_AUDIO_PARAM_VORBISTYPE      sVORBIS;

    /* ...PCM-specific parameters (output port) */
    OMX_AUDIO_PARAM_PCMMODETYPE     sPCM;

}   XAOMXVorbisDecoder;

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/* ...total amount of input buffers */
#define NUM_INPUT_BUFFERS               4

/* ...required input buffer size */
#define INPUT_BUFFER_SIZE               12288

/* ...total amount of output buffers */
#define NUM_OUTPUT_BUFFERS              8

/* ...required data alignment */
#define BUFFER_ALIGNMENT                32

/*******************************************************************************
 * Low-level codec commands
 ******************************************************************************/

/* ...codec setup hook */
static int VORBISDEC_CodecSetup(XAOMXCodecBase *pBase, xf_set_param_msg_t *msg)
{
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *)pBase;

    C_UNUSED(pData);

    /* ...prepare parameters to set */
    msg->item[0].id = XA_VORBISDEC_CONFIG_PARAM_RAW_VORBIS_FILE_MODE;
    msg->item[0].value = 1;

    /* ...return number of parameters we set */
    return 1;
}

/* ...codec runtime initialization hook */
static int VORBISDEC_CodecRuntimeInit(XAOMXCodecBase *pBase, xf_start_msg_t *msg)
{
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *)pBase;
    xf_get_param_msg_t *get = (xf_get_param_msg_t *)msg;

    /* ...initialize the audio parameters for output port */
    pBase->sPortDef[1].nBufferCountMin = NUM_OUTPUT_BUFFERS;
    pBase->sPortDef[1].nBufferCountActual = NUM_OUTPUT_BUFFERS;
    pBase->sPortDef[1].nBufferSize = msg->output_length;
    pBase->sPortDef[1].nBufferAlignment = BUFFER_ALIGNMENT;

    /* ...update parameters requiring port reconfiguration */
    pData->sPCM.nSamplingRate = msg->sample_rate;
    pData->sPCM.nChannels = msg->channels;

    /* ...prepare parameters to get */
    get->c.id[0] = XA_VORBISDEC_CONFIG_PARAM_GET_CUR_BITRATE;

    /* ...return number of parameters we query */
    return 1;
}

/* ...process output stream parameters */
static int VORBISDEC_CodecGetParam(XAOMXCodecBase *pBase, xf_get_param_msg_t *msg, u32 length)
{
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *) pBase;

    /* ...check the message length is correct */
    XF_CHK_ERR(length == sizeof(*msg) * 1, -EBADF);

    /* ...save codec bitrate */
    pData->sVORBIS.nBitRate = msg->r.value[0];

    TRACE(INIT, _b("VORBIS stream parameters"));
    TRACE(INIT, _b("Bitrate:            %u"), pData->sVORBIS.nBitRate);
    TRACE(INIT, _b("Sampling rate:      %u"), pData->sPCM.nSamplingRate);
    TRACE(INIT, _b("Number of channels: %u"), pData->sPCM.nChannels);
    TRACE(INIT, _b("PCM width:          %u"), pData->sPCM.nBitPerSample);

    return 0;
}

/* ...buffer preprocessing */
static void VORBISDEC_CodecBufferPreprocess(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *)pBase;

    C_UNUSED(pData);

    /* ...if buffer contains codec configuration data, do nothing */
    if (pBufHdr->nFlags & OMX_BUFFERFLAG_CODECCONFIG)
        return;
 
    TRACE(1, _b("Strip frame: %lu (%d)"), pBufHdr->nFilledLen, (pBufHdr->nFlags & OMX_BUFFERFLAG_ENDOFFRAME ? 1 : 0));
    
    /* ...strip last 4 bytes from every frame */
    if ((pBufHdr->nFlags & OMX_BUFFERFLAG_ENDOFFRAME) && pBufHdr->nFilledLen > 4)
        pBufHdr->nFilledLen -= 4;
}

/* ...timestamp advance function */
static void VORBISDEC_CodecTimeStamp(XAOMXCodecBase *pBase, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *) pBase;
    u32                 length = pBufHdr->nFilledLen;
    u32                 n = (length * 8) / (pData->sPCM.nChannels * pData->sPCM.nBitPerSample);

    /* ...add current timestamp to the output buffer */
    pBufHdr->nTimeStamp = pBase->nTimeStamp;

    /* ...advance timestamp for the next buffer (very basic and inaccurate way) */
    pBase->nTimeStamp += (n * 1000000) / pData->sPCM.nSamplingRate;
}

/*******************************************************************************
 * Codec-specific OMX IL interface
 ******************************************************************************/

/* ...get parameter */
static OMX_ERRORTYPE VORBISDEC_GetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXVorbisDecoder    *pData = (XAOMXVorbisDecoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioVorbis:
    {
        /* ...return OMX_AUDIO_PARAM_VORBISTYPE structure */
        OMX_AUDIO_PARAM_VORBISTYPE *param = (OMX_AUDIO_PARAM_VORBISTYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sVORBIS.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sVORBIS, sizeof(*param));

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPcm:
    {
        /* ...return OMX_AUDIO_PARAM_PCMMODETYPE structure */
        OMX_AUDIO_PARAM_PCMMODETYPE    *param = (OMX_AUDIO_PARAM_PCMMODETYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sPCM.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(param, &pData->sPCM, sizeof(*param));

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...set parameter */
static OMX_ERRORTYPE VORBISDEC_SetParameter(XAOMXCodecBase *pBase, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    XAOMXVorbisDecoder    *pData = (XAOMXVorbisDecoder *) pBase;

    switch(nIndex) {
    case OMX_IndexParamAudioVorbis:
    {
        /* ...set OMX_AUDIO_PARAM_VORBISTYPE structure */
        OMX_AUDIO_PARAM_VORBISTYPE    *param = (OMX_AUDIO_PARAM_VORBISTYPE *) pParam;

        XF_CHK_ERR(param->nPortIndex == pData->sVORBIS.nPortIndex, OMX_ErrorBadPortIndex);

        memcpy(&pData->sVORBIS, param, sizeof(*param));

        TRACE(INIT, _b("VORBIS parameters set"));
        TRACE(INIT, _b("Number of channels: %lu"), pData->sVORBIS.nChannels);
        TRACE(INIT, _b("Bitrate:            %lu"), pData->sVORBIS.nBitRate);
        TRACE(INIT, _b("Sampling rate:      %lu"), pData->sVORBIS.nSampleRate);
        TRACE(INIT, _b("Audio bandwidth:    %lu"), pData->sVORBIS.nAudioBandWidth);
        TRACE(INIT, _b("Quality:            %lu"), pData->sVORBIS.nQuality);
        TRACE(INIT, _b("Managed:            %u"),  pData->sVORBIS.bManaged);
        TRACE(INIT, _b("Downmix:            %u"),  pData->sVORBIS.bDownmix);

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter */
        return XAOMX_CHK_API(OMX_ErrorUnsupportedIndex);
    }
}

/* ...component destructor */
static OMX_ERRORTYPE VORBISDEC_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *)pComp->pComponentPrivate;

    /* ...destroy base component */
    XAOMX_CHK_API(XAOMX_ComponentDeInit(hComponent));

    /* ...destroy private data */
    free(pData);

    /* ...destroy component data itself (component ceases to exist) */
    free(pComp);

    TRACE(INIT, _b("VORBIS decoder component destroyed"));

    return OMX_ErrorNone;
}

/* ...component constructor */
static OMX_ERRORTYPE VORBISDEC_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXVorbisDecoder *pData = (XAOMXVorbisDecoder *)pComp->pComponentPrivate;

    /* ...initialize base codec interface */
    XAOMX_CHK_API(XAOMX_ComponentInit(proxy, hComponent, pAppData, pCallbacks, "audio_decoder.vorbis", "audio-decoder/vorbis"));

    /* ...set codec-specific callbacks */
    pData->base.pComponentName = "OMX.xa.vorbis.decoder";
    pData->base.SetParameter = VORBISDEC_SetParameter;
    pData->base.GetParameter = VORBISDEC_GetParameter;
    pData->base.CodecSetup = VORBISDEC_CodecSetup;
    pData->base.CodecRuntimeInit = VORBISDEC_CodecRuntimeInit;
    pData->base.CodecGetParam = VORBISDEC_CodecGetParam;
    pData->base.CodecBufferPreprocess = VORBISDEC_CodecBufferPreprocess;
    pData->base.CodecTimeStamp = VORBISDEC_CodecTimeStamp;

    /* ...override component interface */
    pComp->ComponentDeInit = VORBISDEC_ComponentDeInit;

    /* ...initialize the audio parameters for input port */
    pData->base.sPortDef[0].nBufferCountActual = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferCountMin = NUM_INPUT_BUFFERS;
    pData->base.sPortDef[0].nBufferSize = INPUT_BUFFER_SIZE;
    pData->base.sPortDef[0].nBufferAlignment = BUFFER_ALIGNMENT;
    pData->base.sPortDef[0].format.audio.eEncoding = OMX_AUDIO_CodingVORBIS;
    pData->base.sPortDef[0].format.audio.cMIMEType = (OMX_STRING) "audio/vorbis";
    pData->base.sPortDef[0].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[0].format.audio.bFlagErrorConcealment = OMX_TRUE;

    /* ...initialize the compression format for input port */
    pData->base.sPortFormat[0].nIndex = OMX_IndexParamAudioVorbis;
    pData->base.sPortFormat[0].eEncoding = OMX_AUDIO_CodingVORBIS;

    /* ...initialize the audio parameters for output port (format only) */
    pData->base.sPortDef[1].format.audio.eEncoding = OMX_AUDIO_CodingPCM;
    pData->base.sPortDef[1].format.audio.cMIMEType = (OMX_STRING) "raw";
    pData->base.sPortDef[1].format.audio.pNativeRender = NULL;
    pData->base.sPortDef[1].format.audio.bFlagErrorConcealment = OMX_FALSE;

    /* ...initialize the compression format for output port */
    pData->base.sPortFormat[1].nIndex = OMX_IndexParamAudioPcm;
    pData->base.sPortFormat[1].eEncoding = OMX_AUDIO_CodingPCM;

    /* ...VORBIS format defaults */
    XAOMX_INIT_STRUCT(&pData->sVORBIS, OMX_AUDIO_PARAM_VORBISTYPE);
    pData->sVORBIS.nPortIndex = 0;
    pData->sVORBIS.nChannels = 2;
    pData->sVORBIS.nSampleRate = 44100;
    pData->sVORBIS.nBitRate = 0;
    pData->sVORBIS.nAudioBandWidth = 0;
    pData->sVORBIS.nMinBitRate = 0;
    pData->sVORBIS.nMaxBitRate = 0;
    pData->sVORBIS.nQuality = 3;
    pData->sVORBIS.bManaged = 0;
    pData->sVORBIS.bDownmix = 0;

    /* ...PCM format defaults */
    XAOMX_INIT_STRUCT(&pData->sPCM, OMX_AUDIO_PARAM_PCMMODETYPE);
    pData->sPCM.nPortIndex = 1;
    pData->sPCM.nChannels = 2;
    pData->sPCM.nSamplingRate = 44100;
    pData->sPCM.nBitPerSample = 16;
    pData->sPCM.eNumData = OMX_NumericalDataSigned;
    pData->sPCM.eEndian = OMX_EndianLittle;
    pData->sPCM.bInterleaved = OMX_TRUE;
    pData->sPCM.ePCMMode = OMX_AUDIO_PCMModeLinear;
    pData->sPCM.eChannelMapping[0] = OMX_AUDIO_ChannelLF;
    pData->sPCM.eChannelMapping[1] = OMX_AUDIO_ChannelRF;

    return OMX_ErrorNone;
}

/*******************************************************************************
 * Entry points
 ******************************************************************************/

OMX_ERRORTYPE VORBISDEC_ComponentCreate(xf_proxy_t *proxy, OMX_HANDLETYPE *hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks)
{
    OMX_COMPONENTTYPE  *pComp;
    XAOMXVorbisDecoder *pData;
    OMX_ERRORTYPE       eError = OMX_ErrorInsufficientResources;

    /* ...create the base component */
    if ((pComp = calloc(1, sizeof(*pComp))) == NULL)
        goto error;

    /* ...set component version */
    XAOMX_INIT_STRUCT(pComp, OMX_COMPONENTTYPE);

    /* ...allocate private memory */
    if ((pData = calloc(1, sizeof(*pData))) == NULL)
        goto error1;

    /* ...set private data handle */
    pComp->pComponentPrivate = (OMX_PTR) pData;

    /* ...initialize component */
    if ((eError = VORBISDEC_ComponentInit(proxy, (OMX_HANDLETYPE)pComp, pAppData, pCallbacks)) != OMX_ErrorNone)
        goto error2;

    TRACE(INIT, _b("VORBIS decoder initialized"));

    /* ...return component handle */
    *hComponent = (OMX_HANDLETYPE)pComp;

    return OMX_ErrorNone;

error2:
    /* ...deallocate all component resources */
    VORBISDEC_ComponentDeInit((OMX_HANDLETYPE)pComp);

    goto error;

error1:
    /* ...destroy component handle data */
    free(pComp);

error:
    TRACE(INIT, _b("VORBIS decoder component creation failed: %X"), eError);

    return eError;
}
