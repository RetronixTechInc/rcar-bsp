/*******************************************************************************
 * Copyright (c) 2016 by Cadence Design Systems, Inc.  ALL RIGHTS RESERVED.
 * These coded instructions, statements, and computer programs are the
 * copyrighted works and confidential proprietary information of
 * Cadence Design Systems Inc.  They may be adapted and modified by bona fide
 * purchasers for internal use, but neither the original nor any adapted
 * or modified version may be disclosed or distributed to third parties
 * in any manner, medium, or form, in whole or in part, without the prior
 * written consent of Cadence Design Systems Inc.  This software and its
 * derivatives are to be executed solely on products incorporating a Cadence
 * Design Systems processor.
 ******************************************************************************/

/*******************************************************************************
 * omx-tdm-codec-base.c
 *
 * OMX IL component for Xtensa HiFi2 Audio codecs
 ******************************************************************************/

#define MODULE_TAG                      XA_TDMBASE

/*******************************************************************************
 * Includes
 ******************************************************************************/

#include "xf-ap.h"
#include "omx-tdm-codec-base.h"

/*******************************************************************************
 * Tracing configuration
 ******************************************************************************/

TRACE_TAG(IL,       1);
TRACE_TAG(INIT,     1);
TRACE_TAG(BUFFER,   1);
TRACE_TAG(SM,       1);
TRACE_TAG(CMD,      1);
TRACE_TAG(RSP,      1);
TRACE_TAG(INPUT,    1);
TRACE_TAG(OUTPUT,   1);

/*******************************************************************************
 * Port/component state flags
 ******************************************************************************/

/* ...port populating sequence */
#define XA_FLAG_PORT_POPULATING(port)   (1 << (0 + (port)))     /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...port flushing sequence */
#define XA_FLAG_PORT_FLUSHING(port)     (1 << (5 + (port)))     /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...port resetting sequence */
#define XA_FLAG_PORT_RESETTING(port)    (1 << (10 + (port)))     /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...port unpopulating sequence */
#define XA_FLAG_PORT_UNPOPULATING(port) (1 << (15 + (port)))     /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...port destroying sequence */
#define XA_FLAG_PORT_DESTROYING(port)   (1 << (20 + (port)))     /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...pending port command status */
#define XA_FLAG_PORT_COMMAND(port)      (1 << (25 + (port)))    /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...any outstanding port sequence status */
#define XA_FLAG_PORT_BUSY(port)         (0x02108421 << (0 + (port))) /* PRQA S 3453 *//* Confirm macro use is correct. Oct 14, 2016 */

/* ...pending state transition status */
#define XA_FLAG_STATE_COMMAND           (1 << 30)

/* ...any outstanding component active sequence status */
#define XA_FLAG_COMPONENT_BUSY          (XA_FLAG_PORT_BUSY(0) | XA_FLAG_PORT_BUSY(1) | XA_FLAG_PORT_BUSY(2) | XA_FLAG_PORT_BUSY(3) | XA_FLAG_PORT_BUSY(4) | XA_FLAG_STATE_COMMAND)

/*******************************************************************************
 * Codec state flags
 ******************************************************************************/

/* ...codec instantiation state - transition to idle */
#define XA_FLAG_CODEC_SETUP             (1 << 0)

/* ...idle codec state after instantiation */
#define XA_FLAG_CODEC_IDLE              (1 << 1)

/* ...runtime initialization sequence necessity flag */
#define XA_FLAG_CODEC_START             (1 << 2)

/* ...codec initialization sequence is active */
#define XA_FLAG_CODEC_INIT              (1 << 3)

/* ...steady codec execution state */
#define XA_FLAG_CODEC_EXECUTE           (1 << 4)

/* ...end of input stream */
#define XA_FLAG_CODEC_INPUT_DONE        (1 << 5)

/* ...termination of the playback */
#define XA_FLAG_CODEC_OUTPUT_DONE       (1 << 6)

/* ...first input buffer after playback resumption */
#define XA_FLAG_CODEC_TS                (1 << 7)

/* ...runtime initialized flag - tbd - doesn't look great overall */
#define XA_FLAG_CODEC_INIT_DONE         (1 << 8)

 /* ...tunnel state flag */
#define XA_FLAG_TUNNEL_NONE             (0)

#define XA_FLAG_TUNNEL_ESTABLISHED      (1 << 1)

#define XA_FLAG_TUNNEL_SUPPLIER         (1 << 2)

/*******************************************************************************
 * Local constants definitions
 ******************************************************************************/

/* ...no-port flag */
#define XAOMX_NOPORT                    ((OMX_U32) -1)
#define XAOMX_INPUT_PORT                ((OMX_U32) 0)
#define XAOMX_OUTPUT_PORT               ((OMX_U32) 1)

/*******************************************************************************
 * Local typedefs
 ******************************************************************************/

/* ...extended commands */
typedef enum _XAOMX_COMMANDTYPE {
    /* ...input buffer submission */
    XAOMX_CommandEmptyThisBuffer,

    /* ...output buffer submission */
    XAOMX_CommandFillThisBuffer,

    /* ...flush codec state */
    XAOMX_CommandFlush,

    /* ...component deinitialization */
    XAOMX_CommandDeinitialize

}   XAOMX_COMMANDTYPE;

/* ...internal command structure */
typedef struct _XAOMX_COMMAND {
    /* ...command code */
    XAOMX_COMMANDTYPE       cmd;

    /* ...command data */
    OMX_PTR                 data;

    /* ...port index of this command */
    OMX_S32                 port;

}   XAOMX_COMMAND;

/*******************************************************************************
 * Forward declarations
 ******************************************************************************/
static s32 xa_bufferlist_init(XAOMXTDMCodecBase *pData, OMX_U32 nPort, u32 pool);
static void xa_bufferlist_destroy(XAOMXTDMCodecBase *pData, OMX_U32 nPort);
static OMX_ERRORTYPE xaomx_state_process(XAOMXTDMCodecBase *pData);
static OMX_BUFFERHEADERTYPE * xa_bufferlist_allocate(XA_BUFFERLIST *list);
static s32 xa_bufferlist_submit(XA_BUFFERLIST *list, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_BUFFERHEADERTYPE * xa_bufferlist_retrieve(XA_BUFFERLIST *list, void* buffer);
static OMX_BUFFERHEADERTYPE * xa_bufferlist_peek(XA_BUFFERLIST *list);
static s32 xa_commit_buffers(XAOMXTDMCodecBase *pData, OMX_U32 nPort);
static s32 xa_codec_output_setup(XAOMXTDMCodecBase *pData);
static OMX_ERRORTYPE xaomx_command_state_set(XAOMXTDMCodecBase *pData, OMX_STATETYPE state);
static OMX_ERRORTYPE xaomx_command_port_control(XAOMXTDMCodecBase *pData, OMX_COMMANDTYPE cmd, OMX_U32 nPort);
static OMX_ERRORTYPE xaomx_command_mark_buffer(XAOMXTDMCodecBase *pData, OMX_U32 nPort, OMX_MARKTYPE *pMarkBuf);
static OMX_ERRORTYPE xaomx_get_parameter(XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE xaomx_set_parameter(XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam);
static OMX_ERRORTYPE xaomx_create_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE **ppBufHdr, OMX_U32 nPort, OMX_U32 nSize, OMX_PTR pAppPrivate, OMX_PTR pBuffer, OMX_BOOL bAllocate);
static OMX_ERRORTYPE xaomx_free_buffer(XAOMXTDMCodecBase *pData, OMX_U32 nPort, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE xaomx_empty_this_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE xaomx_fill_this_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr);
static OMX_ERRORTYPE xaomx_free_buffer(XAOMXTDMCodecBase *pData, OMX_U32 nPort, OMX_BUFFERHEADERTYPE *pBufHdr);
static void xaomx_return_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr, OMX_BOOL bDone);
static s32 xaomx_command_process(XAOMXTDMCodecBase *pData, OMX_COMMANDTYPE cmd, OMX_PTR cmddata, OMX_S32 portidx);
static s32 xaomx_response_process(XAOMXTDMCodecBase *pData, xf_user_msg_t *m);
static OMX_ERRORTYPE xaomx_port_state_process(XAOMXTDMCodecBase *pData, OMX_U32 nPort);
static void * xaomx_component_thread(void * arg);
static void xaomx_response_cb(xf_handle_t *h, xf_user_msg_t *msg);
static OMX_ERRORTYPE SendCommand(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_COMMANDTYPE Cmd, OMX_IN OMX_U32 nParam1, OMX_IN OMX_PTR pCmdData);
static OMX_ERRORTYPE GetState(OMX_IN OMX_HANDLETYPE hComponent, OMX_OUT OMX_STATETYPE* pState);
static OMX_ERRORTYPE GetConfig(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_INOUT OMX_PTR pComponentConfigStructure);
static OMX_ERRORTYPE SetConfig(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_IN OMX_PTR pComponentConfigStructure);
static OMX_ERRORTYPE GetExtensionIndex(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_STRING cParameterName, OMX_OUT OMX_INDEXTYPE* pIndexType);
static OMX_ERRORTYPE ComponentTunnelRequest(OMX_IN OMX_HANDLETYPE hComp, OMX_IN OMX_U32 nPort, OMX_IN OMX_HANDLETYPE hTunneledComp, OMX_IN OMX_U32 nTunneledPort, OMX_INOUT OMX_TUNNELSETUPTYPE* pTunnelSetup);
static OMX_ERRORTYPE GetComponentVersion(OMX_IN OMX_HANDLETYPE hComponent, OMX_OUT OMX_STRING pComponentName, OMX_OUT OMX_VERSIONTYPE* pComponentVersion, OMX_OUT OMX_VERSIONTYPE* pSpecVersion, OMX_OUT OMX_UUIDTYPE* pComponentUUID);
static OMX_ERRORTYPE SetCallbacks(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_CALLBACKTYPE *pCallbacks, OMX_IN OMX_PTR pAppData);
static OMX_ERRORTYPE GetParameter(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nParamIndex, OMX_INOUT OMX_PTR pComponentParameterStructure);
static OMX_ERRORTYPE SetParameter(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_IN OMX_PTR pComponentParameterStructure);
static OMX_ERRORTYPE UseBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_INOUT OMX_BUFFERHEADERTYPE** ppBufferHdr, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_PTR pAppPrivate, OMX_IN OMX_U32 nSizeBytes, OMX_IN OMX_U8* pBuffer);
static OMX_ERRORTYPE AllocateBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_INOUT OMX_BUFFERHEADERTYPE** ppBuffer, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_PTR pAppPrivate, OMX_IN OMX_U32 nSizeBytes);
static OMX_ERRORTYPE FreeBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer);
static OMX_ERRORTYPE EmptyThisBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer);
static OMX_ERRORTYPE FillThisBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer);

/* ...pass asynchronous commmand to proxy */
static inline s32 xa_cmd_send(XAOMXTDMCodecBase *pData, u32 id, u32 opcode, void *buffer, u32 length)  /* PRQA S 3219 *//* Confirm function call is correct. Oct 14, 2016 */
{
    s32     r;

    /* ...execute command with lock released */
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    r = xf_command(&pData->handle, id, opcode, buffer, length);
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return r;
}

/*******************************************************************************
 * Operations with buffers
 ******************************************************************************/

/* ...initialize buffer list */
static s32 xa_bufferlist_init(XAOMXTDMCodecBase *pData, OMX_U32 nPort, u32 pool)   /* PRQA S 3219, 3206 *//* Confirm function call is correct. Oct 14, 2016 */
{
    OMX_PARAM_PORTDEFINITIONTYPE   *pPortDef = &pData->sPortDef[nPort];
    XA_BUFFERLIST                  *pList = &pData->sBufList[nPort];
    OMX_U32                         num = pPortDef->nBufferCountActual;
    OMX_U32                         size = pPortDef->nBufferSize;
    xf_proxy_t                     *proxy = pData->handle.proxy;

    /* ...allocate shared buffers of requested size */
    if ( (num > 0) && (size > 0) ) {
        XF_CHK_API(xf_pool_alloc(proxy, num, size, pool, &pList->pPool));

        /* ...allocate array of buffer-head pointers */
        XF_CHK_ERR(pList->pPending = calloc(num,  sizeof(*pList->pPending)), -ENOMEM);

        /* ...reset queue head pointer */
        pList->nHead = 0;

        /* ...no buffers are allocated yet */
        pList->nActiveCount = pList->nPendingCount = pList->nUsedCount = 0;

        /* ...set queue length */
        pList->nQueueLength = num;
    }

    TRACE(INIT, _b("Port %lu buffer list created: %lu * %lu"), nPort, num, size);

    return 0;
}

/* ...destroy buffer list */
static void xa_bufferlist_destroy(XAOMXTDMCodecBase *pData, OMX_U32 nPort)
{
    XA_BUFFERLIST      *pList = &pData->sBufList[nPort];

    /* ...destroy buffer pool */
    if (pList->pPool != NULL) {
        xf_pool_free(pList->pPool);
        pList->pPool = NULL;
    }

    /* ...destroy buffer-head pointers */
    if (pList->pPending != NULL) {
        free(pList->pPending);      /* PRQA S 5118 *//* Confirm free memory is used correctly. Oct 14, 2016 */
        pList->pPending = NULL;
    }

    TRACE(INIT, _b("Port %lu destroyed"), nPort);
}

/* ...allocate the buffer header from list */
static OMX_BUFFERHEADERTYPE * xa_bufferlist_allocate(XA_BUFFERLIST *list)   /* PRQA S 3219 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    OMX_BUFFERHEADERTYPE   *pBufHdr;

    /* ...allocate the buffer */
    pBufHdr = calloc(1, sizeof(OMX_BUFFERHEADERTYPE));      /* PRQA S 5118 *//* Confirm memory allaction is correct. Oct 14, 2016 */

    /* ...get index of first available buffer in the list */
    if (pBufHdr == NULL)
    {
        return NULL;
    }

    /* ...set standard parameters */
    XAOMX_INIT_STRUCT(pBufHdr, OMX_BUFFERHEADERTYPE);

    /* ...increase total amount of allocated buffer headers */
    list->nUsedCount++;

    /* ...return allocated descriptor */
    return pBufHdr;
}

/* ...submit buffer to pending queue  */
static s32 xa_bufferlist_submit(XA_BUFFERLIST *list, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    OMX_U32 tail = list->nHead + list->nActiveCount + list->nPendingCount;

    /* ...process buffer wrap-around */
    if (tail >= list->nQueueLength)
    {
        tail -= list->nQueueLength;
    }

    /* ...put buffer into tail of the list */
    list->pPending[tail] = pBufHdr;  

    TRACE(0, _b("buff[%p] << %p (head = %lu, active = %lu, pending = %lu)"), list, pBufHdr, list->nHead, list->nActiveCount, list->nPendingCount);

    /* ...return non-zero if it is a first buffer */
    return (list->nPendingCount++ == 0);        /* PRQA S 3440 *//* Confirm expression is correct. Oct 14, 2016 */
}

/* ...retrieve buffer from pending queue */
static OMX_BUFFERHEADERTYPE * xa_bufferlist_retrieve(XA_BUFFERLIST *list, void* buffer) /* PRQA S 3219, 3673 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    OMX_U32                 head = list->nHead;
    OMX_BUFFERHEADERTYPE   *pBufHdr = list->pPending[head];

    /* ...check the buffer at the head is proper */
    if (list->nActiveCount == 0) {
        return NULL;
    }

    /* ...check the buffer is in-order */
    if (pBufHdr->pBuffer != buffer) {
        TRACE(ERROR, _b("wrong buffer %p != %p (%lu/%lu)"), pBufHdr->pBuffer, buffer, list->nActiveCount, list->nPendingCount);
        return NULL;
    }

    /* ...advance the pointer check if the pointer reached the length */
    head++;
    list->nHead = ( (head == list->nQueueLength) ? 0 : head );

    /* ...decrement total amount of active buffers */
    list->nActiveCount--;

    TRACE(0, _b("buff[%p] >> %p (head = %lu, active = %lu, pending = %lu)"), list, pBufHdr, list->nHead, list->nActiveCount, list->nPendingCount);

    /* ...return the buffer header found */
    return pBufHdr;
}

/* ...peek first buffer from pending queue */
static OMX_BUFFERHEADERTYPE * xa_bufferlist_peek(XA_BUFFERLIST *list)
{
    OMX_U32                 head = list->nHead;
    OMX_BUFFERHEADERTYPE   *pBufHdr = list->pPending[head];

    /* ...check if the queue is empty */
    if (list->nPendingCount == 0) {
        return NULL;
    }

    /* ...advance the pointer */
    head++;
    list->nHead = ( (head == list->nQueueLength) ? 0 : head );

    /* ...decrement total amount of pending buffers */
    list->nPendingCount--;

    /* ...return the buffer header found */
    return pBufHdr;
}

/* ...pass all pending buffers to proxy */
static s32 xa_commit_buffers(XAOMXTDMCodecBase *pData, OMX_U32 nPort)  /* PRQA S 3219 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    XA_BUFFERLIST  *pBufList = &pData->sBufList[nPort];
    OMX_U32         idx = pBufList->nHead + pBufList->nActiveCount;

    /* ...do nothing if port has been disabled recently */
    if (pData->sPortDef[nPort].bEnabled != OMX_TRUE) {
        return 0;
    }

    /* ...get pointer to first pending buffer */
    if (idx >= pBufList->nQueueLength) {
        idx -= pBufList->nQueueLength;
    }

    /* ...process all pending buffers */
    while (pBufList->nPendingCount != 0) {
        OMX_BUFFERHEADERTYPE   *pBufHdr = pBufList->pPending[idx];

        if (pBufHdr->nOutputPortIndex == XAOMX_NOPORT) {
            /* ...never send zero-length buffer explicitly */
            if (pBufHdr->nFilledLen == 0) {
                break;
            }

            /* ...pass non-zero buffer to the component */
            XF_CHK_API(xa_cmd_send(pData, pBufHdr->nInputPortIndex, XF_EMPTY_THIS_BUFFER, pBufHdr->pBuffer, pBufHdr->nFilledLen));
        }
        else {
            XF_CHK_API(xa_cmd_send(pData, pBufHdr->nOutputPortIndex, XF_FILL_THIS_BUFFER, pBufHdr->pBuffer, pBufHdr->nAllocLen));
        }

        /* ...buffer becomes active */
        pBufList->nPendingCount--;
        pBufList->nActiveCount++;

        /* ...advance index position and check it */
        idx++;
        if (idx == pBufList->nQueueLength)
        {
            idx = 0;
        }
    }

    return 0;
}

/*******************************************************************************
 * Codec setup functions
 ******************************************************************************/

/* ...set codec fixed parameters */
static inline s32 xa_codec_setup(XAOMXTDMCodecBase *pData)     /* PRQA S 3219 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    xf_handle_t         *handle = &pData->handle;
    xf_set_param_msg_t  *set = xf_buffer_data(handle->aux);
    s32                 n;      /* PRQA S 3205 *//* Confirm variable is used correctly. Oct 14, 2016 */
    s32                 i;
    
    /* ...get setup message from codec */
    XF_CHK_ERR((n = pData->CodecSetup(pData, set)) >= 0, -EINVAL);

    /* ...start codec setup sequence */
    pData->eos_codec |= XA_FLAG_CODEC_SETUP;

    /* ...pass message to the component (use destination port 0) */
    XF_CHK_API(xf_command(handle, 0, XF_SET_PARAM, set, n));

    /* ...wait for command completion */
    pthread_cond_wait(&pData->wait, &pData->mutex);     /* PRQA S 3200 *//* Confirm return value is no used. Oct 14, 2016 */

    /* ...check for operation result - codec must enter into idle state */
    XF_CHK_ERR(pData->eos_codec & XA_FLAG_CODEC_IDLE, -EBADF);

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        if (pData->sPortDef[i].eDir == OMX_DirInput)
        {
            /* ...initialize input buffer pool */
            XF_CHK_API(xa_bufferlist_init(pData, i, XF_POOL_INPUT));
        }
        else if (pData->sPortDef[i].eDir == OMX_DirOutput)
        {
            /* ...initialize output buffer pool */
            XF_CHK_API(xa_bufferlist_init(pData, i, XF_POOL_OUTPUT));
        }
        else
        {}
    }

    TRACE(INIT, _b("Codec setup completed"));

    return 0;
}

/* ...create output port */
static s32 xa_codec_output_setup(XAOMXTDMCodecBase *pData)     /* PRQA S 3219 *//* Confirm function call is used correctly. Oct 14, 2016 */
{
    s32 i;
    /* ...initialize output buffer pool */
    //XF_CHK_API(xa_bufferlist_init(pData, 1, XF_POOL_OUTPUT));

    /* ...start output port reconfiguration sequence (do I need that explicitly?) */
    pData->eos_codec ^= XA_FLAG_CODEC_INIT | XA_FLAG_CODEC_EXECUTE;

    /* ...pass notification to the client about necessity to reconfigure output port */
    pData->pCallbacks->EventHandler(pData->hSelf, pData->pAppData, OMX_EventPortSettingsChanged, 1, 0, NULL);

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        if (pData->sPortDef[i].eDir == OMX_DirOutput)
        {
            /* ...submit all pending output buffers */
            XF_CHK_API(xa_commit_buffers(pData, i));
        }
    }
    
    TRACE(INIT, _b("Output port setup completed"));

    return 0;
}

/*******************************************************************************
 * Communication between client, proxy and component thread
 ******************************************************************************/

/* ...pass command to the component thread */
static inline void xaomx_command(XAOMXTDMCodecBase *pData, XAOMX_COMMANDTYPE nCmd, OMX_PTR pCmdData, s32 nPort)   /* PRQA S 3673 *//* Confirm function call is used correctly. Oct 14, 2016 */
{
    XAOMX_COMMAND   command = { .cmd = nCmd, .data = pCmdData, .port = nPort};    /* PRQA S 1053, 1031 *//* Confirm designators usage is correct. Oct 14, 2016 */

    if (write(pData->command[1], &command, sizeof(command)) == -1) {
        TRACE(ERROR, _x("pipe broken: %d"), -errno);    /* PRQA S 5119 *//* Confirm the need of use errno. Oct 14, 2016 */
    }
}

/* ...pass response to the component thread */
static inline void xaomx_response(XAOMXTDMCodecBase *pData, xf_user_msg_t *msg)        /* PRQA S 3673 *//* Confirm function call is used correctly. Oct 14, 2016 */
{
    if (write(pData->response[1], msg, sizeof(*msg)) == -1) {
        TRACE(ERROR, _x("pipe broken: %d"), -errno);    /* PRQA S 5119 *//* Confirm the need of use errno. Oct 14, 2016 */
    }
}

/*******************************************************************************
 * Component state-machine implementation
 ******************************************************************************/

/* ...process set-state command */
static OMX_ERRORTYPE xaomx_command_state_set(XAOMXTDMCodecBase *pData, OMX_STATETYPE state)
{
    OMX_ERRORTYPE        eError;
    OMX_BUFFERHEADERTYPE *pBufHdr;
    u32                  eos_codec = pData->eos_codec;
    u32                  eos_port = pData->eos_port;
    u32                  i;

    /* ...check the transition is not to the same state */
    XF_CHK_ERR(pData->state != state, OMX_ErrorSameState);

    /* ...forbid transitioning to invalid state */
    XF_CHK_ERR(state != OMX_StateInvalid, OMX_ErrorInvalidState);

    /* ...save target state instantly */
    pData->nTargetState = state;

    TRACE(SM, _b("Transition from %u to %u (flags: %X)"), pData->state, state, eos_codec);

    switch (state) {
    case OMX_StateLoaded:
    {
        /* ...transition to loaded state */
        if ( (pData->state == OMX_StateIdle) || (pData->state == OMX_StateWaitForResources) ) {

            for (i = 0; i <= XAOMX_PORT_MAX; i++)
            {
                /* ...process for input port */
                if (pData->sPortDef[i].eDir == OMX_DirInput)
                {
                    /* ...start port unpopulating sequences on enabled ports */
                    if ( (pData->sPortDef[i].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[0] == XA_FLAG_TUNNEL_NONE) ) {
                        eos_port |= XA_FLAG_PORT_UNPOPULATING(i);
                    }
                }
                else if (pData->sPortDef[i].eDir == OMX_DirOutput)
                {
                    /* ...process for output port */
                    if (pData->sPortDef[i].bEnabled == OMX_TRUE) {
                        if (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) {
                            eos_port |= XA_FLAG_PORT_UNPOPULATING(i);
                        }
                        else {
                            /* ...call tunneled tear down in codec site */
                            xf_unroute(&pData->handle, pData->sSupplier[1].nPortIndex); /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

                            /* ...need to send FreeBuffer to tunneled component - tbd */
                            //for (i = 0; i < pData->sPortDef[1].nBufferCountActual; i++) {
                                //OMX_FreeBuffer(pData->hTunnelComp[1], pData->nTunnelPort[1], pBufHdr);
                        }
                    }
                }
                else
                {}

                /* ...destroy all ports */
                eos_port |= XA_FLAG_PORT_DESTROYING(i);
            }
            
            /* ...start asynchronous state transition */
            goto start;     /* PRQA S 2001 *//* Confirm goto usage is correct. Oct 14, 2016 */
        }

        /* ...otherwise, incorrect transition */
        return XAOMX_CHK_API(OMX_ErrorIncorrectStateTransition);
    }

    case OMX_StateIdle:
    {
        /* ...transition to idle state */
        if (pData->state == OMX_StateLoaded) {
            /* ...initialization sequence; synchronously setup the codec */
            XF_CHK_ERR(xa_codec_setup(pData) == 0, OMX_ErrorInsufficientResources);

            /* ...update codec state after synchronous operation completes */
            eos_codec = (volatile u32)pData->eos_codec;
            eos_port = (volatile u32)pData->eos_port;
            
            for (i = 0; i <= XAOMX_PORT_MAX; i++)
            {
                /* ...process for input port */
                if (pData->sPortDef[i].eDir == OMX_DirInput)
                {
                    /* ...start port populating sequences on enabled ports (output is disabled always? - tbd) */
                    if ( (pData->sPortDef[i].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[0] == XA_FLAG_TUNNEL_NONE) ) {
                        eos_port |= XA_FLAG_PORT_POPULATING(i);
                        eos_codec |= XA_FLAG_CODEC_TS;
                    }
                }
                else if (pData->sPortDef[i].eDir == OMX_DirOutput)
                {
                    /* ...process for output port */
                    if (pData->sPortDef[i].bEnabled == OMX_TRUE) {
                        if (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) {
                            eos_port |= XA_FLAG_PORT_POPULATING(i);
                        }
                        else {
                            /* ...call allocation tunneled buffer inside codec site */
                            xf_route(&pData->handle, pData->sSupplier[1].nPortIndex,        /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
                                &((XAOMXTDMCodecBase*)((OMX_COMPONENTTYPE*)pData->hTunnelComp[1])->pComponentPrivate)->handle, pData->nTunnelPort[1],
                                pData->sPortDef[1].nBufferCountActual,
                                pData->sPortDef[1].nBufferSize,
                                pData->sPortDef[1].nBufferAlignment);

                            /* ...pass the buffer to tunneled component - cannot hold the buffer to free later ? */
                            /*for (i = 0; i < pData->sPortDef[1].nBufferCountActual; i++) {
                                [> ...pass empty shell to tunneled component <]
                                OMX_UseBuffer(pData->hTunnelComp[1], &pBufHdr, pData->nTunnelPort[1], NULL, 0, NULL);
                            }*/
                        }
                    }
                }
                else
                {}
            }

            /* ...and start asynchronous state transition */
            goto start;     /* PRQA S 2001 *//* Confirm goto usage is correct. Oct 14, 2016 */
        }
        else if ( (pData->state == OMX_StatePause) || (pData->state == OMX_StateExecuting) ) {

            for(i = 0; i <= XAOMX_PORT_MAX; i++)
            {
                /* ...process for input port */
                if (pData->sPortDef[i].eDir == OMX_DirInput)
                {
                    /* ...stop sequence; reset all ports */
                    if ( (pData->sPortDef[i].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[0] == XA_FLAG_TUNNEL_NONE) ) {
                        eos_port |= XA_FLAG_PORT_FLUSHING(i) | XA_FLAG_PORT_RESETTING(i);
                    }
                }
                else if (pData->sPortDef[i].eDir == OMX_DirOutput)
                {
                    /* ...process for output port */
                    if ( (pData->sPortDef[i].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) ) {
                        eos_port |= XA_FLAG_PORT_FLUSHING(i) | XA_FLAG_PORT_RESETTING(i);
                    }
                }
                else
                {}
            }

            /* ...clear execution flag */
            eos_codec = eos_codec & (~XA_FLAG_CODEC_EXECUTE);       /* PRQA S 4130 *//* Confirm bit-wise use function correctly. Oct 14, 2016 */

            /* ...and start asynchronous state transition */
            goto start;     /* PRQA S 2001 *//* Confirm goto usage is correct. Oct 14, 2016 */
        }
        else {
        	/* ...do nothing */
        }

        /* ...otherwise, transition is incorrect */
        return XAOMX_CHK_API(OMX_ErrorIncorrectStateTransition);
    }

    case OMX_StateExecuting:
    {
        /* ...transition to executing state */
        if (pData->state == OMX_StateIdle) {
            /* ...check if runtime initialization is required */
            if ( (eos_codec & XA_FLAG_CODEC_IDLE) != 0 ) {
                /* ...mark initialization sequence is started */
                eos_codec ^= XA_FLAG_CODEC_IDLE | XA_FLAG_CODEC_START;
                
                if (pData->nTunnelFlags[1] != XA_FLAG_TUNNEL_NONE) {
                    eos_codec ^= XA_FLAG_CODEC_START | XA_FLAG_CODEC_EXECUTE;
                }
                else if (pData->nTunnelFlags[0] != XA_FLAG_TUNNEL_NONE) {
                    for (i = 0; i <= XAOMX_PORT_MAX; i++)
                    {
                        if (pData->sPortDef[i].eDir == OMX_DirInput)
                        {
                            xaomx_command(pData, XAOMX_CommandEmptyThisBuffer, (OMX_PTR)0, i);
                            break;
                        }
                    }
                }
                else {
                	/* ...do nothing */
                }
            }
            else {
                /* ...switching back to execution state */
                eos_codec ^= XA_FLAG_CODEC_EXECUTE;
            }
            
            /* ...immediately switch to new operating state */
            goto complete;      /* PRQA S 2001 *//* Confirm goto usage is correct. Oct 14, 2016 */
        }
        else if (pData->state == OMX_StatePause) {
            /* ...force timestamp reset */
            eos_codec |= XA_FLAG_CODEC_TS;

            /* ...immediately switch to new operating state */
            goto complete;      /* PRQA S 2001 *//* Confirm goto usage is correct. Oct 14, 2016 */
        }
        else {
        	/* ...do nothing */
        }

        /* ...otherwise, transition is incorrect */
        return XAOMX_CHK_API(OMX_ErrorIncorrectStateTransition);
    }

    case OMX_StatePause:
    {
        /* ...transition to pause state; possible only from executing */
        XF_CHK_ERR(pData->state == OMX_StateExecuting, OMX_ErrorIncorrectStateTransition);

        /* ...StageFright doesn't support that state; return something */
        return XAOMX_CHK_API(OMX_ErrorNotImplemented);
    }

    case OMX_StateWaitForResources:
    {
        /* ...transition to waiting state; possible only from loaded */
        XF_CHK_ERR(pData->state == OMX_StateLoaded, OMX_ErrorIncorrectStateTransition);

        /* ...StageFright doesn't support that state; return something */
        return XAOMX_CHK_API(OMX_ErrorNotImplemented);
    }

    default:
        /* ...invalid state */
        return XAOMX_CHK_API(OMX_ErrorBadParameter);
    }

complete:

    /* ...immediately switch to new state */
    TRACE(SM, _b("Transition successfull"));

    /* ...set new state */
    pData->state = state;

    /* ...update component flags */
    pData->eos_codec = eos_codec;
    pData->eos_port = eos_port;

    /* ...notify client about successfull transition */
    pData->pCallbacks->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, OMX_CommandStateSet, state, OMX_ErrorNone);

    return OMX_ErrorNone;

start:

    /* ...mark state transition sequence is active (what if it's already active?) */
    eos_port |= XA_FLAG_STATE_COMMAND;

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        /* ...check if port reset is required */
        if ( ((eos_port ^ pData->eos_port) & XA_FLAG_PORT_RESETTING(i)) != 0 ) {
            xaomx_command(pData, XAOMX_CommandFlush, (OMX_PTR)0, i);
        }
    }

    /* ...update component flags */
    pData->eos_codec = eos_codec;
    pData->eos_port = eos_port;

    TRACE(SM, _b("Active sequences: %X"), eos_codec);

    /* ...and process the state change */
    return xaomx_state_process(pData);
}

/* ...process port-control commands */
static OMX_ERRORTYPE xaomx_command_port_control(XAOMXTDMCodecBase *pData, OMX_COMMANDTYPE cmd, OMX_U32 nPort)
{
    u32     eos_codec = pData->eos_codec;
    u32     eos_port = pData->eos_port;
    s32     i;
    s32     port_type = XAOMX_NOPORT;

    /* ...sanity check */
    XF_CHK_ERR((nPort <= XAOMX_PORT_MAX) || (nPort == OMX_ALL), OMX_ErrorBadParameter);

    /* ...make sure we have just one active port sequence */
    if ( (pData->sPortDef[nPort].eDir == OMX_DirInput) || (nPort == OMX_ALL) ) {

        /* ...mark port is input port */
        port_type = XAOMX_INPUT_PORT;
        XF_CHK_ERR((eos_port & XA_FLAG_PORT_COMMAND(nPort)) == 0, OMX_ErrorIncorrectStateOperation);
    }

    if ( ((pData->sPortDef[nPort].eDir == OMX_DirOutput)) || (nPort == OMX_ALL) ) {

        /* ...mark port is output port */
        port_type = XAOMX_OUTPUT_PORT;
        XF_CHK_ERR((eos_port & XA_FLAG_PORT_COMMAND(nPort)) == 0, OMX_ErrorIncorrectStateOperation);
    }

    /* ...command dispatching */
    switch(cmd) {
    case OMX_CommandPortDisable:
    {
        /* ...immediately disable port(s) and start disable sequence */
        if ( (port_type == XAOMX_INPUT_PORT) && (pData->sPortDef[nPort].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[0] == XA_FLAG_TUNNEL_NONE) ) {
            pData->sPortDef[nPort].bEnabled = OMX_FALSE;
            eos_port |= XA_FLAG_PORT_FLUSHING(nPort) | XA_FLAG_PORT_RESETTING(nPort) | XA_FLAG_PORT_UNPOPULATING(nPort);
        }

        if ( (port_type == XAOMX_OUTPUT_PORT) && (pData->sPortDef[nPort].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) ) {
            pData->sPortDef[nPort].bEnabled = OMX_FALSE;
            eos_port |= XA_FLAG_PORT_FLUSHING(nPort) | XA_FLAG_PORT_RESETTING(nPort) | XA_FLAG_PORT_UNPOPULATING(nPort);
        }

        break;
    }

    case OMX_CommandPortEnable:
    {
        /* ...immediately enable port(s) and start enable sequence */
        if ( (port_type == XAOMX_INPUT_PORT) && (pData->sPortDef[nPort].bEnabled == OMX_FALSE) ) {
            pData->sPortDef[nPort].bEnabled = OMX_TRUE;
            if (pData->nTunnelFlags[nPort] == XA_FLAG_TUNNEL_NONE) {
                eos_port |= XA_FLAG_PORT_POPULATING(nPort);
                eos_codec |= XA_FLAG_CODEC_TS;
            }
        }

        if ( (port_type == XAOMX_OUTPUT_PORT) && (pData->sPortDef[nPort].bEnabled == OMX_FALSE) ) {
            pData->sPortDef[nPort].bEnabled = OMX_TRUE;
            if (pData->nTunnelFlags[nPort] == XA_FLAG_TUNNEL_NONE) {
                eos_port |= XA_FLAG_PORT_POPULATING(nPort);
            }
        }

        break;
    }

    case OMX_CommandFlush:
    {
        /* ...command permitted only in executing/pause state */
        XF_CHK_ERR(pData->state == OMX_StateExecuting || pData->state == OMX_StatePause, OMX_ErrorIncorrectStateOperation);

        /* ...start port(s) flushing sequence */
        if ( (port_type == XAOMX_INPUT_PORT) && (pData->nTunnelFlags[0] == XA_FLAG_TUNNEL_NONE) ) {
//            for (i = 0; i < XAOMX_PORT_MAX; i++)
//            {
            eos_port |= XA_FLAG_PORT_FLUSHING(nPort) | XA_FLAG_PORT_RESETTING(nPort);
            eos_codec |= XA_FLAG_CODEC_TS;
//            }
            /* ...clear "end-of-input-stream" condition if present */
            //eos_codec &= ~XA_FLAG_CODEC_INPUT_DONE;
        }

        if ( (port_type == XAOMX_OUTPUT_PORT) && (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) ) {
//            for (i = 0; i < XAOMX_PORT_MAX; i++)
//            {
            eos_port |= XA_FLAG_PORT_FLUSHING(nPort) | XA_FLAG_PORT_RESETTING(nPort);
//            }
            /* ...clear "end-of-output-stream" condition if present */
            //eos_codec &= ~XA_FLAG_CODEC_OUTPUT_DONE;;
        }

        break;
    }

    default:
        /* ...unrecognized command received */
        return XAOMX_CHK_API(OMX_ErrorBadParameter);
    }

    /* ...set active port command (if there is another command pending? - tbd) */
    if ( port_type == XAOMX_INPUT_PORT) {
//        for (i = 0; i < XAOMX_PORT_MAX; i++)
//        {
        eos_port |= XA_FLAG_PORT_COMMAND(nPort);
            pData->nPortCommand[nPort] = cmd;
//        }
    }

    if ( port_type == XAOMX_OUTPUT_PORT) {
        eos_port |= XA_FLAG_PORT_COMMAND(nPort);
        pData->nPortCommand[nPort] = cmd;
    }

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        /* ...check if port reset is required */
        if ( ((eos_port ^ pData->eos_port) & XA_FLAG_PORT_RESETTING(i)) != 0 ) {
            xaomx_command(pData, XAOMX_CommandFlush, (OMX_PTR)&i, i); /* PRQA S 2469 *//* the value of i is guarantee */
        }
    }

    /* ...update component flags */
    pData->eos_codec = eos_codec;
    pData->eos_port = eos_port;

    TRACE(SM, _b("Active sequences: %X"), eos_codec);

    /* ...and process state change as required */
    return xaomx_state_process(pData);
}

/* ...process buffer marking */
static OMX_ERRORTYPE xaomx_command_mark_buffer(XAOMXTDMCodecBase *pData, OMX_U32 nPort, OMX_MARKTYPE *pMarkBuf)
{
    /* ...check the mark data is valid */
    XF_CHK_ERR(pMarkBuf, OMX_ErrorBadParameter);

    /* ...accept commands only on input port */
    XF_CHK_ERR(nPort <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

    /* ...check execution state is sane */
    XF_CHK_ERR(pData->state == OMX_StateExecuting || pData->state == OMX_StatePause, OMX_ErrorIncorrectStateOperation);

    /* ...if there is already a queued mark data, discard this one */
    XF_CHK_ERR(pData->pMarkBuf == NULL, OMX_ErrorIncorrectStateOperation);

    /* ...save the mark data until new input buffer arrives */
    pData->pMarkBuf = pMarkBuf;

    return OMX_ErrorNone;
}

/* ...retrieve component parameters */
static OMX_ERRORTYPE xaomx_get_parameter(XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    switch (nIndex) {
    case OMX_IndexParamPortDefinition:
    {
        /* ...get OMX_PARAM_PORTDEFINITIONTYPE structure */
        OMX_U32 nPort = ((OMX_PARAM_PORTDEFINITIONTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->sPortDef[nPort], sizeof(OMX_PARAM_PORTDEFINITIONTYPE));          /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPortFormat:
    {
        /* ...get OMX_PARAM_PORTDEFINITIONTYPE structure */
        OMX_U32 nPort = ((OMX_AUDIO_PARAM_PORTFORMATTYPE *) pParam)->nPortIndex;

        XF_CHK_ERR(nPort <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

        memcpy(pParam, &pData->sPortFormat[nPort], sizeof(OMX_AUDIO_PARAM_PORTFORMATTYPE));     /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    case OMX_IndexParamPriorityMgmt:
    {
        /* ...gets OMX_PRIORITYMGMTTYPE structure */
        memcpy(pParam, &pData->sPriorityMgmt, sizeof(OMX_PRIORITYMGMTTYPE));                    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter - pass to codec-specific hook */
        TRACE(SM, _b("query codec-specific parameters: %X"), nIndex);
        return pData->GetParameter(pData, nIndex, pParam);
    }
}

/* ...set component parameters */
static OMX_ERRORTYPE xaomx_set_parameter(XAOMXTDMCodecBase *pData, OMX_INDEXTYPE nIndex, OMX_PTR pParam)
{
    switch (nIndex) {
    case OMX_IndexParamPortDefinition:
    {
        /* ...set OMX_PARAM_PORTDEFINITIONTYPE structure */
        OMX_PARAM_PORTDEFINITIONTYPE   *param = (OMX_PARAM_PORTDEFINITIONTYPE *) pParam;
        OMX_U32                         port = param->nPortIndex;

        TRACE(INIT, _b("set-parameter: OMX_IndexParamPortDefinition, port = %lu"), port);

        /* ...check port validity */
        XF_CHK_ERR(port <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

        /* ...check state validity (port must not be locked) */
        XF_CHK_ERR(pData->sBufList[port].nUsedCount == 0, OMX_ErrorIncorrectStateOperation);

        /* ...we shall try to preserve read-only fields of the structure (TBD) */
        memcpy(&pData->sPortDef[port], param, sizeof(*param));      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    case OMX_IndexParamAudioPortFormat:
    {
        /* ...set OMX_PARAM_PORTDEFINITIONTYPE structure */
        OMX_AUDIO_PARAM_PORTFORMATTYPE *param = (OMX_AUDIO_PARAM_PORTFORMATTYPE *) pParam;
        OMX_U32                         port = param->nPortIndex;

        TRACE(INIT, _b("set-parameter: OMX_IndexParamAudioPortFormat, port = %lu"), port);

        /* ...check port validity */
        XF_CHK_ERR(port <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

        /* ...check state validity (port must not be locked) */
        XF_CHK_ERR(pData->sBufList[port].nUsedCount == 0, OMX_ErrorIncorrectStateOperation);

        /* ...there are some read-only fields that should be preserved */
        memcpy(&pData->sPortFormat[port], param, sizeof(OMX_AUDIO_PARAM_PORTFORMATTYPE));   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    case OMX_IndexParamPriorityMgmt:
    {
        /* ...set OMX_PRIORITYMGMTTYPE structure */
        OMX_PRIORITYMGMTTYPE *param = (OMX_PRIORITYMGMTTYPE *) pParam;

        TRACE(INIT, _b("set-parameter: OMX_IndexParamPriorityMgmt"));

        /* ...check state validity */
        XF_CHK_ERR(pData->state == OMX_StateLoaded, OMX_ErrorIncorrectStateOperation);

        /* ...we do not use that thing at all (TBD) */
        memcpy(&pData->sPriorityMgmt, param, sizeof(*param));       /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return OMX_ErrorNone;
    }

    case OMX_IndexParamStandardComponentRole:
    {
        /* ...sets OMX_PARAM_COMPONENTROLETYPE structure */
        OMX_PARAM_COMPONENTROLETYPE *param = (OMX_PARAM_COMPONENTROLETYPE *) pParam;

        TRACE(INIT, _b("set-parameter: OMX_IndexParamStandardComponentRole (%s)"), (const OMX_STRING)param->cRole);

        /* ...check state validity */
        XF_CHK_ERR(pData->state == OMX_StateLoaded, OMX_ErrorIncorrectStateOperation);

        /* ...we support single role for a component */
        XF_CHK_ERR(strcmp((const OMX_STRING)param->cRole, pData->cRole) == 0, OMX_ErrorUnsupportedIndex);

        return OMX_ErrorNone;
    }

    default:
        /* ...unrecognized parameter - pass to codec-specific hook */
        return pData->SetParameter(pData, nIndex, pParam);
    }
}

/* ...use/allocate buffer */
static OMX_ERRORTYPE xaomx_create_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE **ppBufHdr, OMX_U32 nPort, OMX_U32 nSize, OMX_PTR pAppPrivate, OMX_PTR pBuffer, OMX_BOOL bAllocate)
{
    OMX_PARAM_PORTDEFINITIONTYPE   *pPortDef = &pData->sPortDef[nPort];
    XA_BUFFERLIST                  *pBufList = &pData->sBufList[nPort];
    OMX_BUFFERHEADERTYPE           *pBufHdr;

    /* ...check buffer size is suitable */
    XF_CHK_ERR(nSize <= pPortDef->nBufferSize, OMX_ErrorBadParameter);

    /* ...permitted only if port populating sequence is active */
    XF_CHK_ERR(pData->eos_port & XA_FLAG_PORT_POPULATING(nPort), OMX_ErrorIncorrectStateOperation);

    /* ...allocate buffer header */
    XF_CHK_ERR(pBufHdr = xa_bufferlist_allocate(pBufList), OMX_ErrorInsufficientResources);

    /* ...port binding */
    if (pData->sPortDef[nPort].eDir == OMX_DirInput)
    {
        pBufHdr->nInputPortIndex = nPort;
        pBufHdr->nOutputPortIndex = XAOMX_NOPORT;
        pBufHdr->pAppPrivate = pBufHdr->pInputPortPrivate = pAppPrivate;
    }
    else if (pData->sPortDef[nPort].eDir == OMX_DirOutput)
    {
        pBufHdr->nInputPortIndex = XAOMX_NOPORT;
        pBufHdr->nOutputPortIndex = nPort;
        pBufHdr->pAppPrivate = pBufHdr->pOutputPortPrivate = pAppPrivate;
    }
    else
    {
        pBufHdr->nInputPortIndex = XAOMX_NOPORT;
        pBufHdr->nOutputPortIndex = XAOMX_NOPORT;
    }

    /* ...set buffer pointer */
    if (bAllocate == OMX_TRUE) {
        xf_buffer_t    *buffer;

        /* ...get buffer from the shared memory pool */
        buffer = xf_buffer_get(pBufList->pPool);
        if (buffer == NULL) {
            /* ...allocation failed; release buffer header */
            free(pBufHdr);      /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */
            pBufList->nUsedCount--;

            /* ...and bail out */
            return XAOMX_CHK_API(OMX_ErrorInsufficientResources);
        }

        /* ...set buffer pointer and size */
        pBufHdr->pBuffer = xf_buffer_data(buffer);
        pBufHdr->nAllocLen = xf_buffer_length(buffer);
        pBufHdr->pPlatformPrivate = buffer;
    }
    else {
        /* ...set buffer pointer and size (do support buffer preannouncing) */
        pBufHdr->pBuffer = pBuffer;
        pBufHdr->nAllocLen = ( (pBufHdr->pBuffer == NULL) ? 0 : nSize);
    }

    /* ...return created buffer header */
    *ppBufHdr = pBufHdr;

    /* ...check if port populating sequence is over */
    if (pBufList->nUsedCount == pPortDef->nBufferCountActual) {
        /* ...port is populated */
        pPortDef->bPopulated = OMX_TRUE;

        /* ...clear port populating sequence */
        pData->eos_port ^= XA_FLAG_PORT_POPULATING(nPort);

        /* ...and process state change */
        return xaomx_state_process(pData);
    }

    return OMX_ErrorNone;
}

/* ...free buffer */
static OMX_ERRORTYPE xaomx_free_buffer(XAOMXTDMCodecBase *pData, OMX_U32 nPort, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    OMX_PARAM_PORTDEFINITIONTYPE   *pPortDef = &pData->sPortDef[nPort];
    XA_BUFFERLIST                  *pBufList = &pData->sBufList[nPort];

    /* ...command permitted only if port unpopulating sequence is active */
    XF_CHK_ERR(pData->eos_port & XA_FLAG_PORT_UNPOPULATING(nPort), OMX_ErrorIncorrectStateOperation);

    /* ...release shared buffer if it's allocated */
    if (pBufHdr->pPlatformPrivate != NULL) {
        xf_buffer_put((xf_buffer_t *)pBufHdr->pPlatformPrivate);
    }

    /* ...release buffer header (buffer cannot be in a pending list) */
    free(pBufHdr);      /* PRQA S 5118 *//* Confirm free memory usage is correct. Oct 14, 2016 */

    /* ...decerement total use-counter */
    pBufList->nUsedCount--;
    if (pBufList->nUsedCount == 0) {
        /* ...last buffer freed; set unpopulated flag */
        pPortDef->bPopulated = OMX_FALSE;

        /* ...clear port unpopulating sequence flag and unlock port state */
        pData->eos_port ^= XA_FLAG_PORT_UNPOPULATING(nPort);

        /* ...and process state change */
        return xaomx_state_process(pData);
    }

    return OMX_ErrorNone;
}

/* ...submit input buffer for transmission */
static OMX_ERRORTYPE xaomx_empty_this_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    OMX_U32         port_idx = pBufHdr->nInputPortIndex;
    XA_BUFFERLIST  *pBufList = &pData->sBufList[port_idx];

    /* ...check input port is enabled and not busy */
    XF_CHK_ERR(pData->sPortDef[port_idx].bEnabled && (pData->eos_port & XA_FLAG_PORT_BUSY(port_idx)) == 0, OMX_ErrorIncorrectStateOperation);

    /* ...check execution state is sane */
    XF_CHK_ERR(pData->state == OMX_StateExecuting || pData->state == OMX_StatePause, OMX_ErrorIncorrectStateOperation);

    /* ...forbid sending a buffer after end-of-stream has been reported */
    XF_CHK_ERR((pData->eos_codec & XA_FLAG_CODEC_INPUT_DONE) == 0, OMX_ErrorIncorrectStateOperation);

    /* ...make sure input length is not zero */
    XF_CHK_ERR(pBufHdr->nFilledLen != 0 || (pBufHdr->nFlags & OMX_BUFFERFLAG_EOS), OMX_ErrorBadParameter);

#if 0
    /* ...codec-specific buffer preprocessing */
    if (pData->CodecBufferPreprocess)
        pData->CodecBufferPreprocess(pData, pBufHdr);
#endif

    /* ...put the buffer into pending queue */
    if (xa_bufferlist_submit(pBufList, pBufHdr) != 0) {
        /* ...instruct thread to start buffers transmission if required */
        xaomx_command(pData, XAOMX_CommandEmptyThisBuffer, NULL, port_idx);
    }

    /* ...check if the buffer is first one after playback start */
    if ( (pData->eos_codec & XA_FLAG_CODEC_TS) != 0) {
        /* ...retrieve the timestamp from input buffer */
        pData->nTimeStamp = pBufHdr->nTimeStamp;

        /* ...and clear that flag */
        pData->eos_codec ^= XA_FLAG_CODEC_TS;
    }

    /* ...mark current buffer if there is outstanding command and buffer is not marked */
    if ( (pData->pMarkBuf != NULL) && (pBufHdr->pMarkData == NULL) ) {
        /* ...attach current marker to the buffer */
        pBufHdr->hMarkTargetComponent = pData->pMarkBuf->hMarkTargetComponent;
        pBufHdr->pMarkData = pData->pMarkBuf->pMarkData;
        pData->pMarkBuf = NULL;

        /* ...notify application about successfull completion of mark buffer command */
        pData->pCallbacks->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, OMX_CommandMarkBuffer, 0, (OMX_PTR) OMX_ErrorNone);
    }

    /* ...check for input stream termination */
    if ( (pBufHdr->nFlags & OMX_BUFFERFLAG_EOS) != 0 ) {
        TRACE(SM, _b("End-of-stream received"));

        /* ...set end-of-stream flag */
        pData->eos_codec ^= XA_FLAG_CODEC_INPUT_DONE;
    }

    return OMX_ErrorNone;
}

/* ...submit output buffer for transmission */
static OMX_ERRORTYPE xaomx_fill_this_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr)
{
    OMX_U32        port_idx = pBufHdr->nOutputPortIndex;
    XA_BUFFERLIST  *pBufList = &pData->sBufList[port_idx];

    /* ...check output port is enabled and not busy */
    XF_CHK_ERR(pData->sPortDef[port_idx].bEnabled  && (pData->eos_port & XA_FLAG_PORT_BUSY(port_idx)) == 0, OMX_ErrorIncorrectStateOperation);

    /* ...check execution state is sane */
    XF_CHK_ERR(pData->state == OMX_StateExecuting || pData->state == OMX_StatePause, OMX_ErrorIncorrectStateOperation);

    /* ...forbid sending a buffer after end-of-stream has been reported */
    XF_CHK_ERR((pData->eos_codec & XA_FLAG_CODEC_OUTPUT_DONE) == 0, OMX_ErrorIncorrectStateOperation);

    /* ...put the buffer into pending queue */
    if (xa_bufferlist_submit(pBufList, pBufHdr) != 0) {
        if ( (pData->eos_codec & XA_FLAG_CODEC_EXECUTE) != 0 ) {
            xaomx_command(pData, XAOMX_CommandFillThisBuffer, NULL, port_idx);
        }
    }

    return OMX_ErrorNone;
}

/* ...return buffer to client */
static void xaomx_return_buffer(XAOMXTDMCodecBase *pData, OMX_BUFFERHEADERTYPE *pBufHdr, OMX_BOOL bDone)
{
    OMX_CALLBACKTYPE   *cb = pData->pCallbacks;
    s32                 port_index;

    if (pBufHdr->nInputPortIndex == XAOMX_NOPORT)
    {
        port_index = pBufHdr->nOutputPortIndex;
    }
    else
    {
        port_index = pBufHdr->nInputPortIndex;
    }

    if (pData->sPortDef[port_index].eDir == OMX_DirInput) {
        /* ...input buffer completed */
        TRACE(INPUT, _b("EmptyBufferDone[%p]: (%p, %lu)"), pBufHdr, pBufHdr->pBuffer, pBufHdr->nFilledLen);

        /* ...return buffer to client */
        cb->EmptyBufferDone(pData->hSelf, pData->pAppData, pBufHdr);

        /* ...process buffer mark command as required */
        if (pBufHdr->pMarkData != NULL) {
            if (pBufHdr->hMarkTargetComponent == pData->hSelf) {
                /* ...we are intended recipient; notify application about buffer processing */
                cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventMark, 0, 0, pBufHdr->pMarkData);
            }
            else if ( (pData->pMarkData == NULL) && (bDone == OMX_TRUE) ) {
                /* ...propagate mark data (next returned output buffer will get the buffer mark) */
                pData->pMarkData = pBufHdr->pMarkData;
                pData->hMarkTargetComponent = pBufHdr->hMarkTargetComponent;
            }
            else {
                /* ...mark propagation is not possible */ /* PRQA S 0306 1 *//* Confirm pointer casting is in original design intention. Oct 14, 2016 */
                cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, OMX_CommandMarkBuffer, 0, (OMX_PTR) OMX_ErrorNotImplemented);
            }
        }
    }
    else {
        /* ...output buffer completed */
        TRACE(OUTPUT, _b("FillBufferDone[%p]: (%p, %lu)"), pBufHdr, pBufHdr->pBuffer, pBufHdr->nFilledLen);

        /* ...attach buffer mark if required */
        if (pData->pMarkData != NULL) {
            pBufHdr->pMarkData = pData->pMarkData;
            pBufHdr->hMarkTargetComponent = pData->hMarkTargetComponent;
            pData->pMarkData = NULL;
        }

        /* ...return buffer to client */
        cb->FillBufferDone(pData->hSelf, pData->pAppData, pBufHdr);
    }
}

/*******************************************************************************
 * State-machine implementation - execution in component thread context
 ******************************************************************************/

/* ...process command submitted from IL and having unpredictable duration */
static s32 xaomx_command_process(XAOMXTDMCodecBase *pData, OMX_COMMANDTYPE cmd, OMX_PTR cmddata, OMX_S32 portidx)   /* PRQA S 3206 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    xf_handle_t    *handle = &pData->handle;
    s32             i;

    TRACE(CMD, _b("cmd = %u, cmddata = %p"), cmd, cmddata);

    /* ...command dispatching */
    switch (cmd) {
    case XAOMX_CommandFillThisBuffer:
    {
        /* ...pass all pending output buffers to proxy */
        return XF_CHK_API(xa_commit_buffers(pData, portidx));     /* PRQA S 0745 *//* Confirm return value is correct. Oct 14, 2016 */
    }

    case XAOMX_CommandEmptyThisBuffer:
    {
        /* ...pass all pending input buffers to proxy */
        XF_CHK_API(xa_commit_buffers(pData, portidx));

        /* ...process kick-off separately */
        if ( (pData->eos_codec & XA_FLAG_CODEC_START) != 0) {
            /* ...mark initialization sequence is on-going */
            pData->eos_codec ^= XA_FLAG_CODEC_START | XA_FLAG_CODEC_INIT;

            /* ...and start codec operation - submit first bogus output buffer */
            if (pData->nTunnelFlags[1] == XA_FLAG_TUNNEL_NONE) {
                for (i = 0; i <= XAOMX_PORT_MAX; i++)
                {
                    /* ...fill buffer to output port */
                    if (pData->sPortDef[i].eDir == OMX_DirOutput)
                    {
                        XF_CHK_API(xa_cmd_send(pData, i, XF_FILL_THIS_BUFFER, xf_buffer_data(handle->aux), 0));
                        break;
                    }
                }
            }
        }

        /* ...if end-of-stream condition detected, pass final bogus buffer */
        if ( (pData->eos_codec & XA_FLAG_CODEC_INPUT_DONE) != 0 ) {
            /* ....start draining sequence - pass end-of-stream marker */
            for (i = 0; i <= XAOMX_PORT_MAX; i++)
            {
                /* ...empty buffer to input port */
                if (pData->sPortDef[i].eDir == OMX_DirInput)
                {
                    XF_CHK_API(xa_cmd_send(pData, i, XF_EMPTY_THIS_BUFFER, NULL, 0));
                    break;
                }
            }
        }

        return 0;
    }

    case XAOMX_CommandFlush:
    {
        /* ...deliver codec flush command to proxy (destination port passed in parameter) */
        return XF_CHK_API(xa_cmd_send(pData, portidx, XF_FLUSH, NULL, 0));  /* PRQA S 0745 *//* Confirm return value is correct. Oct 14, 2016 */
    }

    case XAOMX_CommandDeinitialize:
    {
        /* ...stop command received */
        TRACE(SM, _b("Thread termination command received"));

        /* ...positive error indicates thread termination */
        return 1;
    }

    default:
        /* ...invalid command received */
        return XF_CHK_API(-EINVAL);     /* PRQA S 0745 *//* Confirm return value is correct. Oct 14, 2016 */
    }
}

/* ...handle response received from proxy */
static s32 xaomx_response_process(XAOMXTDMCodecBase *pData, xf_user_msg_t *m)
{
    OMX_CALLBACKTYPE       *cb = pData->pCallbacks;
    OMX_BUFFERHEADERTYPE   *pBufHdr;
    s32                     port_idx = XF_MSG_SRC_PORT(m->id);

    TRACE(RSP, _b("R[%08X:%08X:%p:%u]"), m->id, m->opcode, m->buffer, m->length);

    switch((s32)m->opcode) {
    case XF_EMPTY_THIS_BUFFER:
    {
//        port_idx = XF_MSG_DST_PORT(m->id);

        /* ...input buffer processed; check if draining sequence is active */
        if (m->buffer == NULL) {
            /* ...NULL-buffer received as result of end-of-stream processing */
            XF_CHK_ERR(pData->eos_codec & XA_FLAG_CODEC_INPUT_DONE, -EBADF);

            /* ...make sure length is zero */
            XF_CHK_ERR(m->length == 0, -EBADF);

            /* ...if component is not in execution state, it is a fatal execution error */
            XF_CHK_ERR(pData->eos_codec & XA_FLAG_CODEC_EXECUTE, -EPIPE);

            TRACE(SM, _b("Playback completed"));
        }
        else {
            /* ...input buffer processed; remove it from pending queue */
            XF_CHK_ERR(pBufHdr = xa_bufferlist_retrieve(&pData->sBufList[port_idx], m->buffer), -EBADF);

            /* ...mark the buffer is fully consumed if length is not zero - need that? - tbd */
            if (m->length != 0) {
                pBufHdr->nFilledLen = 0;
            }

            /* ...return buffer to client */
            xaomx_return_buffer(pData, pBufHdr, OMX_TRUE);
        }

        return 0;
    }

    case XF_FILL_THIS_BUFFER:
    {
//        port_idx = XF_MSG_SRC_PORT(m->id);

        /* ...output buffer processed; check if it is a runtime initialization */
        if ( (pData->eos_codec & XA_FLAG_CODEC_INIT) != 0 ) {
            u32     n;

            /* ...runtime initialization sequence completed; check buffer is valid */
//            XF_CHK_ERR(m->buffer == xf_buffer_data(pData->handle.aux) && m->length == sizeof(xf_start_msg_t), -EBADF);

            TRACE(INIT, _b("Runtime initialization completed"));

            /* ...initialize output port of the component */
            n = (u32)pData->CodecRuntimeInit(pData, m->buffer);
            if (n != 0) {
                /* ...component requires extra parameters; pass command to a codec */
                return XF_CHK_API(xa_cmd_send(pData, 0, XF_GET_PARAM, m->buffer, n));   /* PRQA S 0745 *//* Confirm return vaule is correct. Oct 14, 2016 */
            }
            else {
                /* ...initialization sequence is completed; proceed to output port setup */
                return XF_CHK_API(xa_codec_output_setup(pData));                        /* PRQA S 0745 *//* Confirm return vaule is correct. Oct 14, 2016 */
            }
        }

        /* ...retrieve buffer header */
        XF_CHK_ERR(pBufHdr = xa_bufferlist_retrieve(&pData->sBufList[port_idx], m->buffer), -EBADF);

        /* ...specify the length of output buffer (check if flag should be tested indeed - tbd) */
        pBufHdr->nFilledLen = m->length;
        if ( (pBufHdr->nFilledLen == 0) && ((pData->eos_codec & XA_FLAG_CODEC_INPUT_DONE) != 0) ) {
            /* ...in-band zero-length output buffer received - playback is done */
            if ((pData->eos_codec & XA_FLAG_CODEC_OUTPUT_DONE) == 0) {
                /* ...attach buffer flag only to first buffer reported */
                pData->eos_codec ^= XA_FLAG_CODEC_OUTPUT_DONE;

                /* ...attach end-of-stream flag to output buffer */
                pBufHdr->nFlags |= OMX_BUFFERFLAG_EOS;

                /* ...notify application about last buffer processing */
                cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventBufferFlag, 1, pBufHdr->nFlags, NULL);

                TRACE(SM, _b("End-of-stream marker passed to output"));
            }
            else {
                /* ...all subsequent buffers shall be dropped */
                xaomx_return_buffer(pData, pBufHdr, OMX_FALSE);

                return 0;
            }
        }

        /* ...set timestamp of the buffer */
        pData->CodecTimeStamp(pData, pBufHdr);

        /* ...return buffer back to client */
        xaomx_return_buffer(pData, pBufHdr, OMX_TRUE);

        return 0;
    }

    case XF_FLUSH:
    {
//        port_idx = XF_MSG_SRC_PORT(m->id);

        /* ...port reset response received */
        if (pData->sPortDef[port_idx].eDir == OMX_DirInput) {
            /* ...input port flushed; make sure reset sequence is active */
            XF_CHK_ERR(pData->eos_port & XA_FLAG_PORT_RESETTING(port_idx), -EBADF);

            /* ...clear input path reset flag */
            pData->eos_port &= ~(XA_FLAG_PORT_RESETTING(port_idx));
            pData->eos_codec &= ~(XA_FLAG_CODEC_INPUT_DONE);
        }
        else {
            /* ...output port flushed; make sure reset sequence is active */
            XF_CHK_ERR(pData->eos_port & XA_FLAG_PORT_RESETTING(port_idx), -EBADF);

            /* ...clear output path reset flag  */
            pData->eos_port &= ~(XA_FLAG_PORT_RESETTING(port_idx));
            pData->eos_codec &= ~(XA_FLAG_CODEC_OUTPUT_DONE);
        }

        return 0;
    }

    case XF_GET_PARAM:
    {
        /* ...codec must be in "initialization" state */
        XF_CHK_ERR(pData->eos_codec & XA_FLAG_CODEC_INIT, -EBADF);

        /* ...pass parameter to codec-specific function */
        XF_CHK_API(pData->CodecGetParam(pData, m->buffer, m->length));

        /* ...complete output port setup */
        return XF_CHK_API(xa_codec_output_setup(pData));            /* PRQA S 0745 *//* Confirm return vaule is correct. Oct 14, 2016 */
    }

    case XF_SET_PARAM:
    {
        /* ...codec must be in "creation" state */
        XF_CHK_ERR(pData->eos_codec & XA_FLAG_CODEC_SETUP, -EBADF);

        /* ...switch to idle state */
        pData->eos_codec ^= XA_FLAG_CODEC_SETUP | XA_FLAG_CODEC_IDLE;

        /* ...resume OMX client waiting for operation completion */
        pthread_cond_signal(&pData->wait);                          /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        return 0;
    }

    default:
        /* ...invalid response received */
        return XF_CHK_API(-EBADF);                                  /* PRQA S 0745 *//* Confirm return vaule is correct. Oct 14, 2016 */
    }
}

/* ...process port flushing */
static OMX_ERRORTYPE xaomx_port_state_process(XAOMXTDMCodecBase *pData, OMX_U32 nPort)
{
    XA_BUFFERLIST          *pBufList = &pData->sBufList[nPort];
    OMX_BUFFERHEADERTYPE   *pBufHdr;

    /* ...check if port flushing activity is ended */
    if ((pData->eos_port & XA_FLAG_PORT_FLUSHING(nPort)) != 0) {
        /* ...do nothing if there are active (proxy-owned) buffers */
        if (pBufList->nActiveCount != 0) {
            return OMX_ErrorNone;
        }

        /* ...release all pending (component-owned) buffers */
        while ((pBufHdr = xa_bufferlist_peek(pBufList)) != NULL) {  /* PRQA S 3326 *//* Confirm function usage is correct. Oct 14, 2016 */
            xaomx_return_buffer(pData, pBufHdr, OMX_FALSE);
        }

        /* ...make sure the buffer gets empty */
        XF_CHK_ERR(pBufList->nPendingCount == 0, OMX_ErrorUndefined);

        /* ...clear port flushing sequence flag */
        pData->eos_port ^= XA_FLAG_PORT_FLUSHING(nPort);

        TRACE(SM, _b("Port %lu is flushed"), nPort);
    }

    /* ...process port command completion as required */
    if ((pData->eos_port & XA_FLAG_PORT_BUSY(nPort)) == XA_FLAG_PORT_COMMAND(nPort)) {
        /* ...port-specific command processed successfully */
        TRACE(SM, _b("Port %lu command[%u] completed"), nPort, pData->nPortCommand[nPort]);

        /* ...notify client about command completion */
        pData->pCallbacks->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, pData->nPortCommand[nPort], nPort, OMX_ErrorNone);

        /* ...and clear port command flag */
        pData->eos_port ^= XA_FLAG_PORT_COMMAND(nPort);
    }

    /* ...check if port is to be destroyed */
    if ((pData->eos_port & XA_FLAG_PORT_BUSY(nPort)) == XA_FLAG_PORT_DESTROYING(nPort)) {
        /* ...destroy the port */
        xa_bufferlist_destroy(pData, nPort);
        
        /* ...clear port destroying command */
        pData->eos_port ^= XA_FLAG_PORT_DESTROYING(nPort);
    }
    
    return OMX_ErrorNone;
}

/* ...process component state change */
static OMX_ERRORTYPE xaomx_state_process(XAOMXTDMCodecBase *pData)
{
    OMX_CALLBACKTYPE       *cb = pData->pCallbacks;
    s32                     i;

    /* ...bail out if there are no active procedures */
    if ((pData->eos_port & XA_FLAG_COMPONENT_BUSY) == 0) {
        return OMX_ErrorNone;
    }

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        /* ...prorcess input/output port state change as required */
        if ((pData->eos_port & XA_FLAG_PORT_BUSY(i)) != 0) {
            XAOMX_CHK_API(xaomx_port_state_process(pData, i));
        }
    }

    /* ...process state transition */
    if ((pData->eos_port & XA_FLAG_COMPONENT_BUSY) == XA_FLAG_STATE_COMMAND) {
        /* ...complete transition to the state */
        pData->state = pData->nTargetState;

        TRACE(SM, _b("Transition to state %u completed"), pData->state);

        /* ...notify client about command completion */
        cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, OMX_CommandStateSet, pData->state, OMX_ErrorNone);

        /* ...clear state transition command flag */
        pData->eos_port ^= XA_FLAG_STATE_COMMAND;

        /* ...process transition to particular state */
        if (pData->state == OMX_StateIdle) {
            /* ...flush any active mark command */
            if (pData->pMarkData != NULL) {
                TRACE(SM, _b("Mark command failed for %p"), pData->pMarkData);

                /* ...pass failure notification to the client */ /* PRQA S 0306 1 *//* Confirm pointer casting is in original design intention. Oct 14, 2016 */
                cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventCmdComplete, OMX_CommandMarkBuffer, 0, (OMX_PTR) OMX_ErrorIncorrectStateOperation);

                /* ...and clear mark data */
                pData->pMarkData = NULL;
            }
        }
    }

    return OMX_ErrorNone;
}

/* ...main component execution thread */
static void * xaomx_component_thread(void * arg)        /* PRQA S 3219 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    XAOMXTDMCodecBase     *pData = (XAOMXTDMCodecBase *) arg;
    OMX_CALLBACKTYPE   *cb = pData->pCallbacks;
    s32                 fd_cmd;
    s32                 fd_rsp;
    s32                 fd_max;
    s32                 r;

    /* ...adjust thread priority - not needed yet */
    //setpriority(PRIO_PROCESS, 0, ANDROID_PRIORITY_AUDIO);

    /* ...set thread name */
    //prctl(PR_SET_NAME, (unsigned long)pData->pComponentName, 0, 0, 0);

    /* ...calculate maximal file-descriptor value */
    fd_cmd = pData->command[0];
    fd_rsp = pData->response[0];
    fd_max = ( (fd_cmd < fd_rsp) ? fd_rsp : fd_cmd) + 1;

    /* ...start execution loop */
    while (1) {
        fd_set      rfds;

        /* ...reset waiting structure */
        FD_ZERO(&rfds);         /* PRQA S 3397 *//* Confirm macro usage is correct. Oct 14, 2016 */
        FD_SET(fd_cmd, &rfds);
        FD_SET(fd_rsp, &rfds);

        /* ...wait infinitely for command/response */
        r = select(fd_max, &rfds, NULL, NULL, NULL);

        /* ...get component lock */
        pthread_mutex_lock(&pData->mutex);  /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

        /* ...process negative completion */
        if (r < 0) {
            TRACE(ERROR, _b("Communication link broken: %d"), errno);   /* PRQA S 5119 *//* Confirm the need of errno usage. Oct 14, 2016 */
            r = -errno;     /* PRQA S 5119 *//* Confirm the need of errno usage. Oct 14, 2016 */
            goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
        }

        /* ...process all received commands */
        if (FD_ISSET(fd_cmd, &rfds)) {
            XAOMX_COMMAND   command;

            /* ...get command and associated data from pipe (non-blocking) */
            while (read(fd_cmd, &command, sizeof(command)) > 0) {
                /* ...process command */
                r = xaomx_command_process(pData, command.cmd, command.data, command.port);    /* PRQA S 1421 *//* Confirm enum value use is correct. Oct 14, 2016 */

                if (r < 0) {
                    goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
                }
                else if (r > 0) {
                    goto out;       /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
                }
                else {
                	/* ...do nothing */
                }
            }

            /* PRQA S 5119 3 *//* Confirm the need of errno usage. Oct 14, 2016 */
            if (errno != EAGAIN) {
                TRACE(ERROR, _b("Failed to retrieve command: %d"), errno);
                r = -errno;
                goto error;     /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
            }
        }

        /* ...pocess all received responses */
        if (FD_ISSET(fd_rsp, &rfds)) {
            xf_user_msg_t   msg;

            /* ...retrieve all messages that we have here */
            while (read(fd_rsp, &msg, sizeof(msg)) > 0) {

                /* ...process response */
                r = xaomx_response_process(pData, &msg);

                if (r != 0) {
                    goto error; /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
                }
            }

            /* PRQA S 5119 3 *//* Confirm the need of errno usage. Oct 14, 2016 */
            if (errno != EAGAIN) {
                TRACE(ERROR, _b("Failed to retrieve response: %d"), errno);
                r = -errno;
                goto error;         /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
            }
        }

        /* ...process state change */
        if (xaomx_state_process(pData) != OMX_ErrorNone) {
            /* ...translate into generic failure */
            r = -EINVAL;
            goto error;             /* PRQA S 2001 *//* Confirm goto usage is correct for readability. Oct 14, 2016 */
        }

        /* ...release the lock */
        pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    }

error:
    /* ...fatal error encountered; switch to invalid state */
    pData->state = OMX_StateInvalid;

    /* ...pass generic failure notification to application */
    cb->EventHandler(pData->hSelf, pData->pAppData, OMX_EventError, OMX_ErrorUndefined, 0, "Execution error");

    {
        s32 i = 0;

        for (i = 0; i <= XAOMX_PORT_MAX; i++)
        {
            /* ...process for input/output port */
            if ((pData->sPortDef[i].eDir == OMX_DirInput) || (pData->sPortDef[i].eDir == OMX_DirOutput))
            {
                if ( (pData->sPortDef[i].bEnabled == OMX_TRUE) && (pData->nTunnelFlags[i] == XA_FLAG_TUNNEL_NONE) )
                {
                    pData->eos_port |= XA_FLAG_PORT_UNPOPULATING(i);
                }
            }
        }
    }

out:
    /* ...release component lock */
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...resume any pending synchronous operation */
    pthread_cond_signal(&pData->wait);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    TRACE(INIT, _b("thread terminated"));

    return (void *)(intptr_t)r;     /* PRQA S 0306 *//* Confirm casting is correct. Oct 14, 2016 */
}

/* ...codec response processing hook (called on proxy thread context; should not be blocking) */
static void xaomx_response_cb(xf_handle_t *h, xf_user_msg_t *msg)   /* PRQA S 3219 *//* Confirm function usage is correct. Oct 14, 2016 */
{
    XAOMXTDMCodecBase     *pData = container_of(h, XAOMXTDMCodecBase, handle);    /* PRQA S 0306, 0484, 0488 *//* Confirm macro usage is correct. Oct 14, 2016 */

    /* ...put response into a pipe */
    xaomx_response(pData, msg);
}

/*******************************************************************************
 * OpenMAX IL callbacks wrappers
 ******************************************************************************/

/*******************************************************************************
 * SendCommand
 *
 * Send the command from application (IL-client) to component
 ******************************************************************************/

static OMX_ERRORTYPE SendCommand(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_COMMANDTYPE Cmd, OMX_IN OMX_U32 nParam1, OMX_IN OMX_PTR pCmdData)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase     *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check private data pointer is valid */
    XF_CHK_ERR(pData, OMX_ErrorBadParameter);

    /* ...check execution state is proper */
    XF_CHK_ERR(pData->state != OMX_StateInvalid, OMX_ErrorInvalidState);

    TRACE(SM, _b("Command received: (%d, %lu, %p)"), Cmd, nParam1, pCmdData);

    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...dispatch command execution */
    switch(Cmd) {
    case OMX_CommandStateSet:
        /* ...state transition command */
        eError = xaomx_command_state_set(pData, (OMX_STATETYPE) nParam1);
        break;

    case OMX_CommandMarkBuffer:
        /* ...buffer mark processing command */
        eError = xaomx_command_mark_buffer(pData, nParam1, pCmdData);
        break;

    case OMX_CommandPortDisable:
    case OMX_CommandPortEnable:
    case OMX_CommandFlush:
        /* ...port control command */
        eError = xaomx_command_port_control(pData, Cmd, nParam1);
        break;

    default:
        /* ...invalid command */
        eError = OMX_ErrorBadParameter;
        break;
    }

    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * GetState
 *
 * Return the current state of the component
 ******************************************************************************/

static OMX_ERRORTYPE GetState(OMX_IN OMX_HANDLETYPE hComponent, OMX_OUT OMX_STATETYPE* pState)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase     *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;

    /* ...basic sanity check */
    XF_CHK_ERR(pData && pState, OMX_ErrorBadParameter);

    /* ...output current component state */
    *pState = pData->state;

    return OMX_ErrorNone;
}

/*******************************************************************************
 * GetConfig
 *
 * Retrieve the component configuration
 ******************************************************************************/
/* PRQA S 3206 1 *//* Confirm function usage is correct. Oct 14, 2016 */
static OMX_ERRORTYPE GetConfig(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_INOUT OMX_PTR pComponentConfigStructure)
{
    return XAOMX_CHK_API(OMX_ErrorNotImplemented);
}

/*******************************************************************************
 * SetConfig
 *
 * Set the component configuration
 ******************************************************************************/
/* PRQA S 3206 1 *//* Confirm function usage is correct. Oct 14, 2016 */
static OMX_ERRORTYPE SetConfig(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_IN OMX_PTR pComponentConfigStructure)
{
    return XAOMX_CHK_API(OMX_ErrorNotImplemented);
}

/*******************************************************************************
 * GetExtensionIndex
 *
 * Set the component configuration
 ******************************************************************************/
/* PRQA S 3206 1 *//* Confirm function usage is correct. Oct 14, 2016 */
static OMX_ERRORTYPE GetExtensionIndex(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_STRING cParameterName, OMX_OUT OMX_INDEXTYPE* pIndexType)
{
    return XAOMX_CHK_API(OMX_ErrorNotImplemented);
}

/*******************************************************************************
 * ComponentTunnelRequest
 *
 * Establish a tunnel between components
 ******************************************************************************/

static OMX_ERRORTYPE ComponentTunnelRequest(OMX_IN OMX_HANDLETYPE hComp, OMX_IN OMX_U32 nPort, OMX_IN OMX_HANDLETYPE hTunneledComp, OMX_IN OMX_U32 nTunneledPort, OMX_INOUT OMX_TUNNELSETUPTYPE* pTunnelSetup)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComp;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;

    OMX_ERRORTYPE      eError;
    OMX_PARAM_PORTDEFINITIONTYPE param;
    OMX_PARAM_BUFFERSUPPLIERTYPE pSupplier;

    XF_CHK_ERR(nPort < sizeof(pData->sPortDef)/sizeof(pData->sPortDef[0]), OMX_ErrorBadPortIndex);

    XF_CHK_ERR(pData->state == OMX_StateLoaded, OMX_ErrorIncorrectStateOperation);

    if ((pTunnelSetup == NULL) || (hTunneledComp == 0))
    {
        /* ...cancel previous tunnel */
        pData->hTunnelComp[nPort] = (OMX_HANDLETYPE)NULL;
        pData->nTunnelPort[nPort] = 0;
        pData->nTunnelFlags[nPort] = XA_FLAG_TUNNEL_NONE;
        pData->sSupplier[nPort].eBufferSupplier = OMX_BufferSupplyUnspecified;
        pTunnelSetup->eSupplier = OMX_BufferSupplyUnspecified;
        return OMX_ErrorNone;
    }

    if (pData->sPortDef[nPort].eDir == OMX_DirInput)
    {
        /* ...get Port Definition of the Tunneled Component */
        param.nPortIndex = nTunneledPort;
        XAOMX_INIT_STRUCT(&param, OMX_PARAM_PORTDEFINITIONTYPE);
        eError = OMX_GetParameter(hTunneledComp, OMX_IndexParamPortDefinition, &param);
        if (eError != OMX_ErrorNone)
        {
            TRACE(SM, _b("Tunneled Port Definition error: 0x%08x"), eError);
            /* ...compatibility not reached */
            return eError;
        }

        /* ...check port domain must be audio */
        XF_CHK_ERR(param.eDomain == OMX_PortDomainAudio, OMX_ErrorPortsNotCompatible);

        /* ...check encoding of tunneled port is sane */
        XF_CHK_ERR(param.format.audio.eEncoding == pData->sPortDef[nPort].format.audio.eEncoding, OMX_ErrorPortsNotCompatible);

        /* ...check number buffer of tunneled ports is same */
        XF_CHK_ERR(param.nBufferCountActual == pData->sPortDef[nPort].nBufferCountActual, OMX_ErrorPortsNotCompatible);

        /* ...get Buffer Supplier type of the Tunneled Component */
        pSupplier.nPortIndex = nTunneledPort;
        XAOMX_INIT_STRUCT(&pSupplier, OMX_PARAM_BUFFERSUPPLIERTYPE);
        eError = OMX_GetParameter(hTunneledComp, OMX_IndexParamCompBufferSupplier, &pSupplier);
        if (eError != OMX_ErrorNone)
        {
            /* ...compatibility not reached */
            TRACE(SM, _b("Tunneled Buffer Supplier error: 0x%08x"), eError);
            return eError;
        }
        else
        {
            TRACE(SM, _b("Tunneled Port eBufferSupplier: %x"), pSupplier.eBufferSupplier);
        }

        /* ...store the current callbacks, if defined */
        pData->hTunnelComp[nPort] = hTunneledComp;
        pData->nTunnelPort[nPort] = nTunneledPort;

        /* ...Negotiation - always make output port supplier */
        pTunnelSetup->eSupplier = OMX_BufferSupplyOutput;
        //pData->nTunnelFlags[nPort] |= XA_FLAG_TUNNEL_SUPPLIER;
        pData->nTunnelFlags[nPort] |= XA_FLAG_TUNNEL_ESTABLISHED;
        pData->sSupplier[nPort].eBufferSupplier = OMX_BufferSupplyOutput;

        /* ...Set Buffer Supplier type of the Tunnelled Component after final negotiation */
        pSupplier.nPortIndex = nTunneledPort;
        pSupplier.eBufferSupplier = pData->sSupplier[nPort].eBufferSupplier;
        eError = OMX_SetParameter(hTunneledComp, OMX_IndexParamCompBufferSupplier, &pSupplier);
        if (eError != OMX_ErrorNone)
        {
            /* ...compatibility not reached */
            TRACE(SM, _b("Tunneled Buffer Supplier error: 0x%08x"), eError);
            pData->eos_codec = XA_FLAG_TUNNEL_NONE;
            return eError;
        }
    }
    else
    {
        /* ...output port */

        /* ...get Port Definition of the Tunneled Component */
        param.nPortIndex = nTunneledPort;
        XAOMX_INIT_STRUCT(&param, OMX_PARAM_PORTDEFINITIONTYPE);
        eError = OMX_GetParameter(hTunneledComp, OMX_IndexParamPortDefinition, &param);
        if (eError != OMX_ErrorNone)
        {
            TRACE(SM, _b("Tunneled Port Definition error: 0x%08x"), eError);
            /* ...compatibility not reached */
            return eError;
        }

        /* ...check port domain must be audio */
        XF_CHK_ERR(param.eDomain == OMX_PortDomainAudio, OMX_ErrorPortsNotCompatible);

        /* ...check encoding of tunneled port is sane */
        XF_CHK_ERR(param.format.audio.eEncoding == pData->sPortDef[nPort].format.audio.eEncoding, OMX_ErrorPortsNotCompatible);

        /* ...check number buffer of tunneled ports is same */
        XF_CHK_ERR(param.nBufferCountActual == pData->sPortDef[nPort].nBufferCountActual, OMX_ErrorPortsNotCompatible);

        /* ...set up output port supplier information - always make output supplier */
        pData->hTunnelComp[nPort] = hTunneledComp;
        pData->nTunnelPort[nPort] = nTunneledPort;
        pData->nTunnelFlags[nPort] |= XA_FLAG_TUNNEL_SUPPLIER | XA_FLAG_TUNNEL_ESTABLISHED;
        pData->sSupplier[nPort].eBufferSupplier = OMX_BufferSupplyOutput;
        pTunnelSetup->eSupplier = OMX_BufferSupplyOutput;
    }

    return OMX_ErrorNone;
}

/*******************************************************************************
 * GetComponentVersion
 *
 * Return component version identification
 ******************************************************************************/
/* PRQA S 3206 1 *//* Confirm function usage is correct. Oct 14, 2016 */
static OMX_ERRORTYPE GetComponentVersion(OMX_IN OMX_HANDLETYPE hComponent, OMX_OUT OMX_STRING pComponentName, OMX_OUT OMX_VERSIONTYPE* pComponentVersion, OMX_OUT OMX_VERSIONTYPE* pSpecVersion, OMX_OUT OMX_UUIDTYPE* pComponentUUID)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;

    /* ...basic sanity check */
    XF_CHK_ERR(pComponentVersion && pComponentName && pSpecVersion, OMX_ErrorBadParameter);

    /* ...component name string */
    strcpy(pComponentName, pData->pComponentName);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...component version */
    pComponentVersion->s.nVersionMajor = 1;
    pComponentVersion->s.nVersionMinor = 0;
    pComponentVersion->s.nRevision = 0;
    pComponentVersion->s.nVersionMajor = 0;

    /* ...this should be available in a header somewhere - tbd */
    pSpecVersion->s.nVersionMajor = 1;
    pSpecVersion->s.nVersionMinor = 0;
    pSpecVersion->s.nRevision = 0;
    pSpecVersion->s.nVersionMajor = 0;

    return OMX_ErrorNone;
}

/*******************************************************************************
 * SetCallbacks
 *
 * Set application callbacks for the component
 ******************************************************************************/

static OMX_ERRORTYPE SetCallbacks(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_CALLBACKTYPE *pCallbacks, OMX_IN OMX_PTR pAppData)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;

    /* ...basic sanity checks */
    XF_CHK_ERR(pData && pCallbacks && pAppData, OMX_ErrorBadParameter);

    /* ...assign the client data */
    pData->pCallbacks = pCallbacks;
    pData->pAppData = pAppData;

    return OMX_ErrorNone;
}

/*******************************************************************************
 * GetParameter
 *
 * Retrieve the parameter from the component
 ******************************************************************************/

static OMX_ERRORTYPE GetParameter(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nParamIndex, OMX_INOUT OMX_PTR pComponentParameterStructure)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...chack data handle is valid */
    XF_CHK_ERR(pData && pComponentParameterStructure, OMX_ErrorBadParameter);

    /* ...check execution state is proper */
    XF_CHK_ERR(pData->state != OMX_StateInvalid, OMX_ErrorIncorrectStateOperation);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_get_parameter(pData, nParamIndex, pComponentParameterStructure);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * SetParameter
 *
 * Retrieve the parameter from the component
 ******************************************************************************/

static OMX_ERRORTYPE SetParameter(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_INDEXTYPE nIndex, OMX_IN OMX_PTR pComponentParameterStructure)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE      eError;

    /* ...check data handle is valid */
    XF_CHK_ERR(pData && pComponentParameterStructure, OMX_ErrorBadParameter);

    /* ...check execution state is proper */
    XF_CHK_ERR(pData->state != OMX_StateInvalid, OMX_ErrorIncorrectStateOperation);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_set_parameter(pData, nIndex, pComponentParameterStructure);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * UseBuffer
 *
 * Pass the handle to the buffer allocated by application
 ******************************************************************************/

static OMX_ERRORTYPE UseBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_INOUT OMX_BUFFERHEADERTYPE** ppBufferHdr, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_PTR pAppPrivate, OMX_IN OMX_U32 nSizeBytes, OMX_IN OMX_U8* pBuffer)
//(OMX_HANDLETYPE hComponent, OMX_BUFFERHEADERTYPE** ppBufHdr, OMX_U32 nPort, OMX_PTR pAppPrivate, OMX_U32 nSizeBytes, OMX_U8* pBuffer)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check data validity (do we allow NULL pointer for pBuffer? - TBD) */
    XF_CHK_ERR(pData && ppBufferHdr, OMX_ErrorBadParameter);

    /* ...check target port is valid */
    XF_CHK_ERR(nPortIndex < 2, OMX_ErrorBadParameter);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_create_buffer(pData, ppBufferHdr, nPortIndex, nSizeBytes, pAppPrivate, pBuffer, OMX_FALSE);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    TRACE(INIT, _b("UseBuffer[%lu]: buf = %p"), nPortIndex, *ppBufferHdr);

    return eError;
}

/*******************************************************************************
 * AllocateBuffer
 *
 * Allocate buffer on behalf of a component
 ******************************************************************************/

static OMX_ERRORTYPE AllocateBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_INOUT OMX_BUFFERHEADERTYPE** ppBuffer, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_PTR pAppPrivate, OMX_IN OMX_U32 nSizeBytes)
                                        //OMX_HANDLETYPE hComponent, OMX_BUFFERHEADERTYPE **ppBufHdr, OMX_U32 nPort, OMX_PTR pAppPrivate, OMX_U32 nSizeBytes)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check data validity */
    XF_CHK_ERR(pData && ppBuffer, OMX_ErrorBadParameter);

    /* ...check target port is valid */
    XF_CHK_ERR(nPortIndex <= XAOMX_PORT_MAX, OMX_ErrorBadParameter);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_create_buffer(pData, ppBuffer, nPortIndex, nSizeBytes, pAppPrivate, NULL, OMX_TRUE);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    TRACE(BUFFER, _b("AllocateBuffer[%lu]: buf = %p"), nPortIndex, *ppBuffer);

    return eError;
}

/*******************************************************************************
 * FreeBuffer
 *
 * Deallocate buffer structure
 ******************************************************************************/

static OMX_ERRORTYPE FreeBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_U32 nPortIndex, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer)
            //OMX_HANDLETYPE hComponent, OMX_U32 nPort, OMX_BUFFERHEADERTYPE* pBufHdr)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check data validity */
    XF_CHK_ERR(pData && pBuffer, OMX_ErrorBadParameter);

    /* ...check buffer version */
    XAOMX_CHK_VERSION(pBuffer, OMX_BUFFERHEADERTYPE);

    /* ...check target port is valid */
    XF_CHK_ERR(nPortIndex <= XAOMX_PORT_MAX, OMX_ErrorBadParameter);

    TRACE(BUFFER, _b("FreeBuffer[%lu]: buf = %p"), nPortIndex, pBuffer);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_free_buffer(pData, nPortIndex, pBuffer);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * EmptyThisBuffer
 *
 * Pass filled input buffer to the component
 ******************************************************************************/

static OMX_ERRORTYPE EmptyThisBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer)
            //OMX_HANDLETYPE hComponent, OMX_BUFFERHEADERTYPE* pBufHdr)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check data validity */
    XF_CHK_ERR(pData && pBuffer, OMX_ErrorBadParameter);

    /* ...check buffer version (do we need that? - tbd) */
    XAOMX_CHK_VERSION(pBuffer, OMX_BUFFERHEADERTYPE);

    /* ...check buffer port index is valid */
    XF_CHK_ERR(pBuffer->nInputPortIndex <= XAOMX_PORT_MAX && pBuffer->nOutputPortIndex == XAOMX_NOPORT, OMX_ErrorBadPortIndex);

    TRACE(CMD, _b("EmptyThisBuffer[%p]: (%p, %lu)"), pBuffer, pBuffer->pBuffer, pBuffer->nFilledLen);

    /* ...execute command in interloced fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_empty_this_buffer(pData, pBuffer);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * FillThisBuffer
 *
 * Pass the free output buffer to the component
 ******************************************************************************/

static OMX_ERRORTYPE FillThisBuffer(OMX_IN OMX_HANDLETYPE hComponent, OMX_IN OMX_BUFFERHEADERTYPE* pBuffer)
                //OMX_HANDLETYPE hComponent, OMX_BUFFERHEADERTYPE* pBufHdr)
{
    OMX_COMPONENTTYPE  *pHandle = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pHandle->pComponentPrivate;
    OMX_ERRORTYPE       eError;

    /* ...check data validity */
    XF_CHK_ERR(pData && pBuffer, OMX_ErrorBadParameter);

    /* ...check buffer version (need that? - tbd) */
    XAOMX_CHK_VERSION(pBuffer, OMX_BUFFERHEADERTYPE);

    /* ...check buffer port index is valid */
    XF_CHK_ERR(pBuffer->nInputPortIndex == XAOMX_NOPORT && pBuffer->nOutputPortIndex <= XAOMX_PORT_MAX, OMX_ErrorBadPortIndex);

    TRACE(CMD, _b("FillThisBuffer[%p]: (%p)"), pBuffer, pBuffer->pBuffer);

    /* ...execute command in interlocked fashion */
    pthread_mutex_lock(&pData->mutex);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    eError = xaomx_fill_this_buffer(pData, pBuffer);
    pthread_mutex_unlock(&pData->mutex);    /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    return eError;
}

/*******************************************************************************
 * Public API
 ******************************************************************************/

/*******************************************************************************
 * XAOMXTDM_ComponentDeInit
 *
 * Deinitialize the component
 ******************************************************************************/
/* PRQA S 1503 1 *//* Confirm function usage is correct. Oct 14, 2016 */
OMX_ERRORTYPE XAOMXTDM_ComponentDeInit(OMX_HANDLETYPE hComponent)
{
    OMX_COMPONENTTYPE  *pComp = (OMX_COMPONENTTYPE *) hComponent;
    XAOMXTDMCodecBase  *pData = (XAOMXTDMCodecBase *) pComp->pComponentPrivate;
    OMX_ERRORTYPE       eError;
    s32                 i;

    /* ...sanity check */
    XF_CHK_ERR(pData, OMX_ErrorBadParameter);

    /* ...terminate thread if required */
    if (pData->thread_id != 0) {
        /* ...pass termination command to the component thread */
        xaomx_command(pData, XAOMX_CommandDeinitialize, NULL, 0);

        /* ...wait for thread to exit */
        pthread_join(pData->thread_id, (void*)&eError); /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    }

    /* ...close the pipe handles */
    close(pData->command[0]);       /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    close(pData->command[1]);       /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    close(pData->response[0]);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    close(pData->response[1]);      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        /* ...destroy all buffers we have allocated */
        xa_bufferlist_destroy(pData, i);
    }

    /* ...close component handle */
    xf_close(&pData->handle);

    /* ...destroy component mutex */
    pthread_mutex_destroy(&pData->mutex);       /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...destroy conditional variable for synchronous communication */
    pthread_mutex_destroy(&pData->wait_lock);   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    pthread_cond_destroy(&pData->wait);         /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    TRACE(INIT, _b("Component deinitialized"));

    return OMX_ErrorNone;
}

/*******************************************************************************
 * XAOMX_ComponentInit
 *
 * Entry point for the OMX component
 ******************************************************************************/
/* PRQA S 1503 1 *//* Confirm function usage is correct. Oct 14, 2016 */
OMX_ERRORTYPE XAOMXTDM_ComponentInit(xf_proxy_t *proxy, OMX_HANDLETYPE hComponent, OMX_PTR pAppData, OMX_CALLBACKTYPE *pCallbacks, OMX_STRING cRole, xf_id_t id)
{
    OMX_COMPONENTTYPE       *pComp = (OMX_COMPONENTTYPE *)hComponent;
    XAOMXTDMCodecBase       *pData = (XAOMXTDMCodecBase *)pComp->pComponentPrivate;
    pthread_mutexattr_t     attr;      /* PRQA S 0759 *//* Confirm variable usage is correct. Oct 14, 2016 */
    s32                     i;
    
    /* ...set private data */
    pData->hSelf = hComponent;
    pData->cRole = cRole;
    pData->pCallbacks = pCallbacks;
    pData->pAppData = pAppData;
    pData->state = OMX_StateLoaded;
    pData->eos_codec = 0;
    pData->eos_port = 0;

    /* ...initialize mutex (allow nested locks) */
    pthread_mutexattr_init(&attr);                              /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);  /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    pthread_mutex_init(&pData->mutex, &attr);                   /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...initialize conditional variable for synchronous operations with proxy */
    pthread_mutex_init(&pData->wait_lock, NULL);                /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */
    pthread_cond_init(&pData->wait, NULL);                      /* PRQA S 3200 *//* Confirm return value is no use. Oct 14, 2016 */

    /* ...create component handle */
    XF_CHK_ERR(xf_open(proxy, &pData->handle, id, 0, xaomx_response_cb) == 0, OMX_ErrorInsufficientResources);

    /* ...fill-in function pointers */
    pComp->SetCallbacks = &SetCallbacks;
    pComp->GetComponentVersion = &GetComponentVersion;
    pComp->SendCommand = &SendCommand;
    pComp->GetParameter = &GetParameter;
    pComp->SetParameter = &SetParameter;
    pComp->GetConfig = &GetConfig;
    pComp->SetConfig = &SetConfig;
    pComp->GetExtensionIndex = &GetExtensionIndex;
    pComp->GetState = &GetState;
    pComp->ComponentTunnelRequest = &ComponentTunnelRequest;
    pComp->UseBuffer = &UseBuffer;
    pComp->AllocateBuffer = &AllocateBuffer;
    pComp->FreeBuffer = &FreeBuffer;
    pComp->EmptyThisBuffer = &EmptyThisBuffer;
    pComp->FillThisBuffer = &FillThisBuffer;
    pComp->ComponentDeInit = NULL;

    /* ...set total amount of ports */
    XAOMX_INIT_STRUCT(&pData->sPortParam, OMX_PORT_PARAM_TYPE);
    pData->sPortParam.nPorts = XAOMX_PORT_MAX + 1;
    pData->sPortParam.nStartPortNumber = 0;

    for (i = 0; i <= XAOMX_PORT_MAX; i++)
    {
        /* ...initialize the audio parameters for input port */
        XAOMX_INIT_STRUCT(&pData->sPortDef[i], OMX_PARAM_PORTDEFINITIONTYPE);
        pData->sPortDef[i].nPortIndex = i;
        pData->sPortDef[i].eDir = OMX_DirMax;
        pData->sPortDef[i].bEnabled = OMX_TRUE;
        pData->sPortDef[i].bPopulated = OMX_FALSE;
        pData->sPortDef[i].eDomain = OMX_PortDomainAudio;

        /* ...initialize the compression format for input port */
        XAOMX_INIT_STRUCT(&pData->sPortFormat[i], OMX_AUDIO_PARAM_PORTFORMATTYPE);
        pData->sPortFormat[i].nPortIndex = i;
    }

    /* ...priority management structure (we do not use that thing - TBD) */
    XAOMX_INIT_STRUCT(&pData->sPriorityMgmt, OMX_PRIORITYMGMTTYPE);

    /* ************ TBD ***********************************************************/
    /* ...initialize tunneled component handle */
    pData->hTunnelComp[0] = (OMX_HANDLETYPE)NULL;
    pData->hTunnelComp[1] = (OMX_HANDLETYPE)NULL;

    /* ...initialize tunneled port */
    pData->nTunnelPort[0] = 0;
    pData->nTunnelPort[1] = 0;
    pData->nTunnelFlags[0] = XA_FLAG_TUNNEL_NONE;
    pData->nTunnelFlags[1] = XA_FLAG_TUNNEL_NONE;

    /* ...initialize tunneled supplier structure for input port */
    XAOMX_INIT_STRUCT(&pData->sSupplier[0], OMX_PARAM_BUFFERSUPPLIERTYPE);
    pData->sSupplier[0].nPortIndex = 0;
    pData->sSupplier[0].eBufferSupplier = OMX_BufferSupplyUnspecified;

    /* ...initialize tunneled supplier structure for output port */
    XAOMX_INIT_STRUCT(&pData->sSupplier[1], OMX_PARAM_BUFFERSUPPLIERTYPE);
    pData->sSupplier[1].nPortIndex = 1;
    pData->sSupplier[1].eBufferSupplier = OMX_BufferSupplyUnspecified;
    /* ****************************************************************************/

    /* ...pipe used to send commands to the thread */
    XF_CHK_ERR(pipe2(pData->command, O_NONBLOCK) == 0, OMX_ErrorInsufficientResources);

    /* ...pipe used to retrieve responses from the component */
    XF_CHK_ERR(pipe2(pData->response, O_NONBLOCK) == 0, OMX_ErrorInsufficientResources);

    /* ...component thread proper */
    XF_CHK_ERR(pthread_create(&pData->thread_id, NULL, xaomx_component_thread, pData) == 0, OMX_ErrorInsufficientResources);

    TRACE(INIT, _b("Codec component created"));

    return OMX_ErrorNone;
}
