GLSLCOMPILER_README_E

1. Preface
 This CD-R includes the GLSL off-line compiler of R8A7795 GX6650 OpenGL ES Library
 for Android. You may only use these tools by agreeing to the SDK licensing terms of
 Imagination Technologies Limited.

 URL for SDK licensing:
 https://www.imgtec.com/developers/powervr-sdk-tools/powervr-tools-software-eula/

2. Specification for GL_IMG_shader_binary
 Refer to the GL_IMG_shader_binary in following URL.
 URL in Khronos site: https://www.khronos.org/registry/OpenGL/index_es.php

3. Usage
 Run the GLSLCompilerFrontendDDK_host with following syntax from command prompt on Linux machine.
 (Please store the glslcompilerfrontend_host, libglslcompiler.4.46.6.62.so
 in the same folder)

 -
    Syntax: GLSLCompilerFrontendDDK_host <sourcefile> <outputfile> <-v,-f> -bvnc 4.46.6.62 [OPTIONS]

    Use
            -v for vertex shaders or
            -f for fragment shaders.

    OPTIONS are: -nowarn                 : disable compiler warnings
                 -validateonly           : only validate the code. Do not compile
                 -notcomplete            : don't check for code completeness
 -

GLSLCOMPILER_README_E.TXT / Nov 2019
